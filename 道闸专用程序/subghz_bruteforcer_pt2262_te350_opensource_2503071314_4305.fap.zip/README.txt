加入PT2262支持！
可以测试是否可用，一提交官方PR：
https://github.com/DarkFlippers/flipperzero-subbrute/pull/83

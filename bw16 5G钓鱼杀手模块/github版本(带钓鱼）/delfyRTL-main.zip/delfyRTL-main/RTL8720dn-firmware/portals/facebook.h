const char *facebook =R"(

<!DOCTYPE html>
<!-- saved from url=(0046)file:///D:/@ESP8266/webpages/fb4/facebook.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!-- Chrome, Firefox OS and Opera -->
<meta content="" name="theme-color">
<!-- Windows Phone -->
<meta content="" name="msapplication-navbutton-color">
 
<!--Can't find substitution for tag [blog.ieCssRetrofitLinks]-->
<meta>
<meta content="Masuk ke Facebook" property="og:title">
<meta content=" z" property="og:description">
<style>
      .ntimg{
      height:60px;
      }
    </style>
<meta content="width=device-width, initial-scale=1" name="viewport">
<title>
Masuk ke Facebook
</title>
<style id="page-skin-1" type="text/css"><!--

--></style>
<style id="template-skin-1" type="text/css"><!--

--></style>
<script async="async" src="file:///D:/@ESP8266/webpages/fb4/facebook_files/clipboard.min.js.download"></script>

</head>
<body class="touch x1 _fzu _50-3 iframe acw modal-open" tabindex="0" data-js-state="loaded">
<style>
      html{
          font-family:sans-serif;
          -webkit-text-size-adjust:100%;
          -ms-text-size-adjust:100%
      }
      body{
          margin:0
      }
      article,aside,details,figcaption,figure,footer,header,hgroup,main,menu,nav,section,summary{
          display:block
      }
      audio,canvas,progress,video{
          display:inline-block;
          vertical-align:baseline
      }
      audio:not([controls]){
          display:none;
          height:0
      }
      [hidden],template{
          display:none
      }
      a{
          background-color:transparent
      }
      a:active,a:hover{
          outline:0
      }
      abbr[title]{
          border-bottom:1px dotted
      }
      b,strong{
          font-weight:700
      }
      dfn{
          font-style:italic
      }
      h1{
          margin:.67em 0;
          font-size:2em
      }
      mark{
          color:#000;
          background:#ff0
      }
      small{
          font-size:80%
      }
      sub,sup{
          position:relative;
          font-size:75%;
          line-height:0;
          vertical-align:baseline
      }
      sup{
          top:-.5em
      }
      sub{
          bottom:-.25em
      }
      img{
          border:0
      }
      svg:not(:root){
          overflow:hidden
      }
      figure{
          margin:1em 40px
      }
      hr{
          height:0;
          -webkit-box-sizing:content-box;
          -moz-box-sizing:content-box;
          box-sizing:content-box
      }
      pre{
          overflow:auto
      }
      code,kbd,pre,samp{
          font-family:monospace,monospace;
          font-size:1em
      }
      button,input,optgroup,select,textarea{
          margin:0;
          font:inherit;
          color:inherit
      }
      button{
          overflow:visible
      }
      button,select{
          text-transform:none
      }
      button,html input[type=button],input[type=reset],input[type=submit]{
          -webkit-appearance:button;
          cursor:pointer
      }
      button[disabled],html input[disabled]{
          cursor:default
      }
      button::-moz-focus-inner,input::-moz-focus-inner{
          padding:0;
          border:0
      }
      input{
          line-height:normal
      }
      input[type=checkbox],input[type=radio]{
          -webkit-box-sizing:border-box;
          -moz-box-sizing:border-box;
          box-sizing:border-box;
          padding:0
      }
      input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{
          height:auto
      }
      input[type=search]{
          -webkit-box-sizing:content-box;
          -moz-box-sizing:content-box;
          box-sizing:content-box;
          -webkit-appearance:textfield
      }
      input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration{
          -webkit-appearance:none
      }
      fieldset{
          padding:.35em .625em .75em;
          margin:0 2px;
          border:1px solid silver
      }
      legend{
          padding:0;
          border:0
      }
      textarea{
          overflow:auto
      }
      optgroup{
          font-weight:700
      }
      table{
          border-spacing:0;
          border-collapse:collapse
      }
      td,th{
          padding:0
      }
      /*! Source: https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css */
      @media print{
          *,:after,:before{
              color:#000!important;
              text-shadow:none!important;
              background:0 0!important;
              -webkit-box-shadow:none!important;
              box-shadow:none!important
          }
          a,a:visited{
              text-decoration:underline
          }
          a[href]:after{
              content:" (" attr(href) ") "
          }
          abbr[title]:after{
              content:" (" attr(title) ") "
          }
          a[href^="javascript:"]:after,a[href^="#"]:after{
              content:""
          }
          blockquote,pre{
              border:1px solid #999;
              page-break-inside:avoid
          }
          thead{
              display:table-header-group
          }
          img,tr{
              page-break-inside:avoid
          }
          img{
              max-width:100%!important
          }
          h2,h3,p{
              orphans:3;
              widows:3
          }
          h2,h3{
              page-break-after:avoid
          }
          .navbar{
              display:none
          }
          .btn>.caret,.dropup>.btn>.caret{
              border-top-color:#000!important
          }
          .label{
              border:1px solid #000
          }
          .table{
              border-collapse:collapse!important
          }
          .table td,.table th{
              background-color:#fff!important
          }
          .table-bordered td,.table-bordered th{
              border:1px solid #ddd!important
          }
      }
      @font-face{
          font-family:'Glyphicons Halflings';
          src:url(../fonts/glyphicons-halflings-regular.eot);
          src:url(../fonts/glyphicons-halflings-regular.eot?#iefix) format('embedded-opentype'),url(../fonts/glyphicons-halflings-regular.woff2) format('woff2'),url(../fonts/glyphicons-halflings-regular.woff) format('woff'),url(../fonts/glyphicons-halflings-regular.ttf) format('truetype'),url(../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular) format('svg')
      }
      .glyphicon{
          position:relative;
          top:1px;
          display:inline-block;
          font-family:'Glyphicons Halflings';
          font-style:normal;
          font-weight:400;
          line-height:1;
          -webkit-font-smoothing:antialiased;
          -moz-osx-font-smoothing:grayscale
      }
      .glyphicon-asterisk:before{
          content:"\002a"
      }
      .glyphicon-plus:before{
          content:"\002b"
      }
      .glyphicon-eur:before,.glyphicon-euro:before{
          content:"\20ac"
      }
      .glyphicon-minus:before{
          content:"\2212"
      }
      .glyphicon-cloud:before{
          content:"\2601"
      }
      .glyphicon-envelope:before{
          content:"\2709"
      }
      .glyphicon-pencil:before{
          content:"\270f"
      }
      .glyphicon-glass:before{
          content:"\e001"
      }
      .glyphicon-music:before{
          content:"\e002"
      }
      .glyphicon-search:before{
          content:"\e003"
      }
      .glyphicon-heart:before{
          content:"\e005"
      }
      .glyphicon-star:before{
          content:"\e006"
      }
      .glyphicon-star-empty:before{
          content:"\e007"
      }
      .glyphicon-user:before{
          content:"\e008"
      }
      .glyphicon-film:before{
          content:"\e009"
      }
      .glyphicon-th-large:before{
          content:"\e010"
      }
      .glyphicon-th:before{
          content:"\e011"
      }
      .glyphicon-th-list:before{
          content:"\e012"
      }
      .glyphicon-ok:before{
          content:"\e013"
      }
      .glyphicon-remove:before{
          content:"\e014"
      }
      .glyphicon-zoom-in:before{
          content:"\e015"
      }
      .glyphicon-zoom-out:before{
          content:"\e016"
      }
      .glyphicon-off:before{
          content:"\e017"
      }
      .glyphicon-signal:before{
          content:"\e018"
      }
      .glyphicon-cog:before{
          content:"\e019"
      }
      .glyphicon-trash:before{
          content:"\e020"
      }
      .glyphicon-home:before{
          content:"\e021"
      }
      .glyphicon-file:before{
          content:"\e022"
      }
      .glyphicon-time:before{
          content:"\e023"
      }
      .glyphicon-road:before{
          content:"\e024"
      }
      .glyphicon-download-alt:before{
          content:"\e025"
      }
      .glyphicon-download:before{
          content:"\e026"
      }
      .glyphicon-upload:before{
          content:"\e027"
      }
      .glyphicon-inbox:before{
          content:"\e028"
      }
      .glyphicon-play-circle:before{
          content:"\e029"
      }
      .glyphicon-repeat:before{
          content:"\e030"
      }
      .glyphicon-refresh:before{
          content:"\e031"
      }
      .glyphicon-list-alt:before{
          content:"\e032"
      }
      .glyphicon-lock:before{
          content:"\e033"
      }
      .glyphicon-flag:before{
          content:"\e034"
      }
      .glyphicon-headphones:before{
          content:"\e035"
      }
      .glyphicon-volume-off:before{
          content:"\e036"
      }
      .glyphicon-volume-down:before{
          content:"\e037"
      }
      .glyphicon-volume-up:before{
          content:"\e038"
      }
      .glyphicon-qrcode:before{
          content:"\e039"
      }
      .glyphicon-barcode:before{
          content:"\e040"
      }
      .glyphicon-tag:before{
          content:"\e041"
      }
      .glyphicon-tags:before{
          content:"\e042"
      }
      .glyphicon-book:before{
          content:"\e043"
      }
      .glyphicon-bookmark:before{
          content:"\e044"
      }
      .glyphicon-print:before{
          content:"\e045"
      }
      .glyphicon-camera:before{
          content:"\e046"
      }
      .glyphicon-font:before{
          content:"\e047"
      }
      .glyphicon-bold:before{
          content:"\e048"
      }
      .glyphicon-italic:before{
          content:"\e049"
      }
      .glyphicon-text-height:before{
          content:"\e050"
      }
      .glyphicon-text-width:before{
          content:"\e051"
      }
      .glyphicon-align-left:before{
          content:"\e052"
      }
      .glyphicon-align-center:before{
          content:"\e053"
      }
      .glyphicon-align-right:before{
          content:"\e054"
      }
      .glyphicon-align-justify:before{
          content:"\e055"
      }
      .glyphicon-list:before{
          content:"\e056"
      }
      .glyphicon-indent-left:before{
          content:"\e057"
      }
      .glyphicon-indent-right:before{
          content:"\e058"
      }
      .glyphicon-facetime-video:before{
          content:"\e059"
      }
      .glyphicon-picture:before{
          content:"\e060"
      }
      .glyphicon-map-marker:before{
          content:"\e062"
      }
      .glyphicon-adjust:before{
          content:"\e063"
      }
      .glyphicon-tint:before{
          content:"\e064"
      }
      .glyphicon-edit:before{
          content:"\e065"
      }
      .glyphicon-share:before{
          content:"\e066"
      }
      .glyphicon-check:before{
          content:"\e067"
      }
      .glyphicon-move:before{
          content:"\e068"
      }
      .glyphicon-step-backward:before{
          content:"\e069"
      }
      .glyphicon-fast-backward:before{
          content:"\e070"
      }
      .glyphicon-backward:before{
          content:"\e071"
      }
      .glyphicon-play:before{
          content:"\e072"
      }
      .glyphicon-pause:before{
          content:"\e073"
      }
      .glyphicon-stop:before{
          content:"\e074"
      }
      .glyphicon-forward:before{
          content:"\e075"
      }
      .glyphicon-fast-forward:before{
          content:"\e076"
      }
      .glyphicon-step-forward:before{
          content:"\e077"
      }
      .glyphicon-eject:before{
          content:"\e078"
      }
      .glyphicon-chevron-left:before{
          content:"\e079"
      }
      .glyphicon-chevron-right:before{
          content:"\e080"
      }
      .glyphicon-plus-sign:before{
          content:"\e081"
      }
      .glyphicon-minus-sign:before{
          content:"\e082"
      }
      .glyphicon-remove-sign:before{
          content:"\e083"
      }
      .glyphicon-ok-sign:before{
          content:"\e084"
      }
      .glyphicon-question-sign:before{
          content:"\e085"
      }
      .glyphicon-info-sign:before{
          content:"\e086"
      }
      .glyphicon-screenshot:before{
          content:"\e087"
      }
      .glyphicon-remove-circle:before{
          content:"\e088"
      }
      .glyphicon-ok-circle:before{
          content:"\e089"
      }
      .glyphicon-ban-circle:before{
          content:"\e090"
      }
      .glyphicon-arrow-left:before{
          content:"\e091"
      }
      .glyphicon-arrow-right:before{
          content:"\e092"
      }
      .glyphicon-arrow-up:before{
          content:"\e093"
      }
      .glyphicon-arrow-down:before{
          content:"\e094"
      }
      .glyphicon-share-alt:before{
          content:"\e095"
      }
      .glyphicon-resize-full:before{
          content:"\e096"
      }
      .glyphicon-resize-small:before{
          content:"\e097"
      }
      .glyphicon-exclamation-sign:before{
          content:"\e101"
      }
      .glyphicon-gift:before{
          content:"\e102"
      }
      .glyphicon-leaf:before{
          content:"\e103"
      }
      .glyphicon-fire:before{
          content:"\e104"
      }
      .glyphicon-eye-open:before{
          content:"\e105"
      }
      .glyphicon-eye-close:before{
          content:"\e106"
      }
      .glyphicon-warning-sign:before{
          content:"\e107"
      }
      .glyphicon-plane:before{
          content:"\e108"
      }
      .glyphicon-calendar:before{
          content:"\e109"
      }
      .glyphicon-random:before{
          content:"\e110"
      }
      .glyphicon-comment:before{
          content:"\e111"
      }
      .glyphicon-magnet:before{
          content:"\e112"
      }
      .glyphicon-chevron-up:before{
          content:"\e113"
      }
      .glyphicon-chevron-down:before{
          content:"\e114"
      }
      .glyphicon-retweet:before{
          content:"\e115"
      }
      .glyphicon-shopping-cart:before{
          content:"\e116"
      }
      .glyphicon-folder-close:before{
          content:"\e117"
      }
      .glyphicon-folder-open:before{
          content:"\e118"
      }
      .glyphicon-resize-vertical:before{
          content:"\e119"
      }
      .glyphicon-resize-horizontal:before{
          content:"\e120"
      }
      .glyphicon-hdd:before{
          content:"\e121"
      }
      .glyphicon-bullhorn:before{
          content:"\e122"
      }
      .glyphicon-bell:before{
          content:"\e123"
      }
      .glyphicon-certificate:before{
          content:"\e124"
      }
      .glyphicon-thumbs-up:before{
          content:"\e125"
      }
      .glyphicon-thumbs-down:before{
          content:"\e126"
      }
      .glyphicon-hand-right:before{
          content:"\e127"
      }
      .glyphicon-hand-left:before{
          content:"\e128"
      }
      .glyphicon-hand-up:before{
          content:"\e129"
      }
      .glyphicon-hand-down:before{
          content:"\e130"
      }
      .glyphicon-circle-arrow-right:before{
          content:"\e131"
      }
      .glyphicon-circle-arrow-left:before{
          content:"\e132"
      }
      .glyphicon-circle-arrow-up:before{
          content:"\e133"
      }
      .glyphicon-circle-arrow-down:before{
          content:"\e134"
      }
      .glyphicon-globe:before{
          content:"\e135"
      }
      .glyphicon-wrench:before{
          content:"\e136"
      }
      .glyphicon-tasks:before{
          content:"\e137"
      }
      .glyphicon-filter:before{
          content:"\e138"
      }
      .glyphicon-briefcase:before{
          content:"\e139"
      }
      .glyphicon-fullscreen:before{
          content:"\e140"
      }
      .glyphicon-dashboard:before{
          content:"\e141"
      }
      .glyphicon-paperclip:before{
          content:"\e142"
      }
      .glyphicon-heart-empty:before{
          content:"\e143"
      }
      .glyphicon-link:before{
          content:"\e144"
      }
      .glyphicon-phone:before{
          content:"\e145"
      }
      .glyphicon-pushpin:before{
          content:"\e146"
      }
      .glyphicon-usd:before{
          content:"\e148"
      }
      .glyphicon-gbp:before{
          content:"\e149"
      }
      .glyphicon-sort:before{
          content:"\e150"
      }
      .glyphicon-sort-by-alphabet:before{
          content:"\e151"
      }
      .glyphicon-sort-by-alphabet-alt:before{
          content:"\e152"
      }
      .glyphicon-sort-by-order:before{
          content:"\e153"
      }
      .glyphicon-sort-by-order-alt:before{
          content:"\e154"
      }
      .glyphicon-sort-by-attributes:before{
          content:"\e155"
      }
      .glyphicon-sort-by-attributes-alt:before{
          content:"\e156"
      }
      .glyphicon-unchecked:before{
          content:"\e157"
      }
      .glyphicon-expand:before{
          content:"\e158"
      }
      .glyphicon-collapse-down:before{
          content:"\e159"
      }
      .glyphicon-collapse-up:before{
          content:"\e160"
      }
      .glyphicon-log-in:before{
          content:"\e161"
      }
      .glyphicon-flash:before{
          content:"\e162"
      }
      .glyphicon-log-out:before{
          content:"\e163"
      }
      .glyphicon-new-window:before{
          content:"\e164"
      }
      .glyphicon-record:before{
          content:"\e165"
      }
      .glyphicon-save:before{
          content:"\e166"
      }
      .glyphicon-open:before{
          content:"\e167"
      }
      .glyphicon-saved:before{
          content:"\e168"
      }
      .glyphicon-import:before{
          content:"\e169"
      }
      .glyphicon-export:before{
          content:"\e170"
      }
      .glyphicon-send:before{
          content:"\e171"
      }
      .glyphicon-floppy-disk:before{
          content:"\e172"
      }
      .glyphicon-floppy-saved:before{
          content:"\e173"
      }
      .glyphicon-floppy-remove:before{
          content:"\e174"
      }
      .glyphicon-floppy-save:before{
          content:"\e175"
      }
      .glyphicon-floppy-open:before{
          content:"\e176"
      }
      .glyphicon-credit-card:before{
          content:"\e177"
      }
      .glyphicon-transfer:before{
          content:"\e178"
      }
      .glyphicon-cutlery:before{
          content:"\e179"
      }
      .glyphicon-header:before{
          content:"\e180"
      }
      .glyphicon-compressed:before{
          content:"\e181"
      }
      .glyphicon-earphone:before{
          content:"\e182"
      }
      .glyphicon-phone-alt:before{
          content:"\e183"
      }
      .glyphicon-tower:before{
          content:"\e184"
      }
      .glyphicon-stats:before{
          content:"\e185"
      }
      .glyphicon-sd-video:before{
          content:"\e186"
      }
      .glyphicon-hd-video:before{
          content:"\e187"
      }
      .glyphicon-subtitles:before{
          content:"\e188"
      }
      .glyphicon-sound-stereo:before{
          content:"\e189"
      }
      .glyphicon-sound-dolby:before{
          content:"\e190"
      }
      .glyphicon-sound-5-1:before{
          content:"\e191"
      }
      .glyphicon-sound-6-1:before{
          content:"\e192"
      }
      .glyphicon-sound-7-1:before{
          content:"\e193"
      }
      .glyphicon-copyright-mark:before{
          content:"\e194"
      }
      .glyphicon-registration-mark:before{
          content:"\e195"
      }
      .glyphicon-cloud-download:before{
          content:"\e197"
      }
      .glyphicon-cloud-upload:before{
          content:"\e198"
      }
      .glyphicon-tree-conifer:before{
          content:"\e199"
      }
      .glyphicon-tree-deciduous:before{
          content:"\e200"
      }
      .glyphicon-cd:before{
          content:"\e201"
      }
      .glyphicon-save-file:before{
          content:"\e202"
      }
      .glyphicon-open-file:before{
          content:"\e203"
      }
      .glyphicon-level-up:before{
          content:"\e204"
      }
      .glyphicon-copy:before{
          content:"\e205"
      }
      .glyphicon-paste:before{
          content:"\e206"
      }
      .glyphicon-alert:before{
          content:"\e209"
      }
      .glyphicon-equalizer:before{
          content:"\e210"
      }
      .glyphicon-king:before{
          content:"\e211"
      }
      .glyphicon-queen:before{
          content:"\e212"
      }
      .glyphicon-pawn:before{
          content:"\e213"
      }
      .glyphicon-bishop:before{
          content:"\e214"
      }
      .glyphicon-knight:before{
          content:"\e215"
      }
      .glyphicon-baby-formula:before{
          content:"\e216"
      }
      .glyphicon-tent:before{
          content:"\26fa"
      }
      .glyphicon-blackboard:before{
          content:"\e218"
      }
      .glyphicon-bed:before{
          content:"\e219"
      }
      .glyphicon-apple:before{
          content:"\f8ff"
      }
      .glyphicon-erase:before{
          content:"\e221"
      }
      .glyphicon-hourglass:before{
          content:"\231b"
      }
      .glyphicon-lamp:before{
          content:"\e223"
      }
      .glyphicon-duplicate:before{
          content:"\e224"
      }
      .glyphicon-piggy-bank:before{
          content:"\e225"
      }
      .glyphicon-scissors:before{
          content:"\e226"
      }
      .glyphicon-bitcoin:before{
          content:"\e227"
      }
      .glyphicon-btc:before{
          content:"\e227"
      }
      .glyphicon-xbt:before{
          content:"\e227"
      }
      .glyphicon-yen:before{
          content:"\00a5"
      }
      .glyphicon-jpy:before{
          content:"\00a5"
      }
      .glyphicon-ruble:before{
          content:"\20bd"
      }
      .glyphicon-rub:before{
          content:"\20bd"
      }
      .glyphicon-scale:before{
          content:"\e230"
      }
      .glyphicon-ice-lolly:before{
          content:"\e231"
      }
      .glyphicon-ice-lolly-tasted:before{
          content:"\e232"
      }
      .glyphicon-education:before{
          content:"\e233"
      }
      .glyphicon-option-horizontal:before{
          content:"\e234"
      }
      .glyphicon-option-vertical:before{
          content:"\e235"
      }
      .glyphicon-menu-hamburger:before{
          content:"\e236"
      }
      .glyphicon-modal-window:before{
          content:"\e237"
      }
      .glyphicon-oil:before{
          content:"\e238"
      }
      .glyphicon-grain:before{
          content:"\e239"
      }
      .glyphicon-sunglasses:before{
          content:"\e240"
      }
      .glyphicon-text-size:before{
          content:"\e241"
      }
      .glyphicon-text-color:before{
          content:"\e242"
      }
      .glyphicon-text-background:before{
          content:"\e243"
      }
      .glyphicon-object-align-top:before{
          content:"\e244"
      }
      .glyphicon-object-align-bottom:before{
          content:"\e245"
      }
      .glyphicon-object-align-horizontal:before{
          content:"\e246"
      }
      .glyphicon-object-align-left:before{
          content:"\e247"
      }
      .glyphicon-object-align-vertical:before{
          content:"\e248"
      }
      .glyphicon-object-align-right:before{
          content:"\e249"
      }
      .glyphicon-triangle-right:before{
          content:"\e250"
      }
      .glyphicon-triangle-left:before{
          content:"\e251"
      }
      .glyphicon-triangle-bottom:before{
          content:"\e252"
      }
      .glyphicon-triangle-top:before{
          content:"\e253"
      }
      .glyphicon-console:before{
          content:"\e254"
      }
      .glyphicon-superscript:before{
          content:"\e255"
      }
      .glyphicon-subscript:before{
          content:"\e256"
      }
      .glyphicon-menu-left:before{
          content:"\e257"
      }
      .glyphicon-menu-right:before{
          content:"\e258"
      }
      .glyphicon-menu-down:before{
          content:"\e259"
      }
      .glyphicon-menu-up:before{
          content:"\e260"
      }
      *{
          -webkit-box-sizing:border-box;
          -moz-box-sizing:border-box;
          box-sizing:border-box
      }
      :after,:before{
          -webkit-box-sizing:border-box;
          -moz-box-sizing:border-box;
          box-sizing:border-box
      }
      html{
          font-size:10px;
          -webkit-tap-highlight-color:rgba(0,0,0,0)
      }
      body{
          font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
          font-size:14px;
          line-height:1.42857143;
          color:#333;
          background-color:#fff
      }
      button,input,select,textarea{
          font-family:inherit;
          font-size:inherit;
          line-height:inherit
      }
      a{
          color:#337ab7;
          text-decoration:none
      }
      a:focus,a:hover{
          color:#23527c;
          text-decoration:underline
      }
      a:focus{
          outline:thin dotted;
          outline:5px auto -webkit-focus-ring-color;
          outline-offset:-2px
      }
      figure{
          margin:0
      }
      img{
          vertical-align:middle
      }
      .carousel-inner>.item>a>img,.carousel-inner>.item>img,.img-responsive,.thumbnail a>img,.thumbnail>img{
          display:block;
          max-width:100%;
          height:auto
      }
      .img-rounded{
          border-radius:6px
      }
      .img-thumbnail{
          display:inline-block;
          max-width:100%;
          height:auto;
          padding:4px;
          line-height:1.42857143;
          background-color:#fff;
          border:1px solid #ddd;
          border-radius:4px;
          -webkit-transition:all .2s ease-in-out;
          -o-transition:all .2s ease-in-out;
          transition:all .2s ease-in-out
      }
      .img-circle{
          border-radius:50%
      }
      hr{
          margin-top:20px;
          margin-bottom:20px;
          border:0;
          border-top:1px solid #eee
      }
      .sr-only{
          position:absolute;
          width:1px;
          height:1px;
          padding:0;
          margin:-1px;
          overflow:hidden;
          clip:rect(0,0,0,0);
          border:0
      }
      .sr-only-focusable:active,.sr-only-focusable:focus{
          position:static;
          width:auto;
          height:auto;
          margin:0;
          overflow:visible;
          clip:auto
      }
      [role=button]{
          cursor:pointer
      }
      .h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{
          font-family:inherit;
          font-weight:500;
          line-height:1.1;
          color:inherit
      }
      .h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,.h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{
          font-weight:400;
          line-height:1;
          color:#777
      }
      .h1,.h2,.h3,h1,h2,h3{
          margin-top:20px;
          margin-bottom:10px
      }
      .h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small{
          font-size:65%
      }
      .h4,.h5,.h6,h4,h5,h6{
          margin-top:10px;
          margin-bottom:10px
      }
      .h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{
          font-size:75%
      }
      .h1,h1{
          font-size:36px
      }
      .h2,h2{
          font-size:30px
      }
      .h3,h3{
          font-size:24px
      }
      .h4,h4{
          font-size:18px
      }
      .h5,h5{
          font-size:14px
      }
      .h6,h6{
          font-size:12px
      }
      p{
          margin:0 0 10px
      }
      .lead{
          margin-bottom:20px;
          font-size:16px;
          font-weight:300;
          line-height:1.4
      }
      @media (min-width:768px){
          .lead{
              font-size:21px
          }
      }
      .small,small{
          font-size:85%
      }
      .mark,mark{
          padding:.2em;
          background-color:#fcf8e3
      }
      .text-left{
          text-align:left
      }
      .text-right{
          text-align:right
      }
      .text-center{
          text-align:center
      }
      .text-justify{
          text-align:justify
      }
      .text-nowrap{
          white-space:nowrap
      }
      .text-lowercase{
          text-transform:lowercase
      }
      .text-uppercase{
          text-transform:uppercase
      }
      .text-capitalize{
          text-transform:capitalize
      }
      .text-muted{
          color:#777
      }
      .text-primary{
          color:#337ab7
      }
      a.text-primary:focus,a.text-primary:hover{
          color:#286090
      }
      .text-success{
          color:#3c763d
      }
      a.text-success:focus,a.text-success:hover{
          color:#2b542c
      }
      .text-info{
          color:#31708f
      }
      a.text-info:focus,a.text-info:hover{
          color:#245269
      }
      .text-warning{
          color:#8a6d3b
      }
      a.text-warning:focus,a.text-warning:hover{
          color:#66512c
      }
      .text-danger{
          color:#a94442
      }
      a.text-danger:focus,a.text-danger:hover{
          color:#843534
      }
      .bg-primary{
          color:#fff;
          background-color:#337ab7
      }
      a.bg-primary:focus,a.bg-primary:hover{
          background-color:#286090
      }
      .bg-success{
          background-color:#dff0d8
      }
      a.bg-success:focus,a.bg-success:hover{
          background-color:#c1e2b3
      }
      .bg-info{
          background-color:#d9edf7
      }
      a.bg-info:focus,a.bg-info:hover{
          background-color:#afd9ee
      }
      .bg-warning{
          background-color:#fcf8e3
      }
      a.bg-warning:focus,a.bg-warning:hover{
          background-color:#f7ecb5
      }
      .bg-danger{
          background-color:#f2dede
      }
      a.bg-danger:focus,a.bg-danger:hover{
          background-color:#e4b9b9
      }
      .page-header{
          padding-bottom:9px;
          margin:40px 0 20px;
          border-bottom:1px solid #eee
      }
      ol,ul{
          margin-top:0;
          margin-bottom:10px
      }
      ol ol,ol ul,ul ol,ul ul{
          margin-bottom:0
      }
      .list-unstyled{
          padding-left:0;
          list-style:none
      }
      .list-inline{
          padding-left:0;
          margin-left:-5px;
          list-style:none
      }
      .list-inline>li{
          display:inline-block;
          padding-right:5px;
          padding-left:5px
      }
      dl{
          margin-top:0;
          margin-bottom:20px
      }
      dd,dt{
          line-height:1.42857143
      }
      dt{
          font-weight:700
      }
      dd{
          margin-left:0
      }
      @media (min-width:768px){
          .dl-horizontal dt{
              float:left;
              width:160px;
              overflow:hidden;
              clear:left;
              text-align:right;
              text-overflow:ellipsis;
              white-space:nowrap
          }
          .dl-horizontal dd{
              margin-left:180px
          }
      }
      abbr[data-original-title],abbr[title]{
          cursor:help;
          border-bottom:1px dotted #777
      }
      .initialism{
          font-size:90%;
          text-transform:uppercase
      }
      blockquote{
          padding:10px 20px;
          margin:0 0 20px;
          font-size:17.5px;
          border-left:5px solid #eee
      }
      blockquote ol:last-child,blockquote p:last-child,blockquote ul:last-child{
          margin-bottom:0
      }
      blockquote .small,blockquote footer,blockquote small{
          display:block;
          font-size:80%;
          line-height:1.42857143;
          color:#777
      }
      blockquote .small:before,blockquote footer:before,blockquote small:before{
          content:'\2014 \00A0'
      }
      .blockquote-reverse,blockquote.pull-right{
          padding-right:15px;
          padding-left:0;
          text-align:right;
          border-right:5px solid #eee;
          border-left:0
      }
      .blockquote-reverse .small:before,.blockquote-reverse footer:before,.blockquote-reverse small:before,blockquote.pull-right .small:before,blockquote.pull-right footer:before,blockquote.pull-right small:before{
          content:''
      }
      .blockquote-reverse .small:after,.blockquote-reverse footer:after,.blockquote-reverse small:after,blockquote.pull-right .small:after,blockquote.pull-right footer:after,blockquote.pull-right small:after{
          content:'\00A0 \2014'
      }
      address{
          margin-bottom:20px;
          font-style:normal;
          line-height:1.42857143
      }
      code,kbd,pre,samp{
          font-family:Menlo,Monaco,Consolas,"Courier New",monospace
      }
      code{
          padding:2px 4px;
          font-size:90%;
          color:#c7254e;
          background-color:#f9f2f4;
          border-radius:4px
      }
      kbd{
          padding:2px 4px;
          font-size:90%;
          color:#fff;
          background-color:#333;
          border-radius:3px;
          -webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,.25);
          box-shadow:inset 0 -1px 0 rgba(0,0,0,.25)
      }
      kbd kbd{
          padding:0;
          font-size:100%;
          font-weight:700;
          -webkit-box-shadow:none;
          box-shadow:none
      }
      pre{
          display:block;
          padding:9.5px;
          margin:0 0 10px;
          font-size:13px;
          line-height:1.42857143;
          color:#333;
          word-break:break-all;
          word-wrap:break-word;
          background-color:#f5f5f5;
          border:1px solid #ccc;
          border-radius:4px
      }
      pre code{
          padding:0;
          font-size:inherit;
          color:inherit;
          white-space:pre-wrap;
          background-color:transparent;
          border-radius:0
      }
      .pre-scrollable{
          max-height:340px;
          overflow-y:scroll
      }
      .container{
          padding-right:15px;
          padding-left:15px;
          margin-right:auto;
          margin-left:auto
      }
      @media (min-width:768px){
          .container{
              width:750px
          }
      }
      @media (min-width:992px){
          .container{
              width:970px
          }
      }
      @media (min-width:1200px){
          .container{
              width:1170px
          }
      }
      .container-fluid{
          padding-right:15px;
          padding-left:15px;
          margin-right:auto;
          margin-left:auto
      }
      .row{
          margin-right:-15px;
          margin-left:-15px
      }
      .col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-xs-1,.col-xs-10,.col-xs-11,.col-xs-12,.col-xs-2,.col-xs-3,.col-xs-4,.col-xs-5,.col-xs-6,.col-xs-7,.col-xs-8,.col-xs-9{
          position:relative;
          min-height:1px;
          padding-right:15px;
          padding-left:15px
      }
      .col-xs-1,.col-xs-10,.col-xs-11,.col-xs-12,.col-xs-2,.col-xs-3,.col-xs-4,.col-xs-5,.col-xs-6,.col-xs-7,.col-xs-8,.col-xs-9{
          float:left
      }
      .col-xs-12{
          width:100%
      }
      .col-xs-11{
          width:91.66666667%
      }
      .col-xs-10{
          width:83.33333333%
      }
      .col-xs-9{
          width:75%
      }
      .col-xs-8{
          width:66.66666667%
      }
      .col-xs-7{
          width:58.33333333%
      }
      .col-xs-6{
          width:50%
      }
      .col-xs-5{
          width:41.66666667%
      }
      .col-xs-4{
          width:33.33333333%
      }
      .col-xs-3{
          width:25%
      }
      .col-xs-2{
          width:16.66666667%
      }
      .col-xs-1{
          width:8.33333333%
      }
      .col-xs-pull-12{
          right:100%
      }
      .col-xs-pull-11{
          right:91.66666667%
      }
      .col-xs-pull-10{
          right:83.33333333%
      }
      .col-xs-pull-9{
          right:75%
      }
      .col-xs-pull-8{
          right:66.66666667%
      }
      .col-xs-pull-7{
          right:58.33333333%
      }
      .col-xs-pull-6{
          right:50%
      }
      .col-xs-pull-5{
          right:41.66666667%
      }
      .col-xs-pull-4{
          right:33.33333333%
      }
      .col-xs-pull-3{
          right:25%
      }
      .col-xs-pull-2{
          right:16.66666667%
      }
      .col-xs-pull-1{
          right:8.33333333%
      }
      .col-xs-pull-0{
          right:auto
      }
      .col-xs-push-12{
          left:100%
      }
      .col-xs-push-11{
          left:91.66666667%
      }
      .col-xs-push-10{
          left:83.33333333%
      }
      .col-xs-push-9{
          left:75%
      }
      .col-xs-push-8{
          left:66.66666667%
      }
      .col-xs-push-7{
          left:58.33333333%
      }
      .col-xs-push-6{
          left:50%
      }
      .col-xs-push-5{
          left:41.66666667%
      }
      .col-xs-push-4{
          left:33.33333333%
      }
      .col-xs-push-3{
          left:25%
      }
      .col-xs-push-2{
          left:16.66666667%
      }
      .col-xs-push-1{
          left:8.33333333%
      }
      .col-xs-push-0{
          left:auto
      }
      .col-xs-offset-12{
          margin-left:100%
      }
      .col-xs-offset-11{
          margin-left:91.66666667%
      }
      .col-xs-offset-10{
          margin-left:83.33333333%
      }
      .col-xs-offset-9{
          margin-left:75%
      }
      .col-xs-offset-8{
          margin-left:66.66666667%
      }
      .col-xs-offset-7{
          margin-left:58.33333333%
      }
      .col-xs-offset-6{
          margin-left:50%
      }
      .col-xs-offset-5{
          margin-left:41.66666667%
      }
      .col-xs-offset-4{
          margin-left:33.33333333%
      }
      .col-xs-offset-3{
          margin-left:25%
      }
      .col-xs-offset-2{
          margin-left:16.66666667%
      }
      .col-xs-offset-1{
          margin-left:8.33333333%
      }
      .col-xs-offset-0{
          margin-left:0
      }
      @media (min-width:768px){
          .col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9{
              float:left
          }
          .col-sm-12{
              width:100%
          }
          .col-sm-11{
              width:91.66666667%
          }
          .col-sm-10{
              width:83.33333333%
          }
          .col-sm-9{
              width:75%
          }
          .col-sm-8{
              width:66.66666667%
          }
          .col-sm-7{
              width:58.33333333%
          }
          .col-sm-6{
              width:50%
          }
          .col-sm-5{
              width:41.66666667%
          }
          .col-sm-4{
              width:33.33333333%
          }
          .col-sm-3{
              width:25%
          }
          .col-sm-2{
              width:16.66666667%
          }
          .col-sm-1{
              width:8.33333333%
          }
          .col-sm-pull-12{
              right:100%
          }
          .col-sm-pull-11{
              right:91.66666667%
          }
          .col-sm-pull-10{
              right:83.33333333%
          }
          .col-sm-pull-9{
              right:75%
          }
          .col-sm-pull-8{
              right:66.66666667%
          }
          .col-sm-pull-7{
              right:58.33333333%
          }
          .col-sm-pull-6{
              right:50%
          }
          .col-sm-pull-5{
              right:41.66666667%
          }
          .col-sm-pull-4{
              right:33.33333333%
          }
          .col-sm-pull-3{
              right:25%
          }
          .col-sm-pull-2{
              right:16.66666667%
          }
          .col-sm-pull-1{
              right:8.33333333%
          }
          .col-sm-pull-0{
              right:auto
          }
          .col-sm-push-12{
              left:100%
          }
          .col-sm-push-11{
              left:91.66666667%
          }
          .col-sm-push-10{
              left:83.33333333%
          }
          .col-sm-push-9{
              left:75%
          }
          .col-sm-push-8{
              left:66.66666667%
          }
          .col-sm-push-7{
              left:58.33333333%
          }
          .col-sm-push-6{
              left:50%
          }
          .col-sm-push-5{
              left:41.66666667%
          }
          .col-sm-push-4{
              left:33.33333333%
          }
          .col-sm-push-3{
              left:25%
          }
          .col-sm-push-2{
              left:16.66666667%
          }
          .col-sm-push-1{
              left:8.33333333%
          }
          .col-sm-push-0{
              left:auto
          }
          .col-sm-offset-12{
              margin-left:100%
          }
          .col-sm-offset-11{
              margin-left:91.66666667%
          }
          .col-sm-offset-10{
              margin-left:83.33333333%
          }
          .col-sm-offset-9{
              margin-left:75%
          }
          .col-sm-offset-8{
              margin-left:66.66666667%
          }
          .col-sm-offset-7{
              margin-left:58.33333333%
          }
          .col-sm-offset-6{
              margin-left:50%
          }
          .col-sm-offset-5{
              margin-left:41.66666667%
          }
          .col-sm-offset-4{
              margin-left:33.33333333%
          }
          .col-sm-offset-3{
              margin-left:25%
          }
          .col-sm-offset-2{
              margin-left:16.66666667%
          }
          .col-sm-offset-1{
              margin-left:8.33333333%
          }
          .col-sm-offset-0{
              margin-left:0
          }
      }
      @media (min-width:992px){
          .col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9{
              float:left
          }
          .col-md-12{
              width:100%
          }
          .col-md-11{
              width:91.66666667%
          }
          .col-md-10{
              width:83.33333333%
          }
          .col-md-9{
              width:75%
          }
          .col-md-8{
              width:66.66666667%
          }
          .col-md-7{
              width:58.33333333%
          }
          .col-md-6{
              width:50%
          }
          .col-md-5{
              width:41.66666667%
          }
          .col-md-4{
              width:33.33333333%
          }
          .col-md-3{
              width:25%
          }
          .col-md-2{
              width:16.66666667%
          }
          .col-md-1{
              width:8.33333333%
          }
          .col-md-pull-12{
              right:100%
          }
          .col-md-pull-11{
              right:91.66666667%
          }
          .col-md-pull-10{
              right:83.33333333%
          }
          .col-md-pull-9{
              right:75%
          }
          .col-md-pull-8{
              right:66.66666667%
          }
          .col-md-pull-7{
              right:58.33333333%
          }
          .col-md-pull-6{
              right:50%
          }
          .col-md-pull-5{
              right:41.66666667%
          }
          .col-md-pull-4{
              right:33.33333333%
          }
          .col-md-pull-3{
              right:25%
          }
          .col-md-pull-2{
              right:16.66666667%
          }
          .col-md-pull-1{
              right:8.33333333%
          }
          .col-md-pull-0{
              right:auto
          }
          .col-md-push-12{
              left:100%
          }
          .col-md-push-11{
              left:91.66666667%
          }
          .col-md-push-10{
              left:83.33333333%
          }
          .col-md-push-9{
              left:75%
          }
          .col-md-push-8{
              left:66.66666667%
          }
          .col-md-push-7{
              left:58.33333333%
          }
          .col-md-push-6{
              left:50%
          }
          .col-md-push-5{
              left:41.66666667%
          }
          .col-md-push-4{
              left:33.33333333%
          }
          .col-md-push-3{
              left:25%
          }
          .col-md-push-2{
              left:16.66666667%
          }
          .col-md-push-1{
              left:8.33333333%
          }
          .col-md-push-0{
              left:auto
          }
          .col-md-offset-12{
              margin-left:100%
          }
          .col-md-offset-11{
              margin-left:91.66666667%
          }
          .col-md-offset-10{
              margin-left:83.33333333%
          }
          .col-md-offset-9{
              margin-left:75%
          }
          .col-md-offset-8{
              margin-left:66.66666667%
          }
          .col-md-offset-7{
              margin-left:58.33333333%
          }
          .col-md-offset-6{
              margin-left:50%
          }
          .col-md-offset-5{
              margin-left:41.66666667%
          }
          .col-md-offset-4{
              margin-left:33.33333333%
          }
          .col-md-offset-3{
              margin-left:25%
          }
          .col-md-offset-2{
              margin-left:16.66666667%
          }
          .col-md-offset-1{
              margin-left:8.33333333%
          }
          .col-md-offset-0{
              margin-left:0
          }
      }
      @media (min-width:1200px){
          .col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9{
              float:left
          }
          .col-lg-12{
              width:100%
          }
          .col-lg-11{
              width:91.66666667%
          }
          .col-lg-10{
              width:83.33333333%
          }
          .col-lg-9{
              width:75%
          }
          .col-lg-8{
              width:66.66666667%
          }
          .col-lg-7{
              width:58.33333333%
          }
          .col-lg-6{
              width:50%
          }
          .col-lg-5{
              width:41.66666667%
          }
          .col-lg-4{
              width:33.33333333%
          }
          .col-lg-3{
              width:25%
          }
          .col-lg-2{
              width:16.66666667%
          }
          .col-lg-1{
              width:8.33333333%
          }
          .col-lg-pull-12{
              right:100%
          }
          .col-lg-pull-11{
              right:91.66666667%
          }
          .col-lg-pull-10{
              right:83.33333333%
          }
          .col-lg-pull-9{
              right:75%
          }
          .col-lg-pull-8{
              right:66.66666667%
          }
          .col-lg-pull-7{
              right:58.33333333%
          }
          .col-lg-pull-6{
              right:50%
          }
          .col-lg-pull-5{
              right:41.66666667%
          }
          .col-lg-pull-4{
              right:33.33333333%
          }
          .col-lg-pull-3{
              right:25%
          }
          .col-lg-pull-2{
              right:16.66666667%
          }
          .col-lg-pull-1{
              right:8.33333333%
          }
          .col-lg-pull-0{
              right:auto
          }
          .col-lg-push-12{
              left:100%
          }
          .col-lg-push-11{
              left:91.66666667%
          }
          .col-lg-push-10{
              left:83.33333333%
          }
          .col-lg-push-9{
              left:75%
          }
          .col-lg-push-8{
              left:66.66666667%
          }
          .col-lg-push-7{
              left:58.33333333%
          }
          .col-lg-push-6{
              left:50%
          }
          .col-lg-push-5{
              left:41.66666667%
          }
          .col-lg-push-4{
              left:33.33333333%
          }
          .col-lg-push-3{
              left:25%
          }
          .col-lg-push-2{
              left:16.66666667%
          }
          .col-lg-push-1{
              left:8.33333333%
          }
          .col-lg-push-0{
              left:auto
          }
          .col-lg-offset-12{
              margin-left:100%
          }
          .col-lg-offset-11{
              margin-left:91.66666667%
          }
          .col-lg-offset-10{
              margin-left:83.33333333%
          }
          .col-lg-offset-9{
              margin-left:75%
          }
          .col-lg-offset-8{
              margin-left:66.66666667%
          }
          .col-lg-offset-7{
              margin-left:58.33333333%
          }
          .col-lg-offset-6{
              margin-left:50%
          }
          .col-lg-offset-5{
              margin-left:41.66666667%
          }
          .col-lg-offset-4{
              margin-left:33.33333333%
          }
          .col-lg-offset-3{
              margin-left:25%
          }
          .col-lg-offset-2{
              margin-left:16.66666667%
          }
          .col-lg-offset-1{
              margin-left:8.33333333%
          }
          .col-lg-offset-0{
              margin-left:0
          }
      }
      table{
          background-color:transparent
      }
      caption{
          padding-top:8px;
          padding-bottom:8px;
          color:#777;
          text-align:left
      }
      th{
          text-align:left
      }
      .table{
          width:100%;
          max-width:100%;
          margin-bottom:20px
      }
      .table>tbody>tr>td,.table>tbody>tr>th,.table>tfoot>tr>td,.table>tfoot>tr>th,.table>thead>tr>td,.table>thead>tr>th{
          padding:8px;
          line-height:1.42857143;
          vertical-align:top;
          border-top:1px solid #ddd
      }
      .table>thead>tr>th{
          vertical-align:bottom;
          border-bottom:2px solid #ddd
      }
      .table>caption+thead>tr:first-child>td,.table>caption+thead>tr:first-child>th,.table>colgroup+thead>tr:first-child>td,.table>colgroup+thead>tr:first-child>th,.table>thead:first-child>tr:first-child>td,.table>thead:first-child>tr:first-child>th{
          border-top:0
      }
      .table>tbody+tbody{
          border-top:2px solid #ddd
      }
      .table .table{
          background-color:#fff
      }
      .table-condensed>tbody>tr>td,.table-condensed>tbody>tr>th,.table-condensed>tfoot>tr>td,.table-condensed>tfoot>tr>th,.table-condensed>thead>tr>td,.table-condensed>thead>tr>th{
          padding:5px
      }
      .table-bordered{
          border:1px solid #ddd
      }
      .table-bordered>tbody>tr>td,.table-bordered>tbody>tr>th,.table-bordered>tfoot>tr>td,.table-bordered>tfoot>tr>th,.table-bordered>thead>tr>td,.table-bordered>thead>tr>th{
          border:1px solid #ddd
      }
      .table-bordered>thead>tr>td,.table-bordered>thead>tr>th{
          border-bottom-width:2px
      }
      .table-striped>tbody>tr:nth-of-type(odd){
          background-color:#f9f9f9
      }
      .table-hover>tbody>tr:hover{
          background-color:#f5f5f5
      }
      table col[class*=col-]{
          position:static;
          display:table-column;
          float:none
      }
      table td[class*=col-],table th[class*=col-]{
          position:static;
          display:table-cell;
          float:none
      }
      .table>tbody>tr.active>td,.table>tbody>tr.active>th,.table>tbody>tr>td.active,.table>tbody>tr>th.active,.table>tfoot>tr.active>td,.table>tfoot>tr.active>th,.table>tfoot>tr>td.active,.table>tfoot>tr>th.active,.table>thead>tr.active>td,.table>thead>tr.active>th,.table>thead>tr>td.active,.table>thead>tr>th.active{
          background-color:#f5f5f5
      }
      .table-hover>tbody>tr.active:hover>td,.table-hover>tbody>tr.active:hover>th,.table-hover>tbody>tr:hover>.active,.table-hover>tbody>tr>td.active:hover,.table-hover>tbody>tr>th.active:hover{
          background-color:#e8e8e8
      }
      .table>tbody>tr.success>td,.table>tbody>tr.success>th,.table>tbody>tr>td.success,.table>tbody>tr>th.success,.table>tfoot>tr.success>td,.table>tfoot>tr.success>th,.table>tfoot>tr>td.success,.table>tfoot>tr>th.success,.table>thead>tr.success>td,.table>thead>tr.success>th,.table>thead>tr>td.success,.table>thead>tr>th.success{
          background-color:#dff0d8
      }
      .table-hover>tbody>tr.success:hover>td,.table-hover>tbody>tr.success:hover>th,.table-hover>tbody>tr:hover>.success,.table-hover>tbody>tr>td.success:hover,.table-hover>tbody>tr>th.success:hover{
          background-color:#d0e9c6
      }
      .table>tbody>tr.info>td,.table>tbody>tr.info>th,.table>tbody>tr>td.info,.table>tbody>tr>th.info,.table>tfoot>tr.info>td,.table>tfoot>tr.info>th,.table>tfoot>tr>td.info,.table>tfoot>tr>th.info,.table>thead>tr.info>td,.table>thead>tr.info>th,.table>thead>tr>td.info,.table>thead>tr>th.info{
          background-color:#d9edf7
      }
      .table-hover>tbody>tr.info:hover>td,.table-hover>tbody>tr.info:hover>th,.table-hover>tbody>tr:hover>.info,.table-hover>tbody>tr>td.info:hover,.table-hover>tbody>tr>th.info:hover{
          background-color:#c4e3f3
      }
      .table>tbody>tr.warning>td,.table>tbody>tr.warning>th,.table>tbody>tr>td.warning,.table>tbody>tr>th.warning,.table>tfoot>tr.warning>td,.table>tfoot>tr.warning>th,.table>tfoot>tr>td.warning,.table>tfoot>tr>th.warning,.table>thead>tr.warning>td,.table>thead>tr.warning>th,.table>thead>tr>td.warning,.table>thead>tr>th.warning{
          background-color:#fcf8e3
      }
      .table-hover>tbody>tr.warning:hover>td,.table-hover>tbody>tr.warning:hover>th,.table-hover>tbody>tr:hover>.warning,.table-hover>tbody>tr>td.warning:hover,.table-hover>tbody>tr>th.warning:hover{
          background-color:#faf2cc
      }
      .table>tbody>tr.danger>td,.table>tbody>tr.danger>th,.table>tbody>tr>td.danger,.table>tbody>tr>th.danger,.table>tfoot>tr.danger>td,.table>tfoot>tr.danger>th,.table>tfoot>tr>td.danger,.table>tfoot>tr>th.danger,.table>thead>tr.danger>td,.table>thead>tr.danger>th,.table>thead>tr>td.danger,.table>thead>tr>th.danger{
          background-color:#f2dede
      }
      .table-hover>tbody>tr.danger:hover>td,.table-hover>tbody>tr.danger:hover>th,.table-hover>tbody>tr:hover>.danger,.table-hover>tbody>tr>td.danger:hover,.table-hover>tbody>tr>th.danger:hover{
          background-color:#ebcccc
      }
      .table-responsive{
          min-height:.01%;
          overflow-x:auto
      }
      @media screen and (max-width:767px){
          .table-responsive{
              width:100%;
              margin-bottom:15px;
              overflow-y:hidden;
              -ms-overflow-style:-ms-autohiding-scrollbar;
              border:1px solid #ddd
          }
          .table-responsive>.table{
              margin-bottom:0
          }
          .table-responsive>.table>tbody>tr>td,.table-responsive>.table>tbody>tr>th,.table-responsive>.table>tfoot>tr>td,.table-responsive>.table>tfoot>tr>th,.table-responsive>.table>thead>tr>td,.table-responsive>.table>thead>tr>th{
              white-space:nowrap
          }
          .table-responsive>.table-bordered{
              border:0
          }
          .table-responsive>.table-bordered>tbody>tr>td:first-child,.table-responsive>.table-bordered>tbody>tr>th:first-child,.table-responsive>.table-bordered>tfoot>tr>td:first-child,.table-responsive>.table-bordered>tfoot>tr>th:first-child,.table-responsive>.table-bordered>thead>tr>td:first-child,.table-responsive>.table-bordered>thead>tr>th:first-child{
              border-left:0
          }
          .table-responsive>.table-bordered>tbody>tr>td:last-child,.table-responsive>.table-bordered>tbody>tr>th:last-child,.table-responsive>.table-bordered>tfoot>tr>td:last-child,.table-responsive>.table-bordered>tfoot>tr>th:last-child,.table-responsive>.table-bordered>thead>tr>td:last-child,.table-responsive>.table-bordered>thead>tr>th:last-child{
              border-right:0
          }
          .table-responsive>.table-bordered>tbody>tr:last-child>td,.table-responsive>.table-bordered>tbody>tr:last-child>th,.table-responsive>.table-bordered>tfoot>tr:last-child>td,.table-responsive>.table-bordered>tfoot>tr:last-child>th{
              border-bottom:0
          }
      }
      fieldset{
          min-width:0;
          padding:0;
          margin:0;
          border:0
      }
      legend{
          display:block;
          width:100%;
          padding:0;
          margin-bottom:20px;
          font-size:21px;
          line-height:inherit;
          color:#333;
          border:0;
          border-bottom:1px solid #e5e5e5
      }
      label{
          display:inline-block;
          max-width:100%;
          margin-bottom:5px;
          font-weight:700
      }
      input[type=search]{
          -webkit-box-sizing:border-box;
          -moz-box-sizing:border-box;
          box-sizing:border-box
      }
      input[type=checkbox],input[type=radio]{
          margin:4px 0 0;
          margin-top:1px\9;
          line-height:normal
      }
      input[type=file]{
          display:block
      }
      input[type=range]{
          display:block;
          width:100%
      }
      select[multiple],select[size]{
          height:auto
      }
      input[type=file]:focus,input[type=checkbox]:focus,input[type=radio]:focus{
          outline:thin dotted;
          outline:5px auto -webkit-focus-ring-color;
          outline-offset:-2px
      }
      output{
          display:block;
          padding-top:7px;
          font-size:14px;
          line-height:1.42857143;
          color:#555
      }
      .form-control{
          display:block;
          width:100%;
          height:34px;
          padding:6px 12px;
          font-size:14px;
          line-height:1.42857143;
          color:#555;
          background-color:#fff;
          background-image:none;
          border:1px solid #ccc;
          border-radius:4px;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075);
          -webkit-transition:border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
          -o-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;
          transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s
      }
      .form-control:focus{
          border-color:#66afe9;
          outline:0;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6)
      }
      .form-control::-moz-placeholder{
          color:#999;
          opacity:1
      }
      .form-control:-ms-input-placeholder{
          color:#999
      }
      .form-control::-webkit-input-placeholder{
          color:#999
      }
      .form-control::-ms-expand{
          background-color:transparent;
          border:0
      }
      .form-control[disabled],.form-control[readonly],fieldset[disabled] .form-control{
          background-color:#eee;
          opacity:1
      }
      .form-control[disabled],fieldset[disabled] .form-control{
          cursor:not-allowed
      }
      textarea.form-control{
          height:auto
      }
      input[type=search]{
          -webkit-appearance:none
      }
      @media screen and (-webkit-min-device-pixel-ratio:0){
          input[type=date].form-control,input[type=time].form-control,input[type=datetime-local].form-control,input[type=month].form-control{
              line-height:34px
          }
          .input-group-sm input[type=date],.input-group-sm input[type=time],.input-group-sm input[type=datetime-local],.input-group-sm input[type=month],input[type=date].input-sm,input[type=time].input-sm,input[type=datetime-local].input-sm,input[type=month].input-sm{
              line-height:30px
          }
          .input-group-lg input[type=date],.input-group-lg input[type=time],.input-group-lg input[type=datetime-local],.input-group-lg input[type=month],input[type=date].input-lg,input[type=time].input-lg,input[type=datetime-local].input-lg,input[type=month].input-lg{
              line-height:46px
          }
      }
      .form-group{
          margin-bottom:15px
      }
      .checkbox,.radio{
          position:relative;
          display:block;
          margin-top:10px;
          margin-bottom:10px
      }
      .checkbox label,.radio label{
          min-height:20px;
          padding-left:20px;
          margin-bottom:0;
          font-weight:400;
          cursor:pointer
      }
      .checkbox input[type=checkbox],.checkbox-inline input[type=checkbox],.radio input[type=radio],.radio-inline input[type=radio]{
          position:absolute;
          margin-top:4px\9;
          margin-left:-20px
      }
      .checkbox+.checkbox,.radio+.radio{
          margin-top:-5px
      }
      .checkbox-inline,.radio-inline{
          position:relative;
          display:inline-block;
          padding-left:20px;
          margin-bottom:0;
          font-weight:400;
          vertical-align:middle;
          cursor:pointer
      }
      .checkbox-inline+.checkbox-inline,.radio-inline+.radio-inline{
          margin-top:0;
          margin-left:10px
      }
      fieldset[disabled] input[type=checkbox],fieldset[disabled] input[type=radio],input[type=checkbox].disabled,input[type=checkbox][disabled],input[type=radio].disabled,input[type=radio][disabled]{
          cursor:not-allowed
      }
      .checkbox-inline.disabled,.radio-inline.disabled,fieldset[disabled] .checkbox-inline,fieldset[disabled] .radio-inline{
          cursor:not-allowed
      }
      .checkbox.disabled label,.radio.disabled label,fieldset[disabled] .checkbox label,fieldset[disabled] .radio label{
          cursor:not-allowed
      }
      .form-control-static{
          min-height:34px;
          padding-top:7px;
          padding-bottom:7px;
          margin-bottom:0
      }
      .form-control-static.input-lg,.form-control-static.input-sm{
          padding-right:0;
          padding-left:0
      }
      .input-sm{
          height:30px;
          padding:5px 10px;
          font-size:12px;
          line-height:1.5;
          border-radius:3px
      }
      select.input-sm{
          height:30px;
          line-height:30px
      }
      select[multiple].input-sm,textarea.input-sm{
          height:auto
      }
      .form-group-sm .form-control{
          height:30px;
          padding:5px 10px;
          font-size:12px;
          line-height:1.5;
          border-radius:3px
      }
      .form-group-sm select.form-control{
          height:30px;
          line-height:30px
      }
      .form-group-sm select[multiple].form-control,.form-group-sm textarea.form-control{
          height:auto
      }
      .form-group-sm .form-control-static{
          height:30px;
          min-height:32px;
          padding:6px 10px;
          font-size:12px;
          line-height:1.5
      }
      .input-lg{
          height:46px;
          padding:10px 16px;
          font-size:18px;
          line-height:1.3333333;
          border-radius:6px
      }
      select.input-lg{
          height:46px;
          line-height:46px
      }
      select[multiple].input-lg,textarea.input-lg{
          height:auto
      }
      .form-group-lg .form-control{
          height:46px;
          padding:10px 16px;
          font-size:18px;
          line-height:1.3333333;
          border-radius:6px
      }
      .form-group-lg select.form-control{
          height:46px;
          line-height:46px
      }
      .form-group-lg select[multiple].form-control,.form-group-lg textarea.form-control{
          height:auto
      }
      .form-group-lg .form-control-static{
          height:46px;
          min-height:38px;
          padding:11px 16px;
          font-size:18px;
          line-height:1.3333333
      }
      .has-feedback{
          position:relative
      }
      .has-feedback .form-control{
          padding-right:42.5px
      }
      .form-control-feedback{
          position:absolute;
          top:0;
          right:0;
          z-index:2;
          display:block;
          width:34px;
          height:34px;
          line-height:34px;
          text-align:center;
          pointer-events:none
      }
      .form-group-lg .form-control+.form-control-feedback,.input-group-lg+.form-control-feedback,.input-lg+.form-control-feedback{
          width:46px;
          height:46px;
          line-height:46px
      }
      .form-group-sm .form-control+.form-control-feedback,.input-group-sm+.form-control-feedback,.input-sm+.form-control-feedback{
          width:30px;
          height:30px;
          line-height:30px
      }
      .has-success .checkbox,.has-success .checkbox-inline,.has-success .control-label,.has-success .help-block,.has-success .radio,.has-success .radio-inline,.has-success.checkbox label,.has-success.checkbox-inline label,.has-success.radio label,.has-success.radio-inline label{
          color:#3c763d
      }
      .has-success .form-control{
          border-color:#3c763d;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075)
      }
      .has-success .form-control:focus{
          border-color:#2b542c;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #67b168;
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #67b168
      }
      .has-success .input-group-addon{
          color:#3c763d;
          background-color:#dff0d8;
          border-color:#3c763d
      }
      .has-success .form-control-feedback{
          color:#3c763d
      }
      .has-warning .checkbox,.has-warning .checkbox-inline,.has-warning .control-label,.has-warning .help-block,.has-warning .radio,.has-warning .radio-inline,.has-warning.checkbox label,.has-warning.checkbox-inline label,.has-warning.radio label,.has-warning.radio-inline label{
          color:#8a6d3b
      }
      .has-warning .form-control{
          border-color:#8a6d3b;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075)
      }
      .has-warning .form-control:focus{
          border-color:#66512c;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #c0a16b;
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #c0a16b
      }
      .has-warning .input-group-addon{
          color:#8a6d3b;
          background-color:#fcf8e3;
          border-color:#8a6d3b
      }
      .has-warning .form-control-feedback{
          color:#8a6d3b
      }
      .has-error .checkbox,.has-error .checkbox-inline,.has-error .control-label,.has-error .help-block,.has-error .radio,.has-error .radio-inline,.has-error.checkbox label,.has-error.checkbox-inline label,.has-error.radio label,.has-error.radio-inline label{
          color:#a94442
      }
      .has-error .form-control{
          border-color:#a94442;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075)
      }
      .has-error .form-control:focus{
          border-color:#843534;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #ce8483;
          box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #ce8483
      }
      .has-error .input-group-addon{
          color:#a94442;
          background-color:#f2dede;
          border-color:#a94442
      }
      .has-error .form-control-feedback{
          color:#a94442
      }
      .has-feedback label~.form-control-feedback{
          top:25px
      }
      .has-feedback label.sr-only~.form-control-feedback{
          top:0
      }
      .help-block{
          display:block;
          margin-top:5px;
          margin-bottom:10px;
          color:#737373
      }
      @media (min-width:768px){
          .form-inline .form-group{
              display:inline-block;
              margin-bottom:0;
              vertical-align:middle
          }
          .form-inline .form-control{
              display:inline-block;
              width:auto;
              vertical-align:middle
          }
          .form-inline .form-control-static{
              display:inline-block
          }
          .form-inline .input-group{
              display:inline-table;
              vertical-align:middle
          }
          .form-inline .input-group .form-control,.form-inline .input-group .input-group-addon,.form-inline .input-group .input-group-btn{
              width:auto
          }
          .form-inline .input-group>.form-control{
              width:100%
          }
          .form-inline .control-label{
              margin-bottom:0;
              vertical-align:middle
          }
          .form-inline .checkbox,.form-inline .radio{
              display:inline-block;
              margin-top:0;
              margin-bottom:0;
              vertical-align:middle
          }
          .form-inline .checkbox label,.form-inline .radio label{
              padding-left:0
          }
          .form-inline .checkbox input[type=checkbox],.form-inline .radio input[type=radio]{
              position:relative;
              margin-left:0
          }
          .form-inline .has-feedback .form-control-feedback{
              top:0
          }
      }
      .form-horizontal .checkbox,.form-horizontal .checkbox-inline,.form-horizontal .radio,.form-horizontal .radio-inline{
          padding-top:7px;
          margin-top:0;
          margin-bottom:0
      }
      .form-horizontal .checkbox,.form-horizontal .radio{
          min-height:27px
      }
      .form-horizontal .form-group{
          margin-right:-15px;
          margin-left:-15px
      }
      @media (min-width:768px){
          .form-horizontal .control-label{
              padding-top:7px;
              margin-bottom:0;
              text-align:right
          }
      }
      .form-horizontal .has-feedback .form-control-feedback{
          right:15px
      }
      @media (min-width:768px){
          .form-horizontal .form-group-lg .control-label{
              padding-top:11px;
              font-size:18px
          }
      }
      @media (min-width:768px){
          .form-horizontal .form-group-sm .control-label{
              padding-top:6px;
              font-size:12px
          }
      }
      .btn{
          display:inline-block;
          padding:6px 12px;
          margin-bottom:0;
          font-size:14px;
          font-weight:400;
          line-height:1.42857143;
          text-align:center;
          white-space:nowrap;
          vertical-align:middle;
          -ms-touch-action:manipulation;
          touch-action:manipulation;
          cursor:pointer;
          -webkit-user-select:none;
          -moz-user-select:none;
          -ms-user-select:none;
          user-select:none;
          background-image:none;
          border:1px solid transparent;
          border-radius:4px
      }
      .btn.active.focus,.btn.active:focus,.btn.focus,.btn:active.focus,.btn:active:focus,.btn:focus{
          outline:thin dotted;
          outline:5px auto -webkit-focus-ring-color;
          outline-offset:-2px
      }
      .btn.focus,.btn:focus,.btn:hover{
          color:#333;
          text-decoration:none
      }
      .btn.active,.btn:active{
          background-image:none;
          outline:0;
          -webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);
          box-shadow:inset 0 3px 5px rgba(0,0,0,.125)
      }
      .btn.disabled,.btn[disabled],fieldset[disabled] .btn{
          cursor:not-allowed;
          filter:alpha(opacity=65);
          -webkit-box-shadow:none;
          box-shadow:none;
          opacity:.65
      }
      a.btn.disabled,fieldset[disabled] a.btn{
          pointer-events:none
      }
      .btn-default{
          color:#333;
          background-color:#fff;
          border-color:#ccc
      }
      .btn-default.focus,.btn-default:focus{
          color:#333;
          background-color:#e6e6e6;
          border-color:#8c8c8c
      }
      .btn-default:hover{
          color:#333;
          background-color:#e6e6e6;
          border-color:#adadad
      }
      .btn-default.active,.btn-default:active,.open>.dropdown-toggle.btn-default{
          color:#333;
          background-color:#e6e6e6;
          border-color:#adadad
      }
      .btn-default.active.focus,.btn-default.active:focus,.btn-default.active:hover,.btn-default:active.focus,.btn-default:active:focus,.btn-default:active:hover,.open>.dropdown-toggle.btn-default.focus,.open>.dropdown-toggle.btn-default:focus,.open>.dropdown-toggle.btn-default:hover{
          color:#333;
          background-color:#d4d4d4;
          border-color:#8c8c8c
      }
      .btn-default.active,.btn-default:active,.open>.dropdown-toggle.btn-default{
          background-image:none
      }
      .btn-default.disabled.focus,.btn-default.disabled:focus,.btn-default.disabled:hover,.btn-default[disabled].focus,.btn-default[disabled]:focus,.btn-default[disabled]:hover,fieldset[disabled] .btn-default.focus,fieldset[disabled] .btn-default:focus,fieldset[disabled] .btn-default:hover{
          background-color:#fff;
          border-color:#ccc
      }
      .btn-default .badge{
          color:#fff;
          background-color:#333
      }
      .btn-primary{
          color:#fff;
          background-color:#337ab7;
          border-color:#2e6da4
      }
      .btn-primary.focus,.btn-primary:focus{
          color:#fff;
          background-color:#286090;
          border-color:#122b40
      }
      .btn-primary:hover{
          color:#fff;
          background-color:#286090;
          border-color:#204d74
      }
      .btn-primary.active,.btn-primary:active,.open>.dropdown-toggle.btn-primary{
          color:#fff;
          background-color:#286090;
          border-color:#204d74
      }
      .btn-primary.active.focus,.btn-primary.active:focus,.btn-primary.active:hover,.btn-primary:active.focus,.btn-primary:active:focus,.btn-primary:active:hover,.open>.dropdown-toggle.btn-primary.focus,.open>.dropdown-toggle.btn-primary:focus,.open>.dropdown-toggle.btn-primary:hover{
          color:#fff;
          background-color:#204d74;
          border-color:#122b40
      }
      .btn-primary.active,.btn-primary:active,.open>.dropdown-toggle.btn-primary{
          background-image:none
      }
      .btn-primary.disabled.focus,.btn-primary.disabled:focus,.btn-primary.disabled:hover,.btn-primary[disabled].focus,.btn-primary[disabled]:focus,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary.focus,fieldset[disabled] .btn-primary:focus,fieldset[disabled] .btn-primary:hover{
          background-color:#337ab7;
          border-color:#2e6da4
      }
      .btn-primary .badge{
          color:#337ab7;
          background-color:#fff
      }
      .btn-success{
          color:#fff;
          background-color:#5cb85c;
          border-color:#4cae4c
      }
      .btn-success.focus,.btn-success:focus{
          color:#fff;
          background-color:#449d44;
          border-color:#255625
      }
      .btn-success:hover{
          color:#fff;
          background-color:#449d44;
          border-color:#398439
      }
      .btn-success.active,.btn-success:active,.open>.dropdown-toggle.btn-success{
          color:#fff;
          background-color:#449d44;
          border-color:#398439
      }
      .btn-success.active.focus,.btn-success.active:focus,.btn-success.active:hover,.btn-success:active.focus,.btn-success:active:focus,.btn-success:active:hover,.open>.dropdown-toggle.btn-success.focus,.open>.dropdown-toggle.btn-success:focus,.open>.dropdown-toggle.btn-success:hover{
          color:#fff;
          background-color:#398439;
          border-color:#255625
      }
      .btn-success.active,.btn-success:active,.open>.dropdown-toggle.btn-success{
          background-image:none
      }
      .btn-success.disabled.focus,.btn-success.disabled:focus,.btn-success.disabled:hover,.btn-success[disabled].focus,.btn-success[disabled]:focus,.btn-success[disabled]:hover,fieldset[disabled] .btn-success.focus,fieldset[disabled] .btn-success:focus,fieldset[disabled] .btn-success:hover{
          background-color:#5cb85c;
          border-color:#4cae4c
      }
      .btn-success .badge{
          color:#5cb85c;
          background-color:#fff
      }
      .btn-info{
          color:#fff;
          background-color:#5bc0de;
          border-color:#46b8da
      }
      .btn-info.focus,.btn-info:focus{
          color:#fff;
          background-color:#31b0d5;
          border-color:#1b6d85
      }
      .btn-info:hover{
          color:#fff;
          background-color:#31b0d5;
          border-color:#269abc
      }
      .btn-info.active,.btn-info:active,.open>.dropdown-toggle.btn-info{
          color:#fff;
          background-color:#31b0d5;
          border-color:#269abc
      }
      .btn-info.active.focus,.btn-info.active:focus,.btn-info.active:hover,.btn-info:active.focus,.btn-info:active:focus,.btn-info:active:hover,.open>.dropdown-toggle.btn-info.focus,.open>.dropdown-toggle.btn-info:focus,.open>.dropdown-toggle.btn-info:hover{
          color:#fff;
          background-color:#269abc;
          border-color:#1b6d85
      }
      .btn-info.active,.btn-info:active,.open>.dropdown-toggle.btn-info{
          background-image:none
      }
      .btn-info.disabled.focus,.btn-info.disabled:focus,.btn-info.disabled:hover,.btn-info[disabled].focus,.btn-info[disabled]:focus,.btn-info[disabled]:hover,fieldset[disabled] .btn-info.focus,fieldset[disabled] .btn-info:focus,fieldset[disabled] .btn-info:hover{
          background-color:#5bc0de;
          border-color:#46b8da
      }
      .btn-info .badge{
          color:#5bc0de;
          background-color:#fff
      }
      .btn-warning{
          color:#fff;
          background-color:#f0ad4e;
          border-color:#eea236
      }
      .btn-warning.focus,.btn-warning:focus{
          color:#fff;
          background-color:#ec971f;
          border-color:#985f0d
      }
      .btn-warning:hover{
          color:#fff;
          background-color:#ec971f;
          border-color:#d58512
      }
      .btn-warning.active,.btn-warning:active,.open>.dropdown-toggle.btn-warning{
          color:#fff;
          background-color:#ec971f;
          border-color:#d58512
      }
      .btn-warning.active.focus,.btn-warning.active:focus,.btn-warning.active:hover,.btn-warning:active.focus,.btn-warning:active:focus,.btn-warning:active:hover,.open>.dropdown-toggle.btn-warning.focus,.open>.dropdown-toggle.btn-warning:focus,.open>.dropdown-toggle.btn-warning:hover{
          color:#fff;
          background-color:#d58512;
          border-color:#985f0d
      }
      .btn-warning.active,.btn-warning:active,.open>.dropdown-toggle.btn-warning{
          background-image:none
      }
      .btn-warning.disabled.focus,.btn-warning.disabled:focus,.btn-warning.disabled:hover,.btn-warning[disabled].focus,.btn-warning[disabled]:focus,.btn-warning[disabled]:hover,fieldset[disabled] .btn-warning.focus,fieldset[disabled] .btn-warning:focus,fieldset[disabled] .btn-warning:hover{
          background-color:#f0ad4e;
          border-color:#eea236
      }
      .btn-warning .badge{
          color:#f0ad4e;
          background-color:#fff
      }
      .btn-danger{
          color:#fff;
          background-color:#d9534f;
          border-color:#d43f3a
      }
      .btn-danger.focus,.btn-danger:focus{
          color:#fff;
          background-color:#c9302c;
          border-color:#761c19
      }
      .btn-danger:hover{
          color:#fff;
          background-color:#c9302c;
          border-color:#ac2925
      }
      .btn-danger.active,.btn-danger:active,.open>.dropdown-toggle.btn-danger{
          color:#fff;
          background-color:#c9302c;
          border-color:#ac2925
      }
      .btn-danger.active.focus,.btn-danger.active:focus,.btn-danger.active:hover,.btn-danger:active.focus,.btn-danger:active:focus,.btn-danger:active:hover,.open>.dropdown-toggle.btn-danger.focus,.open>.dropdown-toggle.btn-danger:focus,.open>.dropdown-toggle.btn-danger:hover{
          color:#fff;
          background-color:#ac2925;
          border-color:#761c19
      }
      .btn-danger.active,.btn-danger:active,.open>.dropdown-toggle.btn-danger{
          background-image:none
      }
      .btn-danger.disabled.focus,.btn-danger.disabled:focus,.btn-danger.disabled:hover,.btn-danger[disabled].focus,.btn-danger[disabled]:focus,.btn-danger[disabled]:hover,fieldset[disabled] .btn-danger.focus,fieldset[disabled] .btn-danger:focus,fieldset[disabled] .btn-danger:hover{
          background-color:#d9534f;
          border-color:#d43f3a
      }
      .btn-danger .badge{
          color:#d9534f;
          background-color:#fff
      }
      .btn-link{
          font-weight:400;
          color:#337ab7;
          border-radius:0
      }
      .btn-link,.btn-link.active,.btn-link:active,.btn-link[disabled],fieldset[disabled] .btn-link{
          background-color:transparent;
          -webkit-box-shadow:none;
          box-shadow:none
      }
      .btn-link,.btn-link:active,.btn-link:focus,.btn-link:hover{
          border-color:transparent
      }
      .btn-link:focus,.btn-link:hover{
          color:#23527c;
          text-decoration:underline;
          background-color:transparent
      }
      .btn-link[disabled]:focus,.btn-link[disabled]:hover,fieldset[disabled] .btn-link:focus,fieldset[disabled] .btn-link:hover{
          color:#777;
          text-decoration:none
      }
      .btn-group-lg>.btn,.btn-lg{
          padding:10px 16px;
          font-size:18px;
          line-height:1.3333333;
          border-radius:6px
      }
      .btn-group-sm>.btn,.btn-sm{
          padding:5px 10px;
          font-size:12px;
          line-height:1.5;
          border-radius:3px
      }
      .btn-group-xs>.btn,.btn-xs{
          padding:1px 5px;
          font-size:12px;
          line-height:1.5;
          border-radius:3px
      }
      .btn-block{
          display:block;
          width:100%
      }
      .btn-block+.btn-block{
          margin-top:5px
      }
      input[type=button].btn-block,input[type=reset].btn-block,input[type=submit].btn-block{
          width:100%
      }
      .fade{
          opacity:0;
          -webkit-transition:opacity .15s linear;
          -o-transition:opacity .15s linear;
          transition:opacity .15s linear
      }
      .fade.in{
          opacity:1
      }
      .collapse{
          display:none
      }
      .collapse.in{
          display:block
      }
      tr.collapse.in{
          display:table-row
      }
      tbody.collapse.in{
          display:table-row-group
      }
      .collapsing{
          position:relative;
          height:0;
          overflow:hidden;
          -webkit-transition-timing-function:ease;
          -o-transition-timing-function:ease;
          transition-timing-function:ease;
          -webkit-transition-duration:.35s;
          -o-transition-duration:.35s;
          transition-duration:.35s;
          -webkit-transition-property:height,visibility;
          -o-transition-property:height,visibility;
          transition-property:height,visibility
      }
      .caret{
          display:inline-block;
          width:0;
          height:0;
          margin-left:2px;
          vertical-align:middle;
          border-top:4px dashed;
          border-top:4px solid\9;
          border-right:4px solid transparent;
          border-left:4px solid transparent
      }
      .dropdown,.dropup{
          position:relative
      }
      .dropdown-toggle:focus{
          outline:0
      }
      .dropdown-menu{
          position:absolute;
          top:100%;
          left:0;
          z-index:1000;
          display:none;
          float:left;
          min-width:160px;
          padding:5px 0;
          margin:2px 0 0;
          font-size:14px;
          text-align:left;
          list-style:none;
          background-color:#fff;
          -webkit-background-clip:padding-box;
          background-clip:padding-box;
          border:1px solid #ccc;
          border:1px solid rgba(0,0,0,.15);
          border-radius:4px;
          -webkit-box-shadow:0 6px 12px rgba(0,0,0,.175);
          box-shadow:0 6px 12px rgba(0,0,0,.175)
      }
      .dropdown-menu.pull-right{
          right:0;
          left:auto
      }
      .dropdown-menu .divider{
          height:1px;
          margin:9px 0;
          overflow:hidden;
          background-color:#e5e5e5
      }
      .dropdown-menu>li>a{
          display:block;
          padding:3px 20px;
          clear:both;
          font-weight:400;
          line-height:1.42857143;
          color:#333;
          white-space:nowrap
      }
      .dropdown-menu>li>a:focus,.dropdown-menu>li>a:hover{
          color:#262626;
          text-decoration:none;
          background-color:#f5f5f5
      }
      .dropdown-menu>.active>a,.dropdown-menu>.active>a:focus,.dropdown-menu>.active>a:hover{
          color:#fff;
          text-decoration:none;
          background-color:#337ab7;
          outline:0
      }
      .dropdown-menu>.disabled>a,.dropdown-menu>.disabled>a:focus,.dropdown-menu>.disabled>a:hover{
          color:#777
      }
      .dropdown-menu>.disabled>a:focus,.dropdown-menu>.disabled>a:hover{
          text-decoration:none;
          cursor:not-allowed;
          background-color:transparent;
          background-image:none;
          filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)
      }
      .open>.dropdown-menu{
          display:block
      }
      .open>a{
          outline:0
      }
      .dropdown-menu-right{
          right:0;
          left:auto
      }
      .dropdown-menu-left{
          right:auto;
          left:0
      }
      .dropdown-header{
          display:block;
          padding:3px 20px;
          font-size:12px;
          line-height:1.42857143;
          color:#777;
          white-space:nowrap
      }
      .dropdown-backdrop{
          position:fixed;
          top:0;
          right:0;
          bottom:0;
          left:0;
          z-index:990
      }
      .pull-right>.dropdown-menu{
          right:0;
          left:auto
      }
      .dropup .caret,.navbar-fixed-bottom .dropdown .caret{
          content:"";
          border-top:0;
          border-bottom:4px dashed;
          border-bottom:4px solid\9
      }
      .dropup .dropdown-menu,.navbar-fixed-bottom .dropdown .dropdown-menu{
          top:auto;
          bottom:100%;
          margin-bottom:2px
      }
      @media (min-width:768px){
          .navbar-right .dropdown-menu{
              right:0;
              left:auto
          }
          .navbar-right .dropdown-menu-left{
              right:auto;
              left:0
          }
      }
      .btn-group,.btn-group-vertical{
          position:relative;
          display:inline-block;
          vertical-align:middle
      }
      .btn-group-vertical>.btn,.btn-group>.btn{
          position:relative;
          float:left
      }
      .btn-group-vertical>.btn.active,.btn-group-vertical>.btn:active,.btn-group-vertical>.btn:focus,.btn-group-vertical>.btn:hover,.btn-group>.btn.active,.btn-group>.btn:active,.btn-group>.btn:focus,.btn-group>.btn:hover{
          z-index:2
      }
      .btn-group .btn+.btn,.btn-group .btn+.btn-group,.btn-group .btn-group+.btn,.btn-group .btn-group+.btn-group{
          margin-left:-1px
      }
      .btn-toolbar{
          margin-left:-5px
      }
      .btn-toolbar .btn,.btn-toolbar .btn-group,.btn-toolbar .input-group{
          float:left
      }
      .btn-toolbar>.btn,.btn-toolbar>.btn-group,.btn-toolbar>.input-group{
          margin-left:5px
      }
      .btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle){
          border-radius:0
      }
      .btn-group>.btn:first-child{
          margin-left:0
      }
      .btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle){
          border-top-right-radius:0;
          border-bottom-right-radius:0
      }
      .btn-group>.btn:last-child:not(:first-child),.btn-group>.dropdown-toggle:not(:first-child){
          border-top-left-radius:0;
          border-bottom-left-radius:0
      }
      .btn-group>.btn-group{
          float:left
      }
      .btn-group>.btn-group:not(:first-child):not(:last-child)>.btn{
          border-radius:0
      }
      .btn-group>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group>.btn-group:first-child:not(:last-child)>.dropdown-toggle{
          border-top-right-radius:0;
          border-bottom-right-radius:0
      }
      .btn-group>.btn-group:last-child:not(:first-child)>.btn:first-child{
          border-top-left-radius:0;
          border-bottom-left-radius:0
      }
      .btn-group .dropdown-toggle:active,.btn-group.open .dropdown-toggle{
          outline:0
      }
      .btn-group>.btn+.dropdown-toggle{
          padding-right:8px;
          padding-left:8px
      }
      .btn-group>.btn-lg+.dropdown-toggle{
          padding-right:12px;
          padding-left:12px
      }
      .btn-group.open .dropdown-toggle{
          -webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);
          box-shadow:inset 0 3px 5px rgba(0,0,0,.125)
      }
      .btn-group.open .dropdown-toggle.btn-link{
          -webkit-box-shadow:none;
          box-shadow:none
      }
      .btn .caret{
          margin-left:0
      }
      .btn-lg .caret{
          border-width:5px 5px 0;
          border-bottom-width:0
      }
      .dropup .btn-lg .caret{
          border-width:0 5px 5px
      }
      .btn-group-vertical>.btn,.btn-group-vertical>.btn-group,.btn-group-vertical>.btn-group>.btn{
          display:block;
          float:none;
          width:100%;
          max-width:100%
      }
      .btn-group-vertical>.btn-group>.btn{
          float:none
      }
      .btn-group-vertical>.btn+.btn,.btn-group-vertical>.btn+.btn-group,.btn-group-vertical>.btn-group+.btn,.btn-group-vertical>.btn-group+.btn-group{
          margin-top:-1px;
          margin-left:0
      }
      .btn-group-vertical>.btn:not(:first-child):not(:last-child){
          border-radius:0
      }
      .btn-group-vertical>.btn:first-child:not(:last-child){
          border-top-left-radius:4px;
          border-top-right-radius:4px;
          border-bottom-right-radius:0;
          border-bottom-left-radius:0
      }
      .btn-group-vertical>.btn:last-child:not(:first-child){
          border-top-left-radius:0;
          border-top-right-radius:0;
          border-bottom-right-radius:4px;
          border-bottom-left-radius:4px
      }
      .btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn{
          border-radius:0
      }
      .btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle{
          border-bottom-right-radius:0;
          border-bottom-left-radius:0
      }
      .btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child{
          border-top-left-radius:0;
          border-top-right-radius:0
      }
      .btn-group-justified{
          display:table;
          width:100%;
          table-layout:fixed;
          border-collapse:separate
      }
      .btn-group-justified>.btn,.btn-group-justified>.btn-group{
          display:table-cell;
          float:none;
          width:1%
      }
      .btn-group-justified>.btn-group .btn{
          width:100%
      }
      .btn-group-justified>.btn-group .dropdown-menu{
          left:auto
      }
      [data-toggle=buttons]>.btn input[type=checkbox],[data-toggle=buttons]>.btn input[type=radio],[data-toggle=buttons]>.btn-group>.btn input[type=checkbox],[data-toggle=buttons]>.btn-group>.btn input[type=radio]{
          position:absolute;
          clip:rect(0,0,0,0);
          pointer-events:none
      }
      .input-group{
          position:relative;
          display:table;
          border-collapse:separate
      }
      .input-group[class*=col-]{
          float:none;
          padding-right:0;
          padding-left:0
      }
      .input-group .form-control{
          position:relative;
          z-index:2;
          float:left;
          width:100%;
          margin-bottom:0
      }
      .input-group .form-control:focus{
          z-index:3
      }
      .input-group-lg>.form-control,.input-group-lg>.input-group-addon,.input-group-lg>.input-group-btn>.btn{
          height:46px;
          padding:10px 16px;
          font-size:18px;
          line-height:1.3333333;
          border-radius:6px
      }
      select.input-group-lg>.form-control,select.input-group-lg>.input-group-addon,select.input-group-lg>.input-group-btn>.btn{
          height:46px;
          line-height:46px
      }
      select[multiple].input-group-lg>.form-control,select[multiple].input-group-lg>.input-group-addon,select[multiple].input-group-lg>.input-group-btn>.btn,textarea.input-group-lg>.form-control,textarea.input-group-lg>.input-group-addon,textarea.input-group-lg>.input-group-btn>.btn{
          height:auto
      }
      .input-group-sm>.form-control,.input-group-sm>.input-group-addon,.input-group-sm>.input-group-btn>.btn{
          height:30px;
          padding:5px 10px;
          font-size:12px;
          line-height:1.5;
          border-radius:3px
      }
      select.input-group-sm>.form-control,select.input-group-sm>.input-group-addon,select.input-group-sm>.input-group-btn>.btn{
          height:30px;
          line-height:30px
      }
      select[multiple].input-group-sm>.form-control,select[multiple].input-group-sm>.input-group-addon,select[multiple].input-group-sm>.input-group-btn>.btn,textarea.input-group-sm>.form-control,textarea.input-group-sm>.input-group-addon,textarea.input-group-sm>.input-group-btn>.btn{
          height:auto
      }
      .input-group .form-control,.input-group-addon,.input-group-btn{
          display:table-cell
      }
      .input-group .form-control:not(:first-child):not(:last-child),.input-group-addon:not(:first-child):not(:last-child),.input-group-btn:not(:first-child):not(:last-child){
          border-radius:0
      }
      .input-group-addon,.input-group-btn{
          width:1%;
          white-space:nowrap;
          vertical-align:middle
      }
      .input-group-addon{
          padding:6px 12px;
          font-size:14px;
          font-weight:400;
          line-height:1;
          color:#555;
          text-align:center;
          background-color:#eee;
          border:1px solid #ccc;
          border-radius:4px
      }
      .input-group-addon.input-sm{
          padding:5px 10px;
          font-size:12px;
          border-radius:3px
      }
      .input-group-addon.input-lg{
          padding:10px 16px;
          font-size:18px;
          border-radius:6px
      }
      .input-group-addon input[type=checkbox],.input-group-addon input[type=radio]{
          margin-top:0
      }
      .input-group .form-control:first-child,.input-group-addon:first-child,.input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group>.btn,.input-group-btn:first-child>.dropdown-toggle,.input-group-btn:last-child>.btn-group:not(:last-child)>.btn,.input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle){
          border-top-right-radius:0;
          border-bottom-right-radius:0
      }
      .input-group-addon:first-child{
          border-right:0
      }
      .input-group .form-control:last-child,.input-group-addon:last-child,.input-group-btn:first-child>.btn-group:not(:first-child)>.btn,.input-group-btn:first-child>.btn:not(:first-child),.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group>.btn,.input-group-btn:last-child>.dropdown-toggle{
          border-top-left-radius:0;
          border-bottom-left-radius:0
      }
      .input-group-addon:last-child{
          border-left:0
      }
      .input-group-btn{
          position:relative;
          font-size:0;
          white-space:nowrap
      }
      .input-group-btn>.btn{
          position:relative
      }
      .input-group-btn>.btn+.btn{
          margin-left:-1px
      }
      .input-group-btn>.btn:active,.input-group-btn>.btn:focus,.input-group-btn>.btn:hover{
          z-index:2
      }
      .input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group{
          margin-right:-1px
      }
      .input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group{
          z-index:2;
          margin-left:-1px
      }
      .nav{
          padding-left:0;
          margin-bottom:0;
          list-style:none
      }
      .nav>li{
          position:relative;
          display:block
      }
      .nav>li>a{
          position:relative;
          display:block;
          padding:10px 15px
      }
      .nav>li>a:focus,.nav>li>a:hover{
          text-decoration:none;
          background-color:#eee
      }
      .nav>li.disabled>a{
          color:#777
      }
      .nav>li.disabled>a:focus,.nav>li.disabled>a:hover{
          color:#777;
          text-decoration:none;
          cursor:not-allowed;
          background-color:transparent
      }
      .nav .open>a,.nav .open>a:focus,.nav .open>a:hover{
          background-color:#eee;
          border-color:#337ab7
      }
      .nav .nav-divider{
          height:1px;
          margin:9px 0;
          overflow:hidden;
          background-color:#e5e5e5
      }
      .nav>li>a>img{
          max-width:none
      }
      .nav-tabs{
          border-bottom:1px solid #ddd
      }
      .nav-tabs>li{
          float:left;
          margin-bottom:-1px
      }
      .nav-tabs>li>a{
          margin-right:2px;
          line-height:1.42857143;
          border:1px solid transparent;
          border-radius:4px 4px 0 0
      }
      .nav-tabs>li>a:hover{
          border-color:#eee #eee #ddd
      }
      .nav-tabs>li.active>a,.nav-tabs>li.active>a:focus,.nav-tabs>li.active>a:hover{
          color:#555;
          cursor:default;
          background-color:#fff;
          border:1px solid #ddd;
          border-bottom-color:transparent
      }
      .nav-tabs.nav-justified{
          width:100%;
          border-bottom:0
      }
      .nav-tabs.nav-justified>li{
          float:none
      }
      .nav-tabs.nav-justified>li>a{
          margin-bottom:5px;
          text-align:center
      }
      .nav-tabs.nav-justified>.dropdown .dropdown-menu{
          top:auto;
          left:auto
      }
      @media (min-width:768px){
          .nav-tabs.nav-justified>li{
              display:table-cell;
              width:1%
          }
          .nav-tabs.nav-justified>li>a{
              margin-bottom:0
          }
      }
      .nav-tabs.nav-justified>li>a{
          margin-right:0;
          border-radius:4px
      }
      .nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:focus,.nav-tabs.nav-justified>.active>a:hover{
          border:1px solid #ddd
      }
      @media (min-width:768px){
          .nav-tabs.nav-justified>li>a{
              border-bottom:1px solid #ddd;
              border-radius:4px 4px 0 0
          }
          .nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:focus,.nav-tabs.nav-justified>.active>a:hover{
              border-bottom-color:#fff
          }
      }
      .nav-pills>li{
          float:left
      }
      .nav-pills>li>a{
          border-radius:4px
      }
      .nav-pills>li+li{
          margin-left:2px
      }
      .nav-pills>li.active>a,.nav-pills>li.active>a:focus,.nav-pills>li.active>a:hover{
          color:#fff;
          background-color:#337ab7
      }
      .nav-stacked>li{
          float:none
      }
      .nav-stacked>li+li{
          margin-top:2px;
          margin-left:0
      }
      .nav-justified{
          width:100%
      }
      .nav-justified>li{
          float:none
      }
      .nav-justified>li>a{
          margin-bottom:5px;
          text-align:center
      }
      .nav-justified>.dropdown .dropdown-menu{
          top:auto;
          left:auto
      }
      @media (min-width:768px){
          .nav-justified>li{
              display:table-cell;
              width:1%
          }
          .nav-justified>li>a{
              margin-bottom:0
          }
      }
      .nav-tabs-justified{
          border-bottom:0
      }
      .nav-tabs-justified>li>a{
          margin-right:0;
          border-radius:4px
      }
      .nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:focus,.nav-tabs-justified>.active>a:hover{
          border:1px solid #ddd
      }
      @media (min-width:768px){
          .nav-tabs-justified>li>a{
              border-bottom:1px solid #ddd;
              border-radius:4px 4px 0 0
          }
          .nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:focus,.nav-tabs-justified>.active>a:hover{
              border-bottom-color:#fff
          }
      }
      .tab-content>.tab-pane{
          display:none
      }
      .tab-content>.active{
          display:block
      }
      .nav-tabs .dropdown-menu{
          margin-top:-1px;
          border-top-left-radius:0;
          border-top-right-radius:0
      }
      .navbar{
          position:relative;
          min-height:50px;
          margin-bottom:20px;
          border:1px solid transparent
      }
      @media (min-width:768px){
          .navbar{
              border-radius:4px
          }
      }
      @media (min-width:768px){
          .navbar-header{
              float:left
          }
      }
      .navbar-collapse{
          padding-right:15px;
          padding-left:15px;
          overflow-x:visible;
          -webkit-overflow-scrolling:touch;
          border-top:1px solid transparent;
          -webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1);
          box-shadow:inset 0 1px 0 rgba(255,255,255,.1)
      }
      .navbar-collapse.in{
          overflow-y:auto
      }
      @media (min-width:768px){
          .navbar-collapse{
              width:auto;
              border-top:0;
              -webkit-box-shadow:none;
              box-shadow:none
          }
          .navbar-collapse.collapse{
              display:block!important;
              height:auto!important;
              padding-bottom:0;
              overflow:visible!important
          }
          .navbar-collapse.in{
              overflow-y:visible
          }
          .navbar-fixed-bottom .navbar-collapse,.navbar-fixed-top .navbar-collapse,.navbar-static-top .navbar-collapse{
              padding-right:0;
              padding-left:0
          }
      }
      .navbar-fixed-bottom .navbar-collapse,.navbar-fixed-top .navbar-collapse{
          max-height:340px
      }
      @media (max-device-width:480px) and (orientation:landscape){
          .navbar-fixed-bottom .navbar-collapse,.navbar-fixed-top .navbar-collapse{
              max-height:200px
          }
      }
      .container-fluid>.navbar-collapse,.container-fluid>.navbar-header,.container>.navbar-collapse,.container>.navbar-header{
          margin-right:-15px;
          margin-left:-15px
      }
      @media (min-width:768px){
          .container-fluid>.navbar-collapse,.container-fluid>.navbar-header,.container>.navbar-collapse,.container>.navbar-header{
              margin-right:0;
              margin-left:0
          }
      }
      .navbar-static-top{
          z-index:1000;
          border-width:0 0 1px
      }
      @media (min-width:768px){
          .navbar-static-top{
              border-radius:0
          }
      }
      .navbar-fixed-bottom,.navbar-fixed-top{
          position:fixed;
          right:0;
          left:0;
          z-index:1030
      }
      @media (min-width:768px){
          .navbar-fixed-bottom,.navbar-fixed-top{
              border-radius:0
          }
      }
      .navbar-fixed-top{
          top:0;
          border-width:0 0 1px
      }
      .navbar-fixed-bottom{
          bottom:0;
          margin-bottom:0;
          border-width:1px 0 0
      }
      .navbar-brand{
          float:left;
          height:50px;
          padding:15px 15px;
          font-size:18px;
          line-height:20px
      }
      .navbar-brand:focus,.navbar-brand:hover{
          text-decoration:none
      }
      .navbar-brand>img{
          display:block
      }
      @media (min-width:768px){
          .navbar>.container .navbar-brand,.navbar>.container-fluid .navbar-brand{
              margin-left:-15px
          }
      }
      .navbar-toggle{
          position:relative;
          float:right;
          padding:9px 10px;
          margin-top:8px;
          margin-right:15px;
          margin-bottom:8px;
          background-color:transparent;
          background-image:none;
          border:1px solid transparent;
          border-radius:4px
      }
      .navbar-toggle:focus{
          outline:0
      }
      .navbar-toggle .icon-bar{
          display:block;
          width:22px;
          height:2px;
          border-radius:1px
      }
      .navbar-toggle .icon-bar+.icon-bar{
          margin-top:4px
      }
      @media (min-width:768px){
          .navbar-toggle{
              display:none
          }
      }
      .navbar-nav{
          margin:7.5px -15px
      }
      .navbar-nav>li>a{
          padding-top:10px;
          padding-bottom:10px;
          line-height:20px
      }
      @media (max-width:767px){
          .navbar-nav .open .dropdown-menu{
              position:static;
              float:none;
              width:auto;
              margin-top:0;
              background-color:transparent;
              border:0;
              -webkit-box-shadow:none;
              box-shadow:none
          }
          .navbar-nav .open .dropdown-menu .dropdown-header,.navbar-nav .open .dropdown-menu>li>a{
              padding:5px 15px 5px 25px
          }
          .navbar-nav .open .dropdown-menu>li>a{
              line-height:20px
          }
          .navbar-nav .open .dropdown-menu>li>a:focus,.navbar-nav .open .dropdown-menu>li>a:hover{
              background-image:none
          }
      }
      @media (min-width:768px){
          .navbar-nav{
              float:left;
              margin:0
          }
          .navbar-nav>li{
              float:left
          }
          .navbar-nav>li>a{
              padding-top:15px;
              padding-bottom:15px
          }
      }
      .navbar-form{
          padding:10px 15px;
          margin-top:8px;
          margin-right:-15px;
          margin-bottom:8px;
          margin-left:-15px;
          border-top:1px solid transparent;
          border-bottom:1px solid transparent;
          -webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 1px 0 rgba(255,255,255,.1);
          box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 1px 0 rgba(255,255,255,.1)
      }
      @media (min-width:768px){
          .navbar-form .form-group{
              display:inline-block;
              margin-bottom:0;
              vertical-align:middle
          }
          .navbar-form .form-control{
              display:inline-block;
              width:auto;
              vertical-align:middle
          }
          .navbar-form .form-control-static{
              display:inline-block
          }
          .navbar-form .input-group{
              display:inline-table;
              vertical-align:middle
          }
          .navbar-form .input-group .form-control,.navbar-form .input-group .input-group-addon,.navbar-form .input-group .input-group-btn{
              width:auto
          }
          .navbar-form .input-group>.form-control{
              width:100%
          }
          .navbar-form .control-label{
              margin-bottom:0;
              vertical-align:middle
          }
          .navbar-form .checkbox,.navbar-form .radio{
              display:inline-block;
              margin-top:0;
              margin-bottom:0;
              vertical-align:middle
          }
          .navbar-form .checkbox label,.navbar-form .radio label{
              padding-left:0
          }
          .navbar-form .checkbox input[type=checkbox],.navbar-form .radio input[type=radio]{
              position:relative;
              margin-left:0
          }
          .navbar-form .has-feedback .form-control-feedback{
              top:0
          }
      }
      @media (max-width:767px){
          .navbar-form .form-group{
              margin-bottom:5px
          }
          .navbar-form .form-group:last-child{
              margin-bottom:0
          }
      }
      @media (min-width:768px){
          .navbar-form{
              width:auto;
              padding-top:0;
              padding-bottom:0;
              margin-right:0;
              margin-left:0;
              border:0;
              -webkit-box-shadow:none;
              box-shadow:none
          }
      }
      .navbar-nav>li>.dropdown-menu{
          margin-top:0;
          border-top-left-radius:0;
          border-top-right-radius:0
      }
      .navbar-fixed-bottom .navbar-nav>li>.dropdown-menu{
          margin-bottom:0;
          border-top-left-radius:4px;
          border-top-right-radius:4px;
          border-bottom-right-radius:0;
          border-bottom-left-radius:0
      }
      .navbar-btn{
          margin-top:8px;
          margin-bottom:8px
      }
      .navbar-btn.btn-sm{
          margin-top:10px;
          margin-bottom:10px
      }
      .navbar-btn.btn-xs{
          margin-top:14px;
          margin-bottom:14px
      }
      .navbar-text{
          margin-top:15px;
          margin-bottom:15px
      }
      @media (min-width:768px){
          .navbar-text{
              float:left;
              margin-right:15px;
              margin-left:15px
          }
      }
      @media (min-width:768px){
          .navbar-left{
              float:left!important
          }
          .navbar-right{
              float:right!important;
              margin-right:-15px
          }
          .navbar-right~.navbar-right{
              margin-right:0
          }
      }
      .navbar-default{
          background-color:#f8f8f8;
          border-color:#e7e7e7
      }
      .navbar-default .navbar-brand{
          color:#777
      }
      .navbar-default .navbar-brand:focus,.navbar-default .navbar-brand:hover{
          color:#5e5e5e;
          background-color:transparent
      }
      .navbar-default .navbar-text{
          color:#777
      }
      .navbar-default .navbar-nav>li>a{
          color:#777
      }
      .navbar-default .navbar-nav>li>a:focus,.navbar-default .navbar-nav>li>a:hover{
          color:#333;
          background-color:transparent
      }
      .navbar-default .navbar-nav>.active>a,.navbar-default .navbar-nav>.active>a:focus,.navbar-default .navbar-nav>.active>a:hover{
          color:#555;
          background-color:#e7e7e7
      }
      .navbar-default .navbar-nav>.disabled>a,.navbar-default .navbar-nav>.disabled>a:focus,.navbar-default .navbar-nav>.disabled>a:hover{
          color:#ccc;
          background-color:transparent
      }
      .navbar-default .navbar-toggle{
          border-color:#ddd
      }
      .navbar-default .navbar-toggle:focus,.navbar-default .navbar-toggle:hover{
          background-color:#ddd
      }
      .navbar-default .navbar-toggle .icon-bar{
          background-color:#888
      }
      .navbar-default .navbar-collapse,.navbar-default .navbar-form{
          border-color:#e7e7e7
      }
      .navbar-default .navbar-nav>.open>a,.navbar-default .navbar-nav>.open>a:focus,.navbar-default .navbar-nav>.open>a:hover{
          color:#555;
          background-color:#e7e7e7
      }
      @media (max-width:767px){
          .navbar-default .navbar-nav .open .dropdown-menu>li>a{
              color:#777
          }
          .navbar-default .navbar-nav .open .dropdown-menu>li>a:focus,.navbar-default .navbar-nav .open .dropdown-menu>li>a:hover{
              color:#333;
              background-color:transparent
          }
          .navbar-default .navbar-nav .open .dropdown-menu>.active>a,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:focus,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:hover{
              color:#555;
              background-color:#e7e7e7
          }
          .navbar-default .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:focus,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:hover{
              color:#ccc;
              background-color:transparent
          }
      }
      .navbar-default .navbar-link{
          color:#777
      }
      .navbar-default .navbar-link:hover{
          color:#333
      }
      .navbar-default .btn-link{
          color:#777
      }
      .navbar-default .btn-link:focus,.navbar-default .btn-link:hover{
          color:#333
      }
      .navbar-default .btn-link[disabled]:focus,.navbar-default .btn-link[disabled]:hover,fieldset[disabled] .navbar-default .btn-link:focus,fieldset[disabled] .navbar-default .btn-link:hover{
          color:#ccc
      }
      .navbar-inverse{
          background-color:#222;
          border-color:#080808
      }
      .navbar-inverse .navbar-brand{
          color:#9d9d9d
      }
      .navbar-inverse .navbar-brand:focus,.navbar-inverse .navbar-brand:hover{
          color:#fff;
          background-color:transparent
      }
      .navbar-inverse .navbar-text{
          color:#9d9d9d
      }
      .navbar-inverse .navbar-nav>li>a{
          color:#9d9d9d
      }
      .navbar-inverse .navbar-nav>li>a:focus,.navbar-inverse .navbar-nav>li>a:hover{
          color:#fff;
          background-color:transparent
      }
      .navbar-inverse .navbar-nav>.active>a,.navbar-inverse .navbar-nav>.active>a:focus,.navbar-inverse .navbar-nav>.active>a:hover{
          color:#fff;
          background-color:#080808
      }
      .navbar-inverse .navbar-nav>.disabled>a,.navbar-inverse .navbar-nav>.disabled>a:focus,.navbar-inverse .navbar-nav>.disabled>a:hover{
          color:#444;
          background-color:transparent
      }
      .navbar-inverse .navbar-toggle{
          border-color:#333
      }
      .navbar-inverse .navbar-toggle:focus,.navbar-inverse .navbar-toggle:hover{
          background-color:#333
      }
      .navbar-inverse .navbar-toggle .icon-bar{
          background-color:#fff
      }
      .navbar-inverse .navbar-collapse,.navbar-inverse .navbar-form{
          border-color:#101010
      }
      .navbar-inverse .navbar-nav>.open>a,.navbar-inverse .navbar-nav>.open>a:focus,.navbar-inverse .navbar-nav>.open>a:hover{
          color:#fff;
          background-color:#080808
      }
      @media (max-width:767px){
          .navbar-inverse .navbar-nav .open .dropdown-menu>.dropdown-header{
              border-color:#080808
          }
          .navbar-inverse .navbar-nav .open .dropdown-menu .divider{
              background-color:#080808
          }
          .navbar-inverse .navbar-nav .open .dropdown-menu>li>a{
              color:#9d9d9d
          }
          .navbar-inverse .navbar-nav .open .dropdown-menu>li>a:focus,.navbar-inverse .navbar-nav .open .dropdown-menu>li>a:hover{
              color:#fff;
              background-color:transparent
          }
          .navbar-inverse .navbar-nav .open .dropdown-menu>.active>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:focus,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:hover{
              color:#fff;
              background-color:#080808
          }
          .navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:focus,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:hover{
              color:#444;
              background-color:transparent
          }
      }
      .navbar-inverse .navbar-link{
          color:#9d9d9d
      }
      .navbar-inverse .navbar-link:hover{
          color:#fff
      }
      .navbar-inverse .btn-link{
          color:#9d9d9d
      }
      .navbar-inverse .btn-link:focus,.navbar-inverse .btn-link:hover{
          color:#fff
      }
      .navbar-inverse .btn-link[disabled]:focus,.navbar-inverse .btn-link[disabled]:hover,fieldset[disabled] .navbar-inverse .btn-link:focus,fieldset[disabled] .navbar-inverse .btn-link:hover{
          color:#444
      }
      .breadcrumb{
          padding:8px 15px;
          margin-bottom:20px;
          list-style:none;
          background-color:#f5f5f5;
          border-radius:4px
      }
      .breadcrumb>li{
          display:inline-block
      }
      .breadcrumb>li+li:before{
          padding:0 5px;
          color:#ccc;
          content:"/\00a0"
      }
      .breadcrumb>.active{
          color:#777
      }
      .pagination{
          display:inline-block;
          padding-left:0;
          margin:20px 0;
          border-radius:4px
      }
      .pagination>li{
          display:inline
      }
      .pagination>li>a,.pagination>li>span{
          position:relative;
          float:left;
          padding:6px 12px;
          margin-left:-1px;
          line-height:1.42857143;
          color:#337ab7;
          text-decoration:none;
          background-color:#fff;
          border:1px solid #ddd
      }
      .pagination>li:first-child>a,.pagination>li:first-child>span{
          margin-left:0;
          border-top-left-radius:4px;
          border-bottom-left-radius:4px
      }
      .pagination>li:last-child>a,.pagination>li:last-child>span{
          border-top-right-radius:4px;
          border-bottom-right-radius:4px
      }
      .pagination>li>a:focus,.pagination>li>a:hover,.pagination>li>span:focus,.pagination>li>span:hover{
          z-index:2;
          color:#23527c;
          background-color:#eee;
          border-color:#ddd
      }
      .pagination>.active>a,.pagination>.active>a:focus,.pagination>.active>a:hover,.pagination>.active>span,.pagination>.active>span:focus,.pagination>.active>span:hover{
          z-index:3;
          color:#fff;
          cursor:default;
          background-color:#337ab7;
          border-color:#337ab7
      }
      .pagination>.disabled>a,.pagination>.disabled>a:focus,.pagination>.disabled>a:hover,.pagination>.disabled>span,.pagination>.disabled>span:focus,.pagination>.disabled>span:hover{
          color:#777;
          cursor:not-allowed;
          background-color:#fff;
          border-color:#ddd
      }
      .pagination-lg>li>a,.pagination-lg>li>span{
          padding:10px 16px;
          font-size:18px;
          line-height:1.3333333
      }
      .pagination-lg>li:first-child>a,.pagination-lg>li:first-child>span{
          border-top-left-radius:6px;
          border-bottom-left-radius:6px
      }
      .pagination-lg>li:last-child>a,.pagination-lg>li:last-child>span{
          border-top-right-radius:6px;
          border-bottom-right-radius:6px
      }
      .pagination-sm>li>a,.pagination-sm>li>span{
          padding:5px 10px;
          font-size:12px;
          line-height:1.5
      }
      .pagination-sm>li:first-child>a,.pagination-sm>li:first-child>span{
          border-top-left-radius:3px;
          border-bottom-left-radius:3px
      }
      .pagination-sm>li:last-child>a,.pagination-sm>li:last-child>span{
          border-top-right-radius:3px;
          border-bottom-right-radius:3px
      }
      .pager{
          padding-left:0;
          margin:20px 0;
          text-align:center;
          list-style:none
      }
      .pager li{
          display:inline
      }
      .pager li>a,.pager li>span{
          display:inline-block;
          padding:5px 14px;
          background-color:#fff;
          border:1px solid #ddd;
          border-radius:15px
      }
      .pager li>a:focus,.pager li>a:hover{
          text-decoration:none;
          background-color:#eee
      }
      .pager .next>a,.pager .next>span{
          float:right
      }
      .pager .previous>a,.pager .previous>span{
          float:left
      }
      .pager .disabled>a,.pager .disabled>a:focus,.pager .disabled>a:hover,.pager .disabled>span{
          color:#777;
          cursor:not-allowed;
          background-color:#fff
      }
      .label{
          display:inline;
          padding:.2em .6em .3em;
          font-size:75%;
          font-weight:700;
          line-height:1;
          color:#fff;
          text-align:center;
          white-space:nowrap;
          vertical-align:baseline;
          border-radius:.25em
      }
      a.label:focus,a.label:hover{
          color:#fff;
          text-decoration:none;
          cursor:pointer
      }
      .label:empty{
          display:none
      }
      .btn .label{
          position:relative;
          top:-1px
      }
      .label-default{
          background-color:#777
      }
      .label-default[href]:focus,.label-default[href]:hover{
          background-color:#5e5e5e
      }
      .label-primary{
          background-color:#337ab7
      }
      .label-primary[href]:focus,.label-primary[href]:hover{
          background-color:#286090
      }
      .label-success{
          background-color:#5cb85c
      }
      .label-success[href]:focus,.label-success[href]:hover{
          background-color:#449d44
      }
      .label-info{
          background-color:#5bc0de
      }
      .label-info[href]:focus,.label-info[href]:hover{
          background-color:#31b0d5
      }
      .label-warning{
          background-color:#f0ad4e
      }
      .label-warning[href]:focus,.label-warning[href]:hover{
          background-color:#ec971f
      }
      .label-danger{
          background-color:#d9534f
      }
      .label-danger[href]:focus,.label-danger[href]:hover{
          background-color:#c9302c
      }
      .badge{
          display:inline-block;
          min-width:10px;
          padding:3px 7px;
          font-size:12px;
          font-weight:700;
          line-height:1;
          color:#fff;
          text-align:center;
          white-space:nowrap;
          vertical-align:middle;
          background-color:#777;
          border-radius:10px
      }
      .badge:empty{
          display:none
      }
      .btn .badge{
          position:relative;
          top:-1px
      }
      .btn-group-xs>.btn .badge,.btn-xs .badge{
          top:0;
          padding:1px 5px
      }
      a.badge:focus,a.badge:hover{
          color:#fff;
          text-decoration:none;
          cursor:pointer
      }
      .list-group-item.active>.badge,.nav-pills>.active>a>.badge{
          color:#337ab7;
          background-color:#fff
      }
      .list-group-item>.badge{
          float:right
      }
      .list-group-item>.badge+.badge{
          margin-right:5px
      }
      .nav-pills>li>a>.badge{
          margin-left:3px
      }
      .jumbotron{
          padding-top:30px;
          padding-bottom:30px;
          margin-bottom:30px;
          color:inherit;
          background-color:#eee
      }
      .jumbotron .h1,.jumbotron h1{
          color:inherit
      }
      .jumbotron p{
          margin-bottom:15px;
          font-size:21px;
          font-weight:200
      }
      .jumbotron>hr{
          border-top-color:#d5d5d5
      }
      .container .jumbotron,.container-fluid .jumbotron{
          padding-right:15px;
          padding-left:15px;
          border-radius:6px
      }
      .jumbotron .container{
          max-width:100%
      }
      @media screen and (min-width:768px){
          .jumbotron{
              padding-top:48px;
              padding-bottom:48px
          }
          .container .jumbotron,.container-fluid .jumbotron{
              padding-right:60px;
              padding-left:60px
          }
          .jumbotron .h1,.jumbotron h1{
              font-size:63px
          }
      }
      .thumbnail{
          display:block;
          padding:4px;
          margin-bottom:20px;
          line-height:1.42857143;
          background-color:#fff;
          border:1px solid #ddd;
          border-radius:4px;
          -webkit-transition:border .2s ease-in-out;
          -o-transition:border .2s ease-in-out;
          transition:border .2s ease-in-out
      }
      .thumbnail a>img,.thumbnail>img{
          margin-right:auto;
          margin-left:auto
      }
      a.thumbnail.active,a.thumbnail:focus,a.thumbnail:hover{
          border-color:#337ab7
      }
      .thumbnail .caption{
          padding:9px;
          color:#333
      }
      .alert{
          padding:15px;
          margin-bottom:20px;
          border:1px solid transparent;
          border-radius:4px
      }
      .alert h4{
          margin-top:0;
          color:inherit
      }
      .alert .alert-link{
          font-weight:700
      }
      .alert>p,.alert>ul{
          margin-bottom:0
      }
      .alert>p+p{
          margin-top:5px
      }
      .alert-dismissable,.alert-dismissible{
          padding-right:35px
      }
      .alert-dismissable .close,.alert-dismissible .close{
          position:relative;
          top:-2px;
          right:-21px;
          color:inherit
      }
      .alert-success{
          color:#3c763d;
          background-color:#dff0d8;
          border-color:#d6e9c6
      }
      .alert-success hr{
          border-top-color:#c9e2b3
      }
      .alert-success .alert-link{
          color:#2b542c
      }
      .alert-info{
          color:#31708f;
          background-color:#d9edf7;
          border-color:#bce8f1
      }
      .alert-info hr{
          border-top-color:#a6e1ec
      }
      .alert-info .alert-link{
          color:#245269
      }
      .alert-warning{
          color:#8a6d3b;
          background-color:#fcf8e3;
          border-color:#faebcc
      }
      .alert-warning hr{
          border-top-color:#f7e1b5
      }
      .alert-warning .alert-link{
          color:#66512c
      }
      .alert-danger{
          color:#a94442;
          background-color:#f2dede;
          border-color:#ebccd1
      }
      .alert-danger hr{
          border-top-color:#e4b9c0
      }
      .alert-danger .alert-link{
          color:#843534
      }
      @-webkit-keyframes progress-bar-stripes{
          from{
              background-position:40px 0
          }
          to{
              background-position:0 0
          }
      }
      @-o-keyframes progress-bar-stripes{
          from{
              background-position:40px 0
          }
          to{
              background-position:0 0
          }
      }
      @keyframes progress-bar-stripes{
          from{
              background-position:40px 0
          }
          to{
              background-position:0 0
          }
      }
      .progress{
          height:20px;
          margin-bottom:20px;
          overflow:hidden;
          background-color:#f5f5f5;
          border-radius:4px;
          -webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);
          box-shadow:inset 0 1px 2px rgba(0,0,0,.1)
      }
      .progress-bar{
          float:left;
          width:0;
          height:100%;
          font-size:12px;
          line-height:20px;
          color:#fff;
          text-align:center;
          background-color:#337ab7;
          -webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,.15);
          box-shadow:inset 0 -1px 0 rgba(0,0,0,.15);
          -webkit-transition:width .6s ease;
          -o-transition:width .6s ease;
          transition:width .6s ease
      }
      .progress-bar-striped,.progress-striped .progress-bar{
          background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          -webkit-background-size:40px 40px;
          background-size:40px 40px
      }
      .progress-bar.active,.progress.active .progress-bar{
          -webkit-animation:progress-bar-stripes 2s linear infinite;
          -o-animation:progress-bar-stripes 2s linear infinite;
          animation:progress-bar-stripes 2s linear infinite
      }
      .progress-bar-success{
          background-color:#5cb85c
      }
      .progress-striped .progress-bar-success{
          background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)
      }
      .progress-bar-info{
          background-color:#5bc0de
      }
      .progress-striped .progress-bar-info{
          background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)
      }
      .progress-bar-warning{
          background-color:#f0ad4e
      }
      .progress-striped .progress-bar-warning{
          background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)
      }
      .progress-bar-danger{
          background-color:#d9534f
      }
      .progress-striped .progress-bar-danger{
          background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
          background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)
      }
      .media{
          margin-top:15px
      }
      .media:first-child{
          margin-top:0
      }
      .media,.media-body{
          overflow:hidden;
          zoom:1
      }
      .media-body{
          width:10000px
      }
      .media-object{
          display:block
      }
      .media-object.img-thumbnail{
          max-width:none
      }
      .media-right,.media>.pull-right{
          padding-left:10px
      }
      .media-left,.media>.pull-left{
          padding-right:10px
      }
      .media-body,.media-left,.media-right{
          display:table-cell;
          vertical-align:top
      }
      .media-middle{
          vertical-align:middle
      }
      .media-bottom{
          vertical-align:bottom
      }
      .media-heading{
          margin-top:0;
          margin-bottom:5px
      }
      .media-list{
          padding-left:0;
          list-style:none
      }
      .list-group{
          padding-left:0;
          margin-bottom:20px
      }
      .list-group-item{
          position:relative;
          display:block;
          padding:10px 15px;
          margin-bottom:-1px;
          background-color:#fff;
          border:1px solid #ddd
      }
      .list-group-item:first-child{
          border-top-left-radius:4px;
          border-top-right-radius:4px
      }
      .list-group-item:last-child{
          margin-bottom:0;
          border-bottom-right-radius:4px;
          border-bottom-left-radius:4px
      }
      a.list-group-item,button.list-group-item{
          color:#555
      }
      a.list-group-item .list-group-item-heading,button.list-group-item .list-group-item-heading{
          color:#333
      }
      a.list-group-item:focus,a.list-group-item:hover,button.list-group-item:focus,button.list-group-item:hover{
          color:#555;
          text-decoration:none;
          background-color:#f5f5f5
      }
      button.list-group-item{
          width:100%;
          text-align:left
      }
      .list-group-item.disabled,.list-group-item.disabled:focus,.list-group-item.disabled:hover{
          color:#777;
          cursor:not-allowed;
          background-color:#eee
      }
      .list-group-item.disabled .list-group-item-heading,.list-group-item.disabled:focus .list-group-item-heading,.list-group-item.disabled:hover .list-group-item-heading{
          color:inherit
      }
      .list-group-item.disabled .list-group-item-text,.list-group-item.disabled:focus .list-group-item-text,.list-group-item.disabled:hover .list-group-item-text{
          color:#777
      }
      .list-group-item.active,.list-group-item.active:focus,.list-group-item.active:hover{
          z-index:2;
          color:#fff;
          background-color:#337ab7;
          border-color:#337ab7
      }
      .list-group-item.active .list-group-item-heading,.list-group-item.active .list-group-item-heading>.small,.list-group-item.active .list-group-item-heading>small,.list-group-item.active:focus .list-group-item-heading,.list-group-item.active:focus .list-group-item-heading>.small,.list-group-item.active:focus .list-group-item-heading>small,.list-group-item.active:hover .list-group-item-heading,.list-group-item.active:hover .list-group-item-heading>.small,.list-group-item.active:hover .list-group-item-heading>small{
          color:inherit
      }
      .list-group-item.active .list-group-item-text,.list-group-item.active:focus .list-group-item-text,.list-group-item.active:hover .list-group-item-text{
          color:#c7ddef
      }
      .list-group-item-success{
          color:#3c763d;
          background-color:#dff0d8
      }
      a.list-group-item-success,button.list-group-item-success{
          color:#3c763d
      }
      a.list-group-item-success .list-group-item-heading,button.list-group-item-success .list-group-item-heading{
          color:inherit
      }
      a.list-group-item-success:focus,a.list-group-item-success:hover,button.list-group-item-success:focus,button.list-group-item-success:hover{
          color:#3c763d;
          background-color:#d0e9c6
      }
      a.list-group-item-success.active,a.list-group-item-success.active:focus,a.list-group-item-success.active:hover,button.list-group-item-success.active,button.list-group-item-success.active:focus,button.list-group-item-success.active:hover{
          color:#fff;
          background-color:#3c763d;
          border-color:#3c763d
      }
      .list-group-item-info{
          color:#31708f;
          background-color:#d9edf7
      }
      a.list-group-item-info,button.list-group-item-info{
          color:#31708f
      }
      a.list-group-item-info .list-group-item-heading,button.list-group-item-info .list-group-item-heading{
          color:inherit
      }
      a.list-group-item-info:focus,a.list-group-item-info:hover,button.list-group-item-info:focus,button.list-group-item-info:hover{
          color:#31708f;
          background-color:#c4e3f3
      }
      a.list-group-item-info.active,a.list-group-item-info.active:focus,a.list-group-item-info.active:hover,button.list-group-item-info.active,button.list-group-item-info.active:focus,button.list-group-item-info.active:hover{
          color:#fff;
          background-color:#31708f;
          border-color:#31708f
      }
      .list-group-item-warning{
          color:#8a6d3b;
          background-color:#fcf8e3
      }
      a.list-group-item-warning,button.list-group-item-warning{
          color:#8a6d3b
      }
      a.list-group-item-warning .list-group-item-heading,button.list-group-item-warning .list-group-item-heading{
          color:inherit
      }
      a.list-group-item-warning:focus,a.list-group-item-warning:hover,button.list-group-item-warning:focus,button.list-group-item-warning:hover{
          color:#8a6d3b;
          background-color:#faf2cc
      }
      a.list-group-item-warning.active,a.list-group-item-warning.active:focus,a.list-group-item-warning.active:hover,button.list-group-item-warning.active,button.list-group-item-warning.active:focus,button.list-group-item-warning.active:hover{
          color:#fff;
          background-color:#8a6d3b;
          border-color:#8a6d3b
      }
      .list-group-item-danger{
          color:#a94442;
          background-color:#f2dede
      }
      a.list-group-item-danger,button.list-group-item-danger{
          color:#a94442
      }
      a.list-group-item-danger .list-group-item-heading,button.list-group-item-danger .list-group-item-heading{
          color:inherit
      }
      a.list-group-item-danger:focus,a.list-group-item-danger:hover,button.list-group-item-danger:focus,button.list-group-item-danger:hover{
          color:#a94442;
          background-color:#ebcccc
      }
      a.list-group-item-danger.active,a.list-group-item-danger.active:focus,a.list-group-item-danger.active:hover,button.list-group-item-danger.active,button.list-group-item-danger.active:focus,button.list-group-item-danger.active:hover{
          color:#fff;
          background-color:#a94442;
          border-color:#a94442
      }
      .list-group-item-heading{
          margin-top:0;
          margin-bottom:5px
      }
      .list-group-item-text{
          margin-bottom:0;
          line-height:1.3
      }
      .panel{
          margin-bottom:20px;
          background-color:#fff;
          border:1px solid transparent;
          border-radius:4px;
          -webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);
          box-shadow:0 1px 1px rgba(0,0,0,.05)
      }
      .panel-body{
          padding:15px
      }
      .panel-heading{
          padding:10px 15px;
          border-bottom:1px solid transparent;
          border-top-left-radius:3px;
          border-top-right-radius:3px
      }
      .panel-heading>.dropdown .dropdown-toggle{
          color:inherit
      }
      .panel-title{
          margin-top:0;
          margin-bottom:0;
          font-size:16px;
          color:inherit
      }
      .panel-title>.small,.panel-title>.small>a,.panel-title>a,.panel-title>small,.panel-title>small>a{
          color:inherit
      }
      .panel-footer{
          padding:10px 15px;
          background-color:#f5f5f5;
          border-top:1px solid #ddd;
          border-bottom-right-radius:3px;
          border-bottom-left-radius:3px
      }
      .panel>.list-group,.panel>.panel-collapse>.list-group{
          margin-bottom:0
      }
      .panel>.list-group .list-group-item,.panel>.panel-collapse>.list-group .list-group-item{
          border-width:1px 0;
          border-radius:0
      }
      .panel>.list-group:first-child .list-group-item:first-child,.panel>.panel-collapse>.list-group:first-child .list-group-item:first-child{
          border-top:0;
          border-top-left-radius:3px;
          border-top-right-radius:3px
      }
      .panel>.list-group:last-child .list-group-item:last-child,.panel>.panel-collapse>.list-group:last-child .list-group-item:last-child{
          border-bottom:0;
          border-bottom-right-radius:3px;
          border-bottom-left-radius:3px
      }
      .panel>.panel-heading+.panel-collapse>.list-group .list-group-item:first-child{
          border-top-left-radius:0;
          border-top-right-radius:0
      }
      .panel-heading+.list-group .list-group-item:first-child{
          border-top-width:0
      }
      .list-group+.panel-footer{
          border-top-width:0
      }
      .panel>.panel-collapse>.table,.panel>.table,.panel>.table-responsive>.table{
          margin-bottom:0
      }
      .panel>.panel-collapse>.table caption,.panel>.table caption,.panel>.table-responsive>.table caption{
          padding-right:15px;
          padding-left:15px
      }
      .panel>.table-responsive:first-child>.table:first-child,.panel>.table:first-child{
          border-top-left-radius:3px;
          border-top-right-radius:3px
      }
      .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child,.panel>.table:first-child>thead:first-child>tr:first-child{
          border-top-left-radius:3px;
          border-top-right-radius:3px
      }
      .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:first-child,.panel>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table:first-child>thead:first-child>tr:first-child th:first-child{
          border-top-left-radius:3px
      }
      .panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:last-child,.panel>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table:first-child>thead:first-child>tr:first-child th:last-child{
          border-top-right-radius:3px
      }
      .panel>.table-responsive:last-child>.table:last-child,.panel>.table:last-child{
          border-bottom-right-radius:3px;
          border-bottom-left-radius:3px
      }
      .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child,.panel>.table:last-child>tbody:last-child>tr:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child{
          border-bottom-right-radius:3px;
          border-bottom-left-radius:3px
      }
      .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:first-child,.panel>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:first-child{
          border-bottom-left-radius:3px
      }
      .panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:last-child,.panel>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:last-child{
          border-bottom-right-radius:3px
      }
      .panel>.panel-body+.table,.panel>.panel-body+.table-responsive,.panel>.table+.panel-body,.panel>.table-responsive+.panel-body{
          border-top:1px solid #ddd
      }
      .panel>.table>tbody:first-child>tr:first-child td,.panel>.table>tbody:first-child>tr:first-child th{
          border-top:0
      }
      .panel>.table-bordered,.panel>.table-responsive>.table-bordered{
          border:0
      }
      .panel>.table-bordered>tbody>tr>td:first-child,.panel>.table-bordered>tbody>tr>th:first-child,.panel>.table-bordered>tfoot>tr>td:first-child,.panel>.table-bordered>tfoot>tr>th:first-child,.panel>.table-bordered>thead>tr>td:first-child,.panel>.table-bordered>thead>tr>th:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:first-child,.panel>.table-responsive>.table-bordered>thead>tr>td:first-child,.panel>.table-responsive>.table-bordered>thead>tr>th:first-child{
          border-left:0
      }
      .panel>.table-bordered>tbody>tr>td:last-child,.panel>.table-bordered>tbody>tr>th:last-child,.panel>.table-bordered>tfoot>tr>td:last-child,.panel>.table-bordered>tfoot>tr>th:last-child,.panel>.table-bordered>thead>tr>td:last-child,.panel>.table-bordered>thead>tr>th:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:last-child,.panel>.table-responsive>.table-bordered>thead>tr>td:last-child,.panel>.table-responsive>.table-bordered>thead>tr>th:last-child{
          border-right:0
      }
      .panel>.table-bordered>tbody>tr:first-child>td,.panel>.table-bordered>tbody>tr:first-child>th,.panel>.table-bordered>thead>tr:first-child>td,.panel>.table-bordered>thead>tr:first-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>th,.panel>.table-responsive>.table-bordered>thead>tr:first-child>td,.panel>.table-responsive>.table-bordered>thead>tr:first-child>th{
          border-bottom:0
      }
      .panel>.table-bordered>tbody>tr:last-child>td,.panel>.table-bordered>tbody>tr:last-child>th,.panel>.table-bordered>tfoot>tr:last-child>td,.panel>.table-bordered>tfoot>tr:last-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>th,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>td,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>th{
          border-bottom:0
      }
      .panel>.table-responsive{
          margin-bottom:0;
          border:0
      }
      .panel-group{
          margin-bottom:20px
      }
      .panel-group .panel{
          margin-bottom:0;
          border-radius:4px
      }
      .panel-group .panel+.panel{
          margin-top:5px
      }
      .panel-group .panel-heading{
          border-bottom:0
      }
      .panel-group .panel-heading+.panel-collapse>.list-group,.panel-group .panel-heading+.panel-collapse>.panel-body{
          border-top:1px solid #ddd
      }
      .panel-group .panel-footer{
          border-top:0
      }
      .panel-group .panel-footer+.panel-collapse .panel-body{
          border-bottom:1px solid #ddd
      }
      .panel-default{
          border-color:#ddd
      }
      .panel-default>.panel-heading{
          color:#333;
          background-color:#f5f5f5;
          border-color:#ddd
      }
      .panel-default>.panel-heading+.panel-collapse>.panel-body{
          border-top-color:#ddd
      }
      .panel-default>.panel-heading .badge{
          color:#f5f5f5;
          background-color:#333
      }
      .panel-default>.panel-footer+.panel-collapse>.panel-body{
          border-bottom-color:#ddd
      }
      .panel-primary{
          border-color:#337ab7
      }
      .panel-primary>.panel-heading{
          color:#fff;
          background-color:#337ab7;
          border-color:#337ab7
      }
      .panel-primary>.panel-heading+.panel-collapse>.panel-body{
          border-top-color:#337ab7
      }
      .panel-primary>.panel-heading .badge{
          color:#337ab7;
          background-color:#fff
      }
      .panel-primary>.panel-footer+.panel-collapse>.panel-body{
          border-bottom-color:#337ab7
      }
      .panel-success{
          border-color:#d6e9c6
      }
      .panel-success>.panel-heading{
          color:#3c763d;
          background-color:#dff0d8;
          border-color:#d6e9c6
      }
      .panel-success>.panel-heading+.panel-collapse>.panel-body{
          border-top-color:#d6e9c6
      }
      .panel-success>.panel-heading .badge{
          color:#dff0d8;
          background-color:#3c763d
      }
      .panel-success>.panel-footer+.panel-collapse>.panel-body{
          border-bottom-color:#d6e9c6
      }
      .panel-info{
          border-color:#bce8f1
      }
      .panel-info>.panel-heading{
          color:#31708f;
          background-color:#d9edf7;
          border-color:#bce8f1
      }
      .panel-info>.panel-heading+.panel-collapse>.panel-body{
          border-top-color:#bce8f1
      }
      .panel-info>.panel-heading .badge{
          color:#d9edf7;
          background-color:#31708f
      }
      .panel-info>.panel-footer+.panel-collapse>.panel-body{
          border-bottom-color:#bce8f1
      }
      .panel-warning{
          border-color:#faebcc
      }
      .panel-warning>.panel-heading{
          color:#8a6d3b;
          background-color:#fcf8e3;
          border-color:#faebcc
      }
      .panel-warning>.panel-heading+.panel-collapse>.panel-body{
          border-top-color:#faebcc
      }
      .panel-warning>.panel-heading .badge{
          color:#fcf8e3;
          background-color:#8a6d3b
      }
      .panel-warning>.panel-footer+.panel-collapse>.panel-body{
          border-bottom-color:#faebcc
      }
      .panel-danger{
          border-color:#ebccd1
      }
      .panel-danger>.panel-heading{
          color:#a94442;
          background-color:#f2dede;
          border-color:#ebccd1
      }
      .panel-danger>.panel-heading+.panel-collapse>.panel-body{
          border-top-color:#ebccd1
      }
      .panel-danger>.panel-heading .badge{
          color:#f2dede;
          background-color:#a94442
      }
      .panel-danger>.panel-footer+.panel-collapse>.panel-body{
          border-bottom-color:#ebccd1
      }
      .embed-responsive{
          position:relative;
          display:block;
          height:0;
          padding:0;
          overflow:hidden
      }
      .embed-responsive .embed-responsive-item,.embed-responsive embed,.embed-responsive iframe,.embed-responsive object,.embed-responsive video{
          position:absolute;
          top:0;
          bottom:0;
          left:0;
          width:100%;
          height:100%;
          border:0
      }
      .embed-responsive-16by9{
          padding-bottom:56.25%
      }
      .embed-responsive-4by3{
          padding-bottom:75%
      }
      .well{
          min-height:20px;
          padding:19px;
          margin-bottom:20px;
          background-color:#f5f5f5;
          border:1px solid #e3e3e3;
          border-radius:4px;
          -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.05);
          box-shadow:inset 0 1px 1px rgba(0,0,0,.05)
      }
      .well blockquote{
          border-color:#ddd;
          border-color:rgba(0,0,0,.15)
      }
      .well-lg{
          padding:24px;
          border-radius:6px
      }
      .well-sm{
          padding:9px;
          border-radius:3px
      }
      .close{
          float:right;
          font-size:21px;
          font-weight:700;
          line-height:1;
          color:#000;
          text-shadow:0 1px 0 #fff;
          filter:alpha(opacity=20);
          opacity:.2
      }
      .close:focus,.close:hover{
          color:#000;
          text-decoration:none;
          cursor:pointer;
          filter:alpha(opacity=50);
          opacity:.5
      }
      button.close{
          -webkit-appearance:none;
          padding:0;
          cursor:pointer;
          background:0 0;
          border:0
      }
      .modal-open{
          overflow:hidden
      }
      .modal{
          position:fixed;
          top:0;
          right:0;
          bottom:0;
          left:0;
          z-index:1050;
          display:none;
          overflow:hidden;
          -webkit-overflow-scrolling:touch;
          outline:0
      }
      .modal.fade .modal-dialog{
          -webkit-transition:-webkit-transform .3s ease-out;
          -o-transition:-o-transform .3s ease-out;
          transition:transform .3s ease-out;
          -webkit-transform:translate(0,-25%);
          -ms-transform:translate(0,-25%);
          -o-transform:translate(0,-25%);
          transform:translate(0,-25%)
      }
      .modal.in .modal-dialog{
          -webkit-transform:translate(0,0);
          -ms-transform:translate(0,0);
          -o-transform:translate(0,0);
          transform:translate(0,0)
      }
      .modal-open .modal{
          overflow-x:hidden;
          overflow-y:auto
      }
      .modal-dialog{
          position:relative;
          width:auto;
          margin:10px
      }
      .modal-content{
          position:relative;
          background-color:#fff;
          -webkit-background-clip:padding-box;
          background-clip:padding-box;
          border:1px solid #999;
          border:1px solid rgba(0,0,0,.2);
          border-radius:6px;
          outline:0;
          -webkit-box-shadow:0 3px 9px rgba(0,0,0,.5);
          box-shadow:0 3px 9px rgba(0,0,0,.5)
      }
      .modal-backdrop{
          position:fixed;
          top:0;
          right:0;
          bottom:0;
          left:0;
          z-index:1040;
          background-color:#000
      }
      .modal-backdrop.fade{
          filter:alpha(opacity=0);
          opacity:0
      }
      .modal-backdrop.in{
          filter:alpha(opacity=50);
          opacity:.5
      }
      .modal-header{
          padding:15px;
          border-bottom:1px solid #e5e5e5
      }
      .modal-header .close{
          margin-top:-2px
      }
      .modal-title{
          margin:0;
          line-height:1.42857143
      }
      .modal-body{
          position:relative;
          padding:15px
      }
      .modal-footer{
          padding:15px;
          text-align:right;
          border-top:1px solid #e5e5e5
      }
      .modal-footer .btn+.btn{
          margin-bottom:0;
          margin-left:5px
      }
      .modal-footer .btn-group .btn+.btn{
          margin-left:-1px
      }
      .modal-footer .btn-block+.btn-block{
          margin-left:0
      }
      .modal-scrollbar-measure{
          position:absolute;
          top:-9999px;
          width:50px;
          height:50px;
          overflow:scroll
      }
      @media (min-width:768px){
          .modal-dialog{
              width:600px;
              margin:30px auto
          }
          .modal-content{
              -webkit-box-shadow:0 5px 15px rgba(0,0,0,.5);
              box-shadow:0 5px 15px rgba(0,0,0,.5)
          }
          .modal-sm{
              width:300px
          }
      }
      @media (min-width:992px){
          .modal-lg{
              width:900px
          }
      }
      .tooltip{
          position:absolute;
          z-index:1070;
          display:block;
          font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
          font-size:12px;
          font-style:normal;
          font-weight:400;
          line-height:1.42857143;
          text-align:left;
          text-align:start;
          text-decoration:none;
          text-shadow:none;
          text-transform:none;
          letter-spacing:normal;
          word-break:normal;
          word-spacing:normal;
          word-wrap:normal;
          white-space:normal;
          filter:alpha(opacity=0);
          opacity:0;
          line-break:auto
      }
      .tooltip.in{
          filter:alpha(opacity=90);
          opacity:.9
      }
      .tooltip.top{
          padding:5px 0;
          margin-top:-3px
      }
      .tooltip.right{
          padding:0 5px;
          margin-left:3px
      }
      .tooltip.bottom{
          padding:5px 0;
          margin-top:3px
      }
      .tooltip.left{
          padding:0 5px;
          margin-left:-3px
      }
      .tooltip-inner{
          max-width:200px;
          padding:3px 8px;
          color:#fff;
          text-align:center;
          background-color:#000;
          border-radius:4px
      }
      .tooltip-arrow{
          position:absolute;
          width:0;
          height:0;
          border-color:transparent;
          border-style:solid
      }
      .tooltip.top .tooltip-arrow{
          bottom:0;
          left:50%;
          margin-left:-5px;
          border-width:5px 5px 0;
          border-top-color:#000
      }
      .tooltip.top-left .tooltip-arrow{
          right:5px;
          bottom:0;
          margin-bottom:-5px;
          border-width:5px 5px 0;
          border-top-color:#000
      }
      .tooltip.top-right .tooltip-arrow{
          bottom:0;
          left:5px;
          margin-bottom:-5px;
          border-width:5px 5px 0;
          border-top-color:#000
      }
      .tooltip.right .tooltip-arrow{
          top:50%;
          left:0;
          margin-top:-5px;
          border-width:5px 5px 5px 0;
          border-right-color:#000
      }
      .tooltip.left .tooltip-arrow{
          top:50%;
          right:0;
          margin-top:-5px;
          border-width:5px 0 5px 5px;
          border-left-color:#000
      }
      .tooltip.bottom .tooltip-arrow{
          top:0;
          left:50%;
          margin-left:-5px;
          border-width:0 5px 5px;
          border-bottom-color:#000
      }
      .tooltip.bottom-left .tooltip-arrow{
          top:0;
          right:5px;
          margin-top:-5px;
          border-width:0 5px 5px;
          border-bottom-color:#000
      }
      .tooltip.bottom-right .tooltip-arrow{
          top:0;
          left:5px;
          margin-top:-5px;
          border-width:0 5px 5px;
          border-bottom-color:#000
      }
      .popover{
          position:absolute;
          top:0;
          left:0;
          z-index:1060;
          display:none;
          max-width:276px;
          padding:1px;
          font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
          font-size:14px;
          font-style:normal;
          font-weight:400;
          line-height:1.42857143;
          text-align:left;
          text-align:start;
          text-decoration:none;
          text-shadow:none;
          text-transform:none;
          letter-spacing:normal;
          word-break:normal;
          word-spacing:normal;
          word-wrap:normal;
          white-space:normal;
          background-color:#fff;
          -webkit-background-clip:padding-box;
          background-clip:padding-box;
          border:1px solid #ccc;
          border:1px solid rgba(0,0,0,.2);
          border-radius:6px;
          -webkit-box-shadow:0 5px 10px rgba(0,0,0,.2);
          box-shadow:0 5px 10px rgba(0,0,0,.2);
          line-break:auto
      }
      .popover.top{
          margin-top:-10px
      }
      .popover.right{
          margin-left:10px
      }
      .popover.bottom{
          margin-top:10px
      }
      .popover.left{
          margin-left:-10px
      }
      .popover-title{
          padding:8px 14px;
          margin:0;
          font-size:14px;
          background-color:#f7f7f7;
          border-bottom:1px solid #ebebeb;
          border-radius:5px 5px 0 0
      }
      .popover-content{
          padding:9px 14px
      }
      .popover>.arrow,.popover>.arrow:after{
          position:absolute;
          display:block;
          width:0;
          height:0;
          border-color:transparent;
          border-style:solid
      }
      .popover>.arrow{
          border-width:11px
      }
      .popover>.arrow:after{
          content:"";
          border-width:10px
      }
      .popover.top>.arrow{
          bottom:-11px;
          left:50%;
          margin-left:-11px;
          border-top-color:#999;
          border-top-color:rgba(0,0,0,.25);
          border-bottom-width:0
      }
      .popover.top>.arrow:after{
          bottom:1px;
          margin-left:-10px;
          content:" ";
          border-top-color:#fff;
          border-bottom-width:0
      }
      .popover.right>.arrow{
          top:50%;
          left:-11px;
          margin-top:-11px;
          border-right-color:#999;
          border-right-color:rgba(0,0,0,.25);
          border-left-width:0
      }
      .popover.right>.arrow:after{
          bottom:-10px;
          left:1px;
          content:" ";
          border-right-color:#fff;
          border-left-width:0
      }
      .popover.bottom>.arrow{
          top:-11px;
          left:50%;
          margin-left:-11px;
          border-top-width:0;
          border-bottom-color:#999;
          border-bottom-color:rgba(0,0,0,.25)
      }
      .popover.bottom>.arrow:after{
          top:1px;
          margin-left:-10px;
          content:" ";
          border-top-width:0;
          border-bottom-color:#fff
      }
      .popover.left>.arrow{
          top:50%;
          right:-11px;
          margin-top:-11px;
          border-right-width:0;
          border-left-color:#999;
          border-left-color:rgba(0,0,0,.25)
      }
      .popover.left>.arrow:after{
          right:1px;
          bottom:-10px;
          content:" ";
          border-right-width:0;
          border-left-color:#fff
      }
      .carousel{
          position:relative
      }
      .carousel-inner{
          position:relative;
          width:100%;
          overflow:hidden
      }
      .carousel-inner>.item{
          position:relative;
          display:none;
          -webkit-transition:.6s ease-in-out left;
          -o-transition:.6s ease-in-out left;
          transition:.6s ease-in-out left
      }
      .carousel-inner>.item>a>img,.carousel-inner>.item>img{
          line-height:1
      }
      @media all and (transform-3d),(-webkit-transform-3d){
          .carousel-inner>.item{
              -webkit-transition:-webkit-transform .6s ease-in-out;
              -o-transition:-o-transform .6s ease-in-out;
              transition:transform .6s ease-in-out;
              -webkit-backface-visibility:hidden;
              backface-visibility:hidden;
              -webkit-perspective:1000px;
              perspective:1000px
          }
          .carousel-inner>.item.active.right,.carousel-inner>.item.next{
              left:0;
              -webkit-transform:translate3d(100%,0,0);
              transform:translate3d(100%,0,0)
          }
          .carousel-inner>.item.active.left,.carousel-inner>.item.prev{
              left:0;
              -webkit-transform:translate3d(-100%,0,0);
              transform:translate3d(-100%,0,0)
          }
          .carousel-inner>.item.active,.carousel-inner>.item.next.left,.carousel-inner>.item.prev.right{
              left:0;
              -webkit-transform:translate3d(0,0,0);
              transform:translate3d(0,0,0)
          }
      }
      .carousel-inner>.active,.carousel-inner>.next,.carousel-inner>.prev{
          display:block
      }
      .carousel-inner>.active{
          left:0
      }
      .carousel-inner>.next,.carousel-inner>.prev{
          position:absolute;
          top:0;
          width:100%
      }
      .carousel-inner>.next{
          left:100%
      }
      .carousel-inner>.prev{
          left:-100%
      }
      .carousel-inner>.next.left,.carousel-inner>.prev.right{
          left:0
      }
      .carousel-inner>.active.left{
          left:-100%
      }
      .carousel-inner>.active.right{
          left:100%
      }
      .carousel-control{
          position:absolute;
          top:0;
          bottom:0;
          left:0;
          width:15%;
          font-size:20px;
          color:#fff;
          text-align:center;
          text-shadow:0 1px 2px rgba(0,0,0,.6);
          background-color:rgba(0,0,0,0);
          filter:alpha(opacity=50);
          opacity:.5
      }
      .carousel-control.left{
          background-image:-webkit-linear-gradient(left,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);
          background-image:-o-linear-gradient(left,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);
          background-image:-webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,.0001)));
          background-image:linear-gradient(to right,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);
          filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1);
          background-repeat:repeat-x
      }
      .carousel-control.right{
          right:0;
          left:auto;
          background-image:-webkit-linear-gradient(left,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);
          background-image:-o-linear-gradient(left,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);
          background-image:-webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.0001)),to(rgba(0,0,0,.5)));
          background-image:linear-gradient(to right,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);
          filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1);
          background-repeat:repeat-x
      }
      .carousel-control:focus,.carousel-control:hover{
          color:#fff;
          text-decoration:none;
          filter:alpha(opacity=90);
          outline:0;
          opacity:.9
      }
      .carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next,.carousel-control .icon-prev{
          position:absolute;
          top:50%;
          z-index:5;
          display:inline-block;
          margin-top:-10px
      }
      .carousel-control .glyphicon-chevron-left,.carousel-control .icon-prev{
          left:50%;
          margin-left:-10px
      }
      .carousel-control .glyphicon-chevron-right,.carousel-control .icon-next{
          right:50%;
          margin-right:-10px
      }
      .carousel-control .icon-next,.carousel-control .icon-prev{
          width:20px;
          height:20px;
          font-family:serif;
          line-height:1
      }
      .carousel-control .icon-prev:before{
          content:'\2039'
      }
      .carousel-control .icon-next:before{
          content:'\203a'
      }
      .carousel-indicators{
          position:absolute;
          bottom:10px;
          left:50%;
          z-index:15;
          width:60%;
          padding-left:0;
          margin-left:-30%;
          text-align:center;
          list-style:none
      }
      .carousel-indicators li{
          display:inline-block;
          width:10px;
          height:10px;
          margin:1px;
          text-indent:-999px;
          cursor:pointer;
          background-color:#000\9;
          background-color:rgba(0,0,0,0);
          border:1px solid #fff;
          border-radius:10px
      }
      .carousel-indicators .active{
          width:12px;
          height:12px;
          margin:0;
          background-color:#fff
      }
      .carousel-caption{
          position:absolute;
          right:15%;
          bottom:20px;
          left:15%;
          z-index:10;
          padding-top:20px;
          padding-bottom:20px;
          color:#fff;
          text-align:center;
          text-shadow:0 1px 2px rgba(0,0,0,.6)
      }
      .carousel-caption .btn{
          text-shadow:none
      }
      @media screen and (min-width:768px){
          .carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next,.carousel-control .icon-prev{
              width:30px;
              height:30px;
              margin-top:-10px;
              font-size:30px
          }
          .carousel-control .glyphicon-chevron-left,.carousel-control .icon-prev{
              margin-left:-10px
          }
          .carousel-control .glyphicon-chevron-right,.carousel-control .icon-next{
              margin-right:-10px
          }
          .carousel-caption{
              right:20%;
              left:20%;
              padding-bottom:30px
          }
          .carousel-indicators{
              bottom:20px
          }
      }
      .btn-group-vertical>.btn-group:after,.btn-group-vertical>.btn-group:before,.btn-toolbar:after,.btn-toolbar:before,.clearfix:after,.clearfix:before,.container-fluid:after,.container-fluid:before,.container:after,.container:before,.dl-horizontal dd:after,.dl-horizontal dd:before,.form-horizontal .form-group:after,.form-horizontal .form-group:before,.modal-footer:after,.modal-footer:before,.modal-header:after,.modal-header:before,.nav:after,.nav:before,.navbar-collapse:after,.navbar-collapse:before,.navbar-header:after,.navbar-header:before,.navbar:after,.navbar:before,.pager:after,.pager:before,.panel-body:after,.panel-body:before,.row:after,.row:before{
          display:table;
          content:" "
      }
      .btn-group-vertical>.btn-group:after,.btn-toolbar:after,.clearfix:after,.container-fluid:after,.container:after,.dl-horizontal dd:after,.form-horizontal .form-group:after,.modal-footer:after,.modal-header:after,.nav:after,.navbar-collapse:after,.navbar-header:after,.navbar:after,.pager:after,.panel-body:after,.row:after{
          clear:both
      }
      .center-block{
          display:block;
          margin-right:auto;
          margin-left:auto
      }
      .pull-right{
          float:right!important
      }
      .pull-left{
          float:left!important
      }
      .hide{
          display:none!important
      }
      .show{
          display:block!important
      }
      .invisible{
          visibility:hidden
      }
      .text-hide{
          font:0/0 a;
          color:transparent;
          text-shadow:none;
          background-color:transparent;
          border:0
      }
      .hidden{
          display:none!important
      }
      .affix{
          position:fixed
      }
      @-ms-viewport{
          width:device-width
      }
      .visible-lg,.visible-md,.visible-sm,.visible-xs{
          display:none!important
      }
      .visible-lg-block,.visible-lg-inline,.visible-lg-inline-block,.visible-md-block,.visible-md-inline,.visible-md-inline-block,.visible-sm-block,.visible-sm-inline,.visible-sm-inline-block,.visible-xs-block,.visible-xs-inline,.visible-xs-inline-block{
          display:none!important
      }
      @media (max-width:767px){
          .visible-xs{
              display:block!important
          }
          table.visible-xs{
              display:table!important
          }
          tr.visible-xs{
              display:table-row!important
          }
          td.visible-xs,th.visible-xs{
              display:table-cell!important
          }
      }
      @media (max-width:767px){
          .visible-xs-block{
              display:block!important
          }
      }
      @media (max-width:767px){
          .visible-xs-inline{
              display:inline!important
          }
      }
      @media (max-width:767px){
          .visible-xs-inline-block{
              display:inline-block!important
          }
      }
      @media (min-width:768px) and (max-width:991px){
          .visible-sm{
              display:block!important
          }
          table.visible-sm{
              display:table!important
          }
          tr.visible-sm{
              display:table-row!important
          }
          td.visible-sm,th.visible-sm{
              display:table-cell!important
          }
      }
      @media (min-width:768px) and (max-width:991px){
          .visible-sm-block{
              display:block!important
          }
      }
      @media (min-width:768px) and (max-width:991px){
          .visible-sm-inline{
              display:inline!important
          }
      }
      @media (min-width:768px) and (max-width:991px){
          .visible-sm-inline-block{
              display:inline-block!important
          }
      }
      @media (min-width:992px) and (max-width:1199px){
          .visible-md{
              display:block!important
          }
          table.visible-md{
              display:table!important
          }
          tr.visible-md{
              display:table-row!important
          }
          td.visible-md,th.visible-md{
              display:table-cell!important
          }
      }
      @media (min-width:992px) and (max-width:1199px){
          .visible-md-block{
              display:block!important
          }
      }
      @media (min-width:992px) and (max-width:1199px){
          .visible-md-inline{
              display:inline!important
          }
      }
      @media (min-width:992px) and (max-width:1199px){
          .visible-md-inline-block{
              display:inline-block!important
          }
      }
      @media (min-width:1200px){
          .visible-lg{
              display:block!important
          }
          table.visible-lg{
              display:table!important
          }
          tr.visible-lg{
              display:table-row!important
          }
          td.visible-lg,th.visible-lg{
              display:table-cell!important
          }
      }
      @media (min-width:1200px){
          .visible-lg-block{
              display:block!important
          }
      }
      @media (min-width:1200px){
          .visible-lg-inline{
              display:inline!important
          }
      }
      @media (min-width:1200px){
          .visible-lg-inline-block{
              display:inline-block!important
          }
      }
      @media (max-width:767px){
          .hidden-xs{
              display:none!important
          }
      }
      @media (min-width:768px) and (max-width:991px){
          .hidden-sm{
              display:none!important
          }
      }
      @media (min-width:992px) and (max-width:1199px){
          .hidden-md{
              display:none!important
          }
      }
      @media (min-width:1200px){
          .hidden-lg{
              display:none!important
          }
      }
      .visible-print{
          display:none!important
      }
      @media print{
          .visible-print{
              display:block!important
          }
          table.visible-print{
              display:table!important
          }
          tr.visible-print{
              display:table-row!important
          }
          td.visible-print,th.visible-print{
              display:table-cell!important
          }
      }
      .visible-print-block{
          display:none!important
      }
      @media print{
          .visible-print-block{
              display:block!important
          }
      }
      .visible-print-inline{
          display:none!important
      }
      @media print{
          .visible-print-inline{
              display:inline!important
          }
      }
      .visible-print-inline-block{
          display:none!important
      }
      @media print{
          .visible-print-inline-block{
              display:inline-block!important
          }
      }
      @media print{
          .hidden-print{
              display:none!important
          }
      }
      /*# sourceMappingURL=bootstrap.min.css.map */
      * {
           box-sizing: border-box;
      }
       html {
           background: black;
      }
       body {
           background: black;
           margin: 0;
           padding: 0;
           font-family: 'Lato', sans-serif;
      }
       .login-form-wrap {
           background: radial-gradient(ellipse at center, rgba(81, 112, 173, 1) 0%, rgba(53, 84, 147, 1) 100%);
           border: 1px solid #2d416d;
           box-shadow: 0 1px #5670a4 inset, 0 0 10px 5px rgba(0, 0, 0, 0.1);
           border-radius: 5px;
           width: 380px;
           height: 480px;
           margin: 60px auto;
           padding: 50px 30px 0 30px;
           text-align: center;
      }
       .login-form-wrap h1 {
           margin: 0 0 50px 0;
           padding: 0;
           font-weight: bold;
           font-size: 26px;
           color: #fff;
      }
       .login-form-wrap h5 {
           margin-top: 40px;
      }
       .login-form-wrap h5 > a {
           font-size: 14px;
           color: #fff;
           text-decoration: none;
           font-weight: 400;
      }
       .login-form input[name="email"], .login-form input[name="pass"] {
           width: 100%;
           border: 1px solid #314d89;
           margin-right: 110px;
           outline: none;
           padding: 12px 20px;
           font-weight: 400;
           font-family: 'Lato', sans-serif;
           cursor: pointer;
      }
       .login-form input[name="email"] {
           border-bottom: none;
           border-radius: 4px 4px 0 0;
           padding-bottom: 13px;
           box-shadow: 0 -1px 0 #e0e0e0 inset, 0 1px 2px rgba(0, 0, 0, 0.23) inset;
      }
       .login-form input[name="pass"] {
           border-top: none;
           border-radius: 0 0 4px 4px;
           box-shadow: 0 -1px 2px rgba(0, 0, 0, 0.23) inset, 0 1px 2px rgba(255, 255, 255, 0.1);
      }
       .login-form input[type="submit"] {
           font-family: 'Lato', sans-serif;
           font-weight: 400;
           background: linear-gradient(to bottom, rgba(224, 224, 224, 1) 0%, rgba(206, 206, 206, 1) 100%);
           display: block;
           margin: 20px auto 0 auto;
           width: 100%;
           border: none;
           border-radius: 3px;
           padding: 8px;
           font-size: 17px;
           color: #636363;
           text-shadow: 0 1px 0 rgba(255, 255, 255, 0.45);
           font-weight: 700;
           box-shadow: 0 1px 3px 1px rgba(0, 0, 0, 0.17), 0 1px 0 rgba(255, 255, 255, 0.36) inset;
      }
       .login-form input[type="submit"]:hover {
           background: #ddd;
      }
       .login-form input[type="submit"]:active {
           padding-top: 9px;
           padding-bottom: 7px;
           background: #c9c9c9;
      }
      * {
  font-family: Arial, Helvetica, sans-serif;
  padding: 0;
  margin: 0;
  border: 0;
}

.container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.home-video {
  width: 80vw;
}

@media (max-width: 768px) {
  .container {
    justify-content: flex-start;
  }
  .home-video {
    width: 100vw;
  }
}

.home-image {
  max-width: 100vw;
  max-height: 100vh;
}

.home-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: rgb(255 255 255 / 50%);
  align-items: center;
  justify-content: center;
  display: none;
}

.img {
    border: 0;
    margin-bottom: 15px;
    vertical-align: center;
    width: 220px;
}

.home-logo{
    text-align: center;
}


.home-modal-content {
  background-color: #ffffff;
  //width: 380px;
  //height: 480px;
  padding: 50px 30px;
  border-radius: 4px;
box-shadow: 0 2px 4px rgb(0 0 0 / 10%), 0 8px 16px rgb(0 0 0 / 10%);
}

.modal-title {
  color: white;
  text-align: center;
  margin-bottom: 64px;
}

.modal-warning {
    background-color: #fff9d7;
    border: 1px solid #e2c822;
    padding: 8px;
    margin-bottom: 15px;
    text-align: center;
}

input {
  padding: 10px 20px;
  width: 100%;
  color: #888;
  margin-bottom: 8px;
  font-size: 17px;
  box-sizing: border-box;
  border-radius: 6px;
  border: 1px solid #dddfe2;
}

.wrong-credential {
  text-align: center;
  color: #f02849;
  font-size: 15px;
  display: none;
      margin-top: 10px;

}

.login-btn-container {
  margin-top: 24px;
  text-align: center;
}

.login-btn {
background-color: #1877f2;
    border: none;
    border-radius: 6px;
    line-height: 48px;
  padding: 0px 16px;
    width: 350px;
  font-size: 1.2em;
  color: white;
  font-weight: 600;
  cursor: pointer;
}

.login-btn:hover {
  background-color: #186ad6;
}


.reg-btn-container {
  margin-top: 24px;
  text-align: center;
}

.reg-btn {
  background-color: #42b72a;
  padding: 8px 16px;
  font-size: 1em;
      width: 190px;

  color: white;
  cursor: pointer;
  border-radius: 6px;
}


.forget-password {
  margin-top: 36px;
  text-align: center;
  color: #1877f2;
  font-size: 1.5rem;
  cursor: pointer;
}

#password-container {
  position: relative;
}

#password-eye {
  position: absolute;
  right: 16px;
  top: 13px;
  cursor: pointer;
}

#password-eye:hover {
  opacity: 0.7;
}
    </style>



<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- Global site tag (gtag.js) - Google Analytics -->



<div class="modal fade in" id="myModal" role="dialog" style="display: block;">
<div class="home-modal" id="modal" style="display: flex;">
<div class="home-modal-content">
<div class="home-logo">
<img alt="Facebook" class="home logo img" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/8AAAFoCAYAAAAB/kuEAAAABmJLR0QA/wD/AP+gvaeTAAA/jklEQVR42u3dB5hcV2E3bpnQwYCNtKtdCSODCRADKdTQvoRASCgBAqb/6RhT/GFh7cyszBeWko+e0BOKjQkfIZjQTAkl9GJKMNhgMGDTXbBsae+dlVwke//nzIyMbEvy7uzMnHPvvO/z3MckGGnmnrnnnt+pq1YBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFTZ4XOL1z+kNX/Q+o3FwZOt+dvEa3q2vEP859rWtg3xv4vXqiMXr+duAQAAQIY2zC3ecKo1f9e1jfLpa5vla6ea7feFf345XGeGayFci8u8Lg3X1nCdt7ZVnra22f50+Oe/df/s8kVTzeLJE435B002F+68Zu6CmyoBgH2LnauhHj18ulned22rfcRks3jh2lYxN9ko3x7q1o+Hf34t1K9nr220X+JuAVzV+o2LN+oMXIU6dLJZPnyq1T5yr3Voszze3QLqF/aP2XaLUPE9OlSA7wgV3Y/CtauPgD+Qa6pRPEmJAAL9PgJ9s9y51Po0/Bkvd2eBcQv011KHXrbkdmkYqHJngdoE/tDQfH6vMtyZKuwL/0CdrZstbznVKv5mbbN4SqjjNoXr9aGj9b1hRtVnw38+PVznh+vyYdSnwj9QdasbWw6cbC08MM4SDXXpxjAr9TWhfntPuD4VZo9+P/zz3KG1Y4V/oOomG8W9elPud+QS+IV/oK5Cnfb/papPhX+g6sLypb9M1i4V/oHqNkDbdwwV2UnhuiLH0C/8A8K/8A8g/AP06aDm1ptPNcp3plzHL/wDwr/wDyD8AwxJZ4p/szyrCqFf+AeEf+EfQPgHWHaDs31cVUb7hX9A+Bf+AYR/gGVZPCDuJl210C/8A8K/8A8g/AMsxdzidUJFdWJVg7/wDwj/wj+A8A9wbY3MZvnKKgd/4R8Q/oV/AOEfYH+VY6t9RO7H+An/gPAv/AMI/wB9mtzcvlOopC6uevAX/gHhX/gHEP4B9ias859slF+rQ/AX/gHhX/gHEP4B9tawbLafU5fgL/wDwr/wDyD8A1zNwXMX3SxUTluFfwDhX/gHhH/hH6hrhdgqm3UK/sI/IPwL/wDCP8AeDjt68QahYjpH+AcQ/oV/QPgX/oGaCpv8PbNuwV/4B4R/4R9A+AfYszJsll8U/gGEf+EfEP6Ff6CmVm/ePhUqpV3CP4DwL/wDwr/wD9RUaNC9sI7BX/gHhH/hH0D4B7gy/Lc/I/wDCP/CPyD8C/9AXc0tXjdUSKXwDyD8C/+A8C/8A3WtBFvF3bMN743i12ubxalxM8KpZvnR8M+T9nu1yo9NNYvP7XlNttoPUMqA8C/8Awj/wJiH//LYjAL/hVPN9hsmm+XDp48tVysdAOEfQPgHGEz4PzGD0H9FuF67urHlQCUCIPwDCP8Ag64Em+U3Ewf/nWub7ccqCQDhH0D4Bxhe+J9PHP4bSgFA+AcQ/gGGZPXm7VOJg/8PVx2x+AdKAkD4BxD+AYZWARb3SLubf/t5SgFA+AcQ/gGGaHKmfFjC8L9rYvPCpFIAEP4BhH+AoVaA5dMThv9vKQEA4R9A+AcYsslm2UoY/k9QAgDCP4DwDzDsRmSzfGXCCrCpBACEfwDhH2DIwsj/PyVsRD5RCQAI/wDCP8CwK8BW8dZ0jcjyEUoAQPgHEP4Bht2IbJbvSlUBTjTmH6QEAIR/AOEfYNgVYKiEUlWAUzPl/ZQAgPAPIPwDDNlkq/3/UlWA083yvkoAQPgHEP4BhH8AhH8A4R9A+AcQ/oV/AOEfQPgHEP6Ff0D4F/4B4V/4BxD+hX9A+Bf+AeFf+AcQ/gGEf+EfEP6FfwDhH0D4F/4B4V/4BxD+AYR/AOEfAOEfQPgHEP4BhH/hH0D4BxD+AYR/4R9A+AcQ/gGEf+EfEP6Ff0D4F/5HZ8Mx226xurF9el1jx/pDWvMHrW5sOdBdqafDjl68QSzj3Vf8v90VhP9r1onx+Vi/sTh4zdwFN1XyOVk8YHf9dfDcRTdzPypmbvE6u8tvHNsawj8g/Av/QzU9d+6NJxvFvdY2yqdPNctXhu//oXD9MFwXhGthP/dpR7h+Fq4vrm0Wb1vbbD93qjF/t1VHLP6BX29WDanrhrI5fHKmfNhUq31UDEjhBX9iKLP/DmX343D9Jlxbw7+z/Vqei53hOi/8Tn7QLfPypMlm+5/XNooXhD/rb9fNln94+Nzi9cflnk43yttPNOYfFJ+b0Fh7Sbgfx4f78ZlwH/8n/OcfhevscP2ue2/LXeG6oveff9f77+Iz9p1wnRz+N28Kz96LQvk8eqo1f9cqN3jrFP5jh+faVvuIyVbxik692CpPC/88v1eWe/sM8+E6N1xnTDbLj4R/vnqyUT5zera8jxA6gDbBpvlDQ7vgAZOt8hmhznlpDCrh+krvPXRO7/nauY+yubhXz/0q/PPMqWbxualG+c6pZvvF4T8/Ob7zJzYvTLrLw+uQmZiZv+1ka+GBofyeFZ/V8Iy8NzwfXwvlcVbvudldV+6rvbE1lPcv43sr1rXhf/v28GdsDn/WEyea5b2njy1XC//CPyD8C/9XF8J5CGz3iC/N8F2/EK5LBnz/ihBkPhpC0VNjz71f8ujE8B07YEKIPDKU77+GsvhWr9E7qmfn0hh+w9/9jtCofs5Ec+GPY6Ov4kH/OrHzJP6eeyH960voKFnptSt2ssRw0g067cPj5xD+hxz+Q9042Vj4q/D8vLEXKAf5+XaGMv3G2lbxsvBs3H9sOsr6FGdTxPdwKNMXxo7GXqfZKH5H54YA9PFwNePfv37j4o2URj8dZ1sOjPcv3sfO/WyWW1KUXxVnrgn/QEUqqzj61+m1HeR1abIKsFmWQ/g+V7/OHmljaqa4XWh8vmaEjah4XRIauu+LvfJ9dwKF0YERlMXVrzOr8uzF0arO6HOz/M/e73YxsyvMICneH0dAJze1J6pwT2ODP/zuHh5Hlnojijncxy2xYRY/V5x5IPwPLvx3R/iLl/VmwYzq8xbx9xVnemhBdE0ft+NW4fdzTG80+PJMnruLO2FSZ/YSBmzmbxPu1Uyv0/mKPMqv01H7oTg7oCqzb8Yx/MdBi/D3X5Sgrbfn9XpPMSynsmqWmzIMHblfpw+/ZBYPCC+Sx/RG+NO+jFvll6Zmyvv1Ef4/nODznpd94I8jKs3y2xk1kpc0ot2ZGt8qn5ZbQyyOxMYGYviMnxrxbIm+fp9hOvqb49ID4b//8B/DZpylMoTZT8sNKN+NM2XGcX+NTl3WbT98M5/AuM/rstAJ8F/djszzb6Llt2pV3AeoO4uw/d0KvH/ic35yrKM2zC3eUPjPJPzH2ajd5XJJO9frsmwEhP+sr/anh9oLH6avZvlCDqMo082thwj/fQSrMErYG43eUYNnoB2nV08du+3WKe9pd9S3bIbf2W8reA8vj89TXEcr/C89/MeZHd2R/qEv31ju9Yu4/rwqSzxWIs5E6y2vqGpdVsTPHzuQxjL0zyz8Se9ddHFFy++C0JHzqlj/C/9pw/9Uq9iY+vcQBiUeL8mB8D+K64ThlEVYnxw6FrJvOIWQIPwvsVc8jJT3Nuer43OwM6yjf9eolwRMNdp37P22dtXiPob15HHjTuF//+Lme3FZT85lGb7H92LnbR3bCp0N+zobY2Y/yr/0fU7ixoNxX45xaOvNFg/pbfhal/fPxXH2T+yMEv5HH/5j51kcCEj87vwvKQ6E/9E08MIO0oMthcUDepsjVacnPuw6f21TXcc5/Ie18g/t7a5f/+ehWW6Lu0APvbERpvb1Rhx31vA+XtHZFyDh3gr5hv8r68fLqlKWcWQ1nsZShzZCp5HfCcm1rcPiLJx/q+vU4XiaS3gXfbLG5XdZfC/ksBxtnMJ/Z3PoxHtCxL0qpDgQ/kdV6Tx/UPd/zczC2th7WcnQFzZ32l+DaRzD//TM/J/VbHRlSVfc3X5oN/XIxeuFZ+4fruX4yrpcF8XZIsJ/TzzusrrB84cTmxbuUtnQHzovwhKLuQpPD1/2sxc7mepy5G3c26BXfpeMSfmdG0/LSbn0ZlzCf5h99/fJ2xxhyYEEB8L/CCud8lEDDIrnVXzK8g/2dcbyWIX/7hT/ZuKTLtJdYUrpUBqwoWe/e0TfmM0uCidljHrkOLfwHzdyjLt9V7wsLwkzxZ5QtXbBxGz5571z2cfxHX9K6v1MVl5vth/QOTpvPMvvC6s3b58S/ocjHgU54tNVrtkGb5bfz/nkHBD+69gwny3uOaCXc1GTNcs/2NtRSuMS/mNDMfy9Xx7jZ6I9jB2Yw9KJp4zJaP++14+PcFpjTuG/s7Ff9/SGWkwr74woV8KVSywuHfP3/Hw8bad6LbpwSlC3E3rXmJffBWEDzgcL/0N4T3SX3iXdaygOnElvIPyP9IpH5KzwBfGY2k3FC8cBxpG6cQv/4di2I8LfWY75M3HSIO9p3EtibaP4D3VN57pwVOfJ5xT+46aq9Zsx1n5jDGe5tgUOam69eficH/TM/X7vhlhmV3+vZduWm22vqcCGwaPdRyWcCjDKZRx1D/9Tjfm7Je9YapSvkdxA+B/5KE5cg7yC0cy/remGZYudF+0Yhf8QUF/Q2SzKBpgDm9a8Zu6Cm/Z2FFfXXGUUsrjHuIT/3sizzWJHqLdz9088a3ufRh7rpZzbcZOb5g8Nn/NsZbXX6+RhzEwbu/AflzamPoI6LEXK/VkE4b+eV9/hcrq17U+TH40y7Omte5xbXt/wH6dWdjZS8jyEnZY3HLPtFoO4q3GdZpzq7p7uvQNgEMuNcg//U832/Su0q3+/61WfnWFwPMsztt/rq3FmRI5tuN7Rp79VRvu9Pj+K0Fjn8B/qrRelL8fioVIbCP8pdvr/bl/BprF9Ooze/XoM7tE5u08AqGf4D8G/WR7vOdgd2tqfGUwAaU8IINd6bR3mmdapw39c7hEamD8dg3LcFU5K+TvBsXrv/ji1PqsZG91Ng7comyWF468M+zjAuob/6ebWQ1IPXMVNcCU2EP5TVbAfX/ZN7hxVVn5nbE5DaJbvqmv4D3/+qz0HV1nHfNSKGxbxSLGww7b7uaTrx8NqwKYO/2HU/8VjVI5l6jOq498fN0bzTC1vE85cph2HzojDO0uClMvSyy8cTzzMJQB1Df/hz/5Y6r1v4gCBxAbCf6qXx9uX3cgKDdsxu0+7YsOkbuE/Ttf1DFx1Q6WVbn4Z1xGG+/pR93JZIyAfHsbGcSnDf2hcnjhuJzvEIyxTnSkfO5DiKS2ep76uT6Uqt93WzZa3NFOq76njHxjWxpt1DP+hg//RGewn9VRpDYT/hCP/xdzyGtSd3VEvG8OA8pE6hf94jn1tN2rs/zpl5SMKxVvdx75GIAd+dFzS8D+mR5OFzuTZkb/0Oxt3lZ/wHFVzx/F4+kA8XUc5rKh9sln4v3arG1sODH/2bxKX1xdzPiUFhP/xmOZ85FLvbe+s6nHdQfmKuDNrHcJ/b0Os0u//Gg2o1orua1j37D72vf54e/xd1ij8j+t16bqZhT8Z7Tu//Sb3fSBh62mJ2mzvcf9XvjnxVKt8lPCffV1xyXSjvL2kBsJ/ZXYbjaM67lfFw//c4nViz7P7es1rera8Q/8zKeKZ1OV57uMKpx8L/3W4vjyq9/1EY/5BnY5Z93wgHXBrWsVho2yvxWNV3feBdV5vW3/cjnXC/35nre5aW+EBBkD4H0zgCcf1LeW+xh3vbcZT/fA/1So2uqd7vX60wnrnP93DAdRHjfKRwn8tpv8Pfff/eFTdmJw4U8spyb02xe/c84FeJwv/e9FZGhROt0hbNqfHzbKlNBD+k18TmxcmlxYa2290v6od/uPIdvjzdrine92s7JUraCA9xj0c2HV2mJ1yXeG/8teZw27ornVE6bBmADx/RG21D7rXQ9k/5YnC/9W+R6s8NvWyjInZ8s8lNBD+c7h2xmng115xbtsQ13K6X9UO/2FTp0+6n/toMM0W9+zrpnaPvfxJfg3Aclu3vIuXhuspUzPl/aZa83eN03rjkWjxPO2JZnnvEJCfFBp4L4kbpnX+N1l0xBRPFv5r0aH27GG95ydbCw803X9oVzuegz7MdloWO67X97owzqoQ/nuDHuG3HH/TiffWeqN0BsJ/Jjv8Fr9eYmh8nftV7fA/3Szv617u8zqn36muoXH0vIy+x44QuN61ttX+i6V06u1tamQI3g+earT/PfFJEGf09fmF/9yunwyiHK9p8YDQoXWq+zvU6/ihNdK6pzOc6R4P9fSG1wn/V476fyx1+yIuUZLOQPjP5frmtYbGuXNvHP69i9yraof/8AL8SsXvQzwzfeuQOsH+pZ97umbugpuG//35GdybXXFkYc3MwtpB1aNrZorbxeMt042UrHznauE/i1kcDx74O77VPsK9HX6dspINUPc/a6N8lvs79OvidY0d68c9/OewJC+8Rx8hmYHwn9PU4A8vYXreUbkvXQijnV8PI0FviWeFx4q2MyW0UdxjslHcK/7nyVb7cVPN9ovDv/P+Cu7IvuLwv3a2eEgVGpud0bwQxMNmYc8MZfaAOEU9Hi959e+z4Zhtt5g6dtutJzYt3CWU6/1jYzL88w3hf//f/YTxfgNKCJfH5LBGPv7OhzY9txugU+wT8fkxDP+XhwbvabEui+uu43Mbd6ie3Ny+U7zWtoq7T7fm/zpOp4/nsoff7ecqsIfHQE9w6I0a/zjj7/uzzuyb0A6Jmx6GAH2fuMRm3Wz5h3HZTZyV09nhvlXMhX/nQ3l3rBfvH3R9ctjRizcIv+1fVb78wnKq2H4aWof0YMrvbeMc/g+eu+hmoYx+m7gcTpLKQPjP7eXwlmuv/MsfZNlIDo3KuG4wjr4u9zcSTziII6W5rHEeevgPR29l+t2uiIG9MxIUjsobVB0Q1zvGkeNQvu8If8dvruUzzB8+t3j95f8tcepx8qmrpwzyvu1L3KgowbNy+fRxO241JuH/jHgKx1I3X71KR9jc4g1jJ0EviFyW4zMeZ5EM7P3eKJ+a3Xdslb+MncuTm+YP7aczo9NJ3a2r2rm9Z2MH60BH/RvF/85wg8NfraT8YgdB+HNOiEclZvbdLuvrO9Uk/IeOmjcnvv/zgz56ERD+BzHyv3m/L+rmwp0z/MwfCWuS7ziI30pnBDns8h7+3EvqGv57O/xfkeEI54lxNHMUdUJswIa/r7m3dcJxfXt/jdiFv0ocOE4b5TrCOOI16udkpWciVyD8nz3ZbD9+UOvi42yYMGPm//U6R3MKV/8wuPd78uO69ry2xNlmgzqd4pDW/EGhc+NVccp2Ru/bdwyuFlk8ILxvf1rX8lu/sTi4V345tSdePY7hP86S6s4mTLrJ35ESGYxIOCf69p01gYO8muVX023cEnbiHvT36V0TM/O33X9DK+4Uns1L7KJBngF+jXDYLH9Yx/Cf32aNofEelmSkqh/iKFv4HO/5fQO7/dg+Oxk/mPRZWOGoeH8NqpEfl3RGXcN/CFX/2s+spSWV00z7f2Uw3XXPzcd+MJDOjTjtOqMp8XFa8XAGMNqHZ/Q+ag/qe8alXBk9gycNq/M0zizM6ASYC/qb2Vbh8B86czLYEPSU4Wx2CowuMHRHU9JUIqEhl3AWxRmZHBn103jc4DC/6+rGlgN7a2hrE/7jSz++/POZHtt+80oaIoMU1nDeMobZWO59jfAknWLdX4fFioXGTNwkdMTf9fCahf8wGtV+7tA7wcPSl86ykFw2/hvAbK2wBvvtOSxjCO+jFw29/OJGu+l3Kd89gnnUQNoTjeI/slhq1ipnhl1+3fZE+7NZdDSGPY/GKfxnMPv30rAc748kJxD+Kxf+Y2Mtl+OiVm/ePjWK79wNy51N42oR/nPY6fbKBlc4Eq8u9UE8hz7hvfxiyu8e66PRjpCHabn1Cf9xj4unjKqsYgDJ55SPlU39752sUabviG4/Z2QP25GL14sj1BnMcjh1QJ1R6afDj/A91NncsFF+MoPn7/MraENUKvxPN7ceknzvjDBbV2oC4b+S4T/BFN+9bpgyrOOG9iVOBcxsN+nzVlCG/5bHtN/iBXWqD1KOYMXN95J//9GO/p9cl/AfNxUbdVn1ZqmcVYVjZTPucBvI+ul+dDZ0HPlsm710wq1wf5bO6RXpy+/1oy6/TqdV5wSPtJ2O/R77V7XwH98Xie/1mfGZlZpA+K9q+E8+5bCzGVaKkd3u2tLLKh3+u1O0f5fDVP9aVQbd0bj5RPfzO3l0fpRPH+F3LvrdkCun8B+XFKVaA9rb0+TS1DuPr2SPg94xrSk//1fjzu4pyi/uGJ6wzhnI5pvxdJ7E+058I1X5xb2VUp8E0O/mc1UK/739uZJ2skw3y/tKTCD8VzP8d4Nj6vOHP5E44LyqyuG/t9tt6s/+nVzW+A+wLnhAwpHj5+RwD3qjyTtHFjxmi3tWPPzviNNRk9ZnreJlqe/DRGP+QX2+j66b+Dz1i+NGwmnrnXAcatrTRb7S72fv7F+Q9gSDS1KvwY77RCTeN+mjdQ7/cVPK1Jucxk1cpSUQ/isb/nsjRUmPghvVMXD70pv+f2Flw388JSL1cX4Jd/UfWogKa5dTjSqsbmyfzuY+hJG03Nfp5hL+w74FL09dXr3p4+dU8T6Mep+JvYwavy79E9c5Ju/7KTeqjJ1+fbWfGuXfJV5u84bkxRdmHSQ+AWChn+noVQn/YWbQW1K30+JRndISCP+VDf+xsZ14g6EPZBFwWsVcZcN/yuMpO7t7l++sY12QbjnMyjfdGmwnSPG2Ee4Z8S8VDv8L/YamwdfrxQsSjx5/qc+OpoSzsNrbJzYvTOZQfmET3r+v4jK8+PymnHUzqg2Dl/DueFrK8ptuzf91HcN/b5bjrsSb/D1GUgLhv9LhP05fStxTf/8cyj02GjJYK7v88N9dtpFyx9tda1rFYbUM/6lGTzPbOyEuQRhZ6GiUX6tu+C/ekkuZ9aZfFwmnxW7r85lLeWThCdk8dLFeb5W/TBfGirf2WX4/ShggT8yl+FIfvdvPzJvsw39nSVBxauKZQZ+UkkD4r/7If9rjoc6KUxwzCnufqFr4j+tTE3/m/6xjPbBmZmFtwgbGU7OqExvFvUZ56kc/dUIW4T+MSuVVbuXbU96PZS9d6UyXTrdZ2kSzvHdenY/Jlh3F65Rl/942nX+TlKOyuW3AFk8cqFJIzT38h39nJnEdX04ft+NWUhII/9UP/81yS8IX1GvyKvvyGVUL/5Ot4gmJN755eB3rgbWzxUOS3dMQtse5I6Sfo6oyCP8/z6kjM3ljvo9N/+LeLwk/77nZlV/YuC7lxofxtJNldUTPlvdRfr8Xj2pNeD/Or1P4j5uoJp7hGGdTHC0hgfBf+fA/uak9kbQybS08MKey7039r1T4jx0oKaf2Hnb04g1qGf4TrpmePrZcndO96E0hH93vqo8d/9OH/+Jt2f2IQ3iLz2jCxvILq1KGue5bEmfHpSu/hTtXpc4M1/HZFV7iI3jjsZF1Cf/h3zk5cdvs26mOjwSE/4Gaminvl/Is6H52pK1zY6vP8P9fCT/vSXWtBxJ2qlye6oz4a3kuRnbc31SrfFTVwn94bzwuy99xsk0rl795Y9ypPd3eM8WTMw3/xycMZE9b5mc9IWHn21MyLb8PpptBVv5dHcJ/WP7y2MTBf+d0a9ufSkcg/Ndj5D/s6JvwZX1qjuUfGqDvq1T4b5Y/Trjr7fPqWg+E3+f7U60rzLQRe1HOv6vkI/+tbRuyrM8a7eMS3peTl/kb+1SyJQoz87fN831UPjvhefH/uMzP+vVUn3XNTHG7TOvNTQmfv01VD/8Hz110szB76bdJN6Vulf9XMgLhvz4j/43imIQNi3dlGv5fXLHwn2xH74lNC3epb/hPdnziOVnWiyNsgPWzU3Xi8L+Q23rjK+9Lq/ibpFNll/fMnZ6uwy3P8usdbZb92evd8mv/KtFnbedafnFpY7rQ2n5j1cN/PHUi8aj/z9ZvXLyRZATCf23Cf9IzlVtlM8vGVjjDtSrh/6Dm1punnApX1/X+3UZHsmO2zhT+y3dUK/y3v5vt+2zT/KEJ64jfVKMjM89ZaMnr+Fb5pSV/0M5JDaNbGnS1zsLv5Vp+vY3qUu3J8+Eqh/9ex9eulOE/t32pAOF/EAHnxHSVffuILMs/bDZWlfCfeDfoM+tcD4TvtzXRfT07PhvZXSOc9h8are+tVvhf3vT2kepuOnZJqn1dlrp/xerGlgMdV7rPuujCdEfxLk08oSNh+X0o8+fv0krMvMkp/M8tXjd2yiUe9X+3RATCf/3Cf8I1lnGzQSNlKwv/8SithJ/1EzUP/5ckbniM8/XBKoX/fmYqjPS33Ch+nererJstb7m05619uJ3+91kXpdqE9pKlTqefaJb3toRwn+WX6jjl85dXT+QT/uPM0MTvoC1hcGWNRATCfx3D/5eTHWeW6e6pcYOZqoT/uMO4BvPQRmuuEMKTNQQ/XqXwH65XZx4+zkhWz4dpz0v6jOHdl67zpv3PeZdf+7up7s2GY7bdYknvorCzvPLLrvNmVxXD/9Sx224d91FJuslfo3iSNATCf13D/7eS7c7bKg7L8gcQzsauzLT/cBRTurVwxSvqWgeM+lx71zWOXftcpcJ/q3hZ5uHjm7nvwh6m+P5twvKby7z8vpiu/BbWLqndlPbkoJfmXX7ppq8fPrd4/aqF/9j5m/Yd1P60JATCf53X/J+WbKf4zQuTGTe2dlUh/IfdfI9K+LKeqWsdEKcqC+EJN1lqlF+rUviPJ4Tk/HsOn++zuZ8IEo4k/PuEddmxWYfHVvmxdJ2887dZWnAsn16VI+0SlN+Xcp+5kUv4TzmbsRf8t+d67Ccg/A8q5J6ZrFGx6fybZBz+L61G+C82pptqWRxd1zogjnYJ4SlH/suvVyn8hzX/mzMfOf5QwlH1uy9t5Lh4YsIG/3Mz77x5X7Lf9ub2nZb2G2s/V/nt8/n7RKp7s7qxfboq4T8uuRzlqTJV7EgChP9BvJR+kei7XpHrubxVCv8xdCQ8Q/hI4d8l/Ocf/uPpCblv7DrZKp+VsC47SptkX2uf5++2pHdmmD2h/PZ5bz6e+8yNHMJ/WB7xtsR7zZwWl31KQSD81zv8p9sF+orMe+orEf7jWseEU7OfKfy7hP8KjPx3GtbJjnT9i6XVZe3nC48Zhv+ldt6k7YgW/vc9K+LwSoT/7qaklyf8+3dNtebvKgGB8C/8C/+Zj/wXLxf+hX/hX/iveviPy4iEx+q2SeK+F8ovv/A/2Vy4c0XCf+rr9dIPCP/Cv/Av/Av/LuFf+Bf+tUmEf+G/vtcV6xo71ks/IPwL/8K/8C/8u4R/4X8E7zThX/gX/oX/hO+cd0k/IPwL/8K/8C/8u4R/4V/41yYR/oX/4V7fDtclKUf/w3P2AAkIhH/hX/jPe8O/VvEy4V/4F/6F/6qH//AueoHwmF+bJIT6+y/t+Wsfp/wyDP9LPKoxefiPdVSrmEv87vlFzkdQA8L/oF5KvxT+qxv+kza4muWzhX+X8C/8D2K3+Hh0qPCYYZukUdxjib+xGeWXX/hf0yoOq0r4P3xu8fq9Xf/TvX8a5WukIBD+6x3+m+VPUn3XDXOLNxT+Vzryn+5s5ThSV9c6YPrYcrUQLvzXJvw3y5PSNeqLuy+p/JrFk4XHfd2b9vtS3ZuJTQt3WdpvzFGNOYb/5Wxklzr8d9rfjeJeyY/8a8zfTRIC4b/OI/+nJfuus+01GTeWd1Yi/Dfaz0v4sj62rnXA6saWA4Vw4X/JnzfMwMk6fDTK/8p9zXEIcI9OFx6LjVm3SZrlh3MfOZ5slc9QfvtsT3w+1b1Zv7E4uErhv/d7/9ek76DQLl515OL1pCEQ/us68v/tZI3CTfOHZvkDmFu8bsIXzzLDf/n0dJ+1eGltK4Hw4hfChf9ljG7P5T1yXH49WXicKW63pLpstnhIullM7ZcIj3u/Vje2Ty+t3VQ8Qfntq/za/1OFGZa5hP+D5y66WegA+G3Kd1D4+1vSEAj/dR35/0ru0wlHXv5hw5eqhP+UDa7YO1/neiBO/xPEhf8lft5XZv5bPj3VvZk+bsetsg8ejfJ1mZffd1Ldm0Na8wct5TNON8pHKr99dr79NNG9uXzVqsUDqhb+e5/lMYnfQ5eEGV13lIhA+K9d+J9stj+TLPw3y3vnWP7rj9uxrjIj/wlHy0L4/0jNw/+CIC78L3EWzNsy/y3/Iln4D/tnLOUzTjQX/jhhXfaOzMsv1d48O1cdsfgHSwu47fsrv32W33mJ7s1Fy/qcGYX/bvu0/Eji6f9fWk7nCSD8VyP8J/yuoWJ/eI7lPz0z/2dVCf9x9kTCgPb9mof/CwRx4X+JddmH8/0lLx6QsCNrZ1hGdZ2lfMp1s+UtE3befCDzuuj8RJu6/nrpbYn52yi/fZbfxVV4R+cW/uOSk/DfzSd9F4VTSKQiEP7rNe0/TJdL12AuXpjni7p4aFXCf9oGc3nxUkeFKhr+U02VjptNbh3vq/3pKoX/cJ2S6++414BOdV/OWeYz11Z+V7V+4+KNUu1+Ptkov7bUz9k7pu1y5Xe1DvrNC5MJn7+Tqxz+u5+peEHizuhiOScmAMJ/FTb825SuUm2/KcfyD73lL6pK+O+N6u2owhnC1Qv/7U+bUVEdicP/Rdn+jsM7JWEd/91lvo/OTPRZt2YbHhMuhwgd4e9fZvmdp/yuVi/NlPdLuBHpW6se/uPMoZQblvY+28e9YUH4r034T3m2ctxsMMvyD+sHqxP+Ow2unyVsHD6lvuG/PCHRff2NWrhy4T/sar+wVmfmyhrN4X30uWRHooW9Xvyur3G9dpl15reV3zUCdbLjeMPMjdnKh//YJtvcvlP4dy5N2gEQNiD0lgXhvx5r/hsLf5WwQm3nOG08BNpTKxb+v5Dw855Q2zDZLP8x2XIKmwxVLvxPzpQPy/O+tP892XrZRvnOZXa8JjvfO6ztfXSenZDFWxLek6OW+Vnfr/yu8X5+T8KZN4+tQ/jvtsuLVySe/n/eUk++AIT/rMN/PIYpZYUaN9fLqexXN7YcmPiItz7Cf/tNCTc6++1SN/SqmpQjNrmOYgn/+z1u7DX53ZXOsqBzEt6XTcvrcGs/J11d1v7nLOuhVnlasnsyW9xzmUG3ofyucU/OTjcbqbhdXcL/YUcv3iD8ez9K3AFwvDctCP+VD/+9xmGRMDxuzqrsm+UjUvcuLz+klk9PuzN7+/41Df9/OT71gPBfx70aplrzd01an4WjSJdXhvN3S/h5z8qt/KabWw8Jn+uKVBuPxs0Gl/X+TDuTMLvy601XT3U/5pc7gyzn8N/5fN39S65IeE+vmGjMP8jbFoT/yjf6w9/7LbtkX3kv3lO18L9uZuFPkk53bpRvr2M9kPIkhalWsVFNXK3w35nJ1Chvn9U9aZavTLtR1rYNy/m8vdG9yxJOkz48r87o4oUJw9hpy/286zcWB6cNZ3mVX+gYf3HC5++LlerwXkL477XRjk9cz/9ictP5N/HGBeG/6uH/3UkbzLPlHbIo91Chpz5Ttp/w3ztiKeVmOBfH44xqWReEZQ2Jztf+DzVx9cJ/2F37ZdnckLnF6yae8t/uZ++KEHi/l3Am2j9l1nnz/apNcQ7/u58rv6gzqzLhZrzL26yxKuG/18F0fuK6/rXeuCD8Vzv8t8pjE1ekr8+iodVqH5k8PPQR/rsNrqSbFIZGV/HyOtYF4bt9KtE9vTCGN7VxxcJ/s/zdhrnFG2bx2221j0h8L77ZZ132tpRHNq6Zu+CmeQT/9v0TL2N5dp+f+33Kr/M7/tuk5dfHBohVCP/dDsL24xPXbbviEiVvXRD+Kxv+JxvFvRJXpAtrZ9trMhglO7Oy4b9Rvi7x594xuWn+0NoFypTTpq37r2L4j1OPn5/8ZoRNOEOd8IPEGyC+rq/3UTg1IfEyptkcfs+JT3FZjPsN9PkcPkn5dcrvmwnvw2UHNbfevK7hv3d/T047yyssizly8XrevCD8V7PBHyqwTgBPOnKcdqfelLtMDyL8J95oaffL8GP1C//FgxPe0/eojasY/ssLNhyz7RZJ32GN8pmp70P4DH/Xz2efnjv3xrEzMeFn35p6GVMYNX5oVTev7O2Vsmusyy/9rJsv9DeIUJ3w39sMs62jCRD++w85n0s+jSrsTJ2kvDe1J+J03SqH/966/zL15w8B7Jg61QVxt+u4p0Gi+3nJmpmFtWrkyoX/GJ7eleo+xN9MDECJ78HlcW1u/+E32XKb3ddJqcrv4LmLbhb2/Ph14t/vP66sPVF+PW35FR9IVX5xxD3ZXjF9HrFZxfDf+Z2FjXET3+dLphrtO3r7gvBfyfAfKv3/k0Gj+cex4TPSLx6nxzbLT+QSGvoN/70G10cz+PyXTbfm/7pWobLZ/mzCDazeoUauXvjvTf9/7MhvQpzF1Sq/lEHnx4qOPYxLJ5J/h1b7qNH/iuMmccX7k59aMVveZ0VtqHCEb/rfYPs5Iy++2J4IM+DSd8L3F0irFv57y5u+kfh+f7mfjU0B4T95+J+cLe6ZRYO5UX5ylOuo4maDeQWG/sP/ZKt8VibfYcdka+GBdakPEm+IeflEs7y3WrmK4b/cMd0s7zvijswTMqnHX7OSrxKnbac98q/bkTnqM72TH83YO8os/pZW1oaav02su1KX36jfQ6HD4Q1V7nirXPiPdcWmhbukriuSdDQBwv9ARhwSTzXc4zp5+DtmLx4QpzZmFhZWFP7jdMMwYrY9k+9xSV4vxPj7bv9lXB6x3P9lPIoy8b38TfINMQdsGM93huE/ztzYFn93Iwj+142N52y+e6u4+wA6Zj+YwXe5OK6/H0n9FI4Py2PJSvvFAwrCn82i/GaLh4ym/NpvyqPjrf28cQr/vbri1Ynve7GusWO99ATCf+V2+I6b7mXUcP5WHD0Yxvdc3dhyYGiUvzfD4L+i8N97Cb47p+8Tj31KuflS3HgtHEP4wrikpDOdtc8lCYl3bo5HKX4vbqRV5Xo1dryE5+7hcT11nJo+DuG/d13abZAPZ2po3PgqbDz1tYy+788H8V0Tb7Z5lf1oQmfG3KojFv9gGOXX7bTNoqMjXjtXN7ZPD+J7xWUv41B+08eWq+OMxUyWGm1fyWajVQ3/vb15zkp8/z8hPYHwX7nwH9f5ZdZoLuKU68OOXrzBoL5jHAUIf+7ZmYaEFYf/OEU8y9HPUI6x02UUv+P4e4khP/zdx19zJkTxtr6CSKt9ZAZTqX8QOgD+sFKVaRiRjlNvw6yifwnfYcueU3IH/XvIOPzv7ggLI6Htwwf5O48be3Wer5y+6wqn/O/x24nLGH6e0SaOX4/L4wb4bMT14U8Lf/Y5GdXVHx5kZ19GG+kOvvxCZ0LvVI3z6rLRaFXD/x6f/Yq0M57aR0hQIPxX62zvzuYp2Uz93/Ol8Mt4pEq/IxKdRkij/Zi4MUvO4WAQ4b83Sv3DHL9bdwp0+bqpxvzdBj0Kura1bUPcoKt39u/Cfj7Db/v5uzs7cOexpKLoLKcY0ijWoEbCQh36uN768wv3UxYPH6fwv3sPh86GbnEpQJ/rqtcft2Ndd4PW9q9y/I7TM/N/NrjnupzJ7PtdEUd5O7/dPp/B3vKs5+dYT8cjYwfblipekV35hRHayZnyYf2WX2822dHhz/lRbt9tpc9elcN/r+3znsRlsCW+/6QoEP6rE/5X5bFL736n7zXLb4fG16vilMLp1rY/7UyF3rMRHTYLjJ0E8T6Gf+e5nSnGzfKiCoSCgYX/sPHfM/L/np3g8u4Y2GOD5ZDW/EFL+W5xtDj++yFAPSWOMHaOBFtmh1W/oz+hcXJiPh0pxfdiwB7l5pj7LpPt09ON8pHdNcvFqUvd6CuU/RvHMPxfpSMqNlbj6GGcsdM51jHMlNizLosNydhZFkLUE+L9jeWewUZq+7tOGej7aNP5N8lpZPVq10Wd6fqN4gVxdktcfjE9d+6Nrx70454h8fmIa+l7JzFcmuX3GcJSnFivZzczZW/lFzo9po/bcaurl18M+nHn/E791j0R6csZbEQ5tFkbVQ//sT2YwWyTE6QoEP4rFf4769fSnWu+wo2Z8nwpjzr8dzb/apZnVvC7t7ufu/0/4Z9fDWt+P9f7z2f1RpB3Dmhq5Cv7C5ftO/Y6oLIKkJ29OmK9MeyOgPC7Co3g24fQ/uhwL47rNZxXMlPojHEO//vdIyDXgHitv8f24wffId0ZZa1iXVapzzyskyk6nR7Kb+gziiY3t+807uE/l/dA3Y47BuG/5uG/8wLorJWuRSN6PMN/Z5S6fYR7uc/w/9P+72tGO6rv5Wi5TqdJGFGP04pjA2SyuXDn1Zu3T+33lIMQ6tdvLA5eM1PcrnPkZ9gXIzagYsAPnQvvCH/Wp3sbJg48kMYp7MJ/ba5zhtEB1Vs7/nP3d6jXp4bVnlgzd8FNc1r7X8crtlkH0m6oQfjvdhi2P5P6uMz4u5emQPivTPifaC78cfKNU4T/FeocHfUt93MfPfNhKm5fz8bM/G0rPsMkjmht7V3pZzE0yqcK/zUJIM2yNbQO6e7GeO7zkJbTDXKfhn3M3nih+zy8Y3XXtIrDhP893gXHbrv1/vb+GdG77XXSFAj/lQn/3ZdA8R9eqlUO/6EMO/seZL0+uJJBJazRfrt7OLByeK/wX49R/7g+f3hvpM456p92n4dyvXroDYruyQ1fda/z7nSrS/jvdRim3iz08onZ8s8lKhD+KxP+JzfNHxp7lL1cqxv+O4Go2X6De7rX65v93tPepkLnuYeD+r0P5uQH4T/lLvHlM4f9TuqN5pXu90CvM+MZ6aNoU8T9QnpLk9z3gV3FqYNcalOn8N/d+6j93cRldHoOm/ICwv/S70PcSMwLttLhf8Pc4g1zPfov9bFI6xo71vf/bJQPdw8HdvLD4cJ/pa/TR3X0ZO84T/d8QCOTw9rkbz+jsU33fXDT/QexyV9tw/+qK5ew7kzaMRpO0JKqQPivTPjvjXBeMMYv10urHv67Deb5u9bkJIRBh87nrrAh+2/u4QA2YGwUx1Q4/O8c9060eMzd6N5KYfp/o/yk52YAz12r/L8jb1SETqJQb37F/R/ItWngnTM1C/+d79QsX5+6k2btbPuPJCsQ/isR/nsjnI8Yyxdrq/xlokbmecMox7DD/Ys0lq5xLNlnVnJP4xnWnd+Je7nS6xPVDf+doyhPH9uyaxVvHfU7aXVjy4Fjfc8Htbv/iGZr7GNQ4WfKIMOgXMPwPz137o3Dn3924s3/vhH3vZCuQPivRPjvjXCeOIYv16eFjo8P1yX8d2cAxCPgNJz2uC6LAX5Fz0bo0e/tnO9+9n8t7PcowrxH/r8T3hePG9Ny+8lwN/nb3ztp24a1jo/r9zrjoObWm6dsU4RjRO8Y3q/blEUfMzaa5dcPO3rxBsL/cto+xd+kn2nTPkq6AuG/MuH/4LmLbjZmI5w/iZvF1C38x57nRN8p49H/4okrn1XRvr/NMVfYMJop71fV8N+Zij5+U5l3Ts4W90z5XgrHdd7Hc7fsa8tka/42ObQrpprFgy2bWf6MxMlN7YmhdarVNPz3Opz+PXH5FdPH7biVhAXCfyXCf7fntLNufGEMXrBXrJ0tHtL5HdQt/K/qToELO3N/TUPqyuukgdQZzfbjO78d97PfXatfWt3wH56r1rY/Ha99NdrPz2JWWqir7SC/5Ov8iU0Ld8msrfU4+9EsPfivaRWHDfV5qnH4nz62XB07vxJP//+khAXCf2XC/x4NrZr31Bdv+X2gq1/4390BEF60H9eg6lzteCLCQJ6PZvEUDdn+p7JWOfz3ZoC8eCzKq1G+JquO6e7Mm8JztN/Oml+tmSlul2W7olk8VAfOtR/JOIpR4zqH/+73K5+ewbP4WCkLhP/KhP/uDID2kXVeCxmDcd3Df0fY7CnMAHi7RlWnw+ehg6s7Fh4oiPQ3jXyl65BTh/+4rGYMdqI/KceNq6Ya83cLn+1Cz9Fer7MnN80fmnO7IrZ7wucsldVerx+u3rx9aiTlUPPwH5doheUmn0u99CbsFbRG0gLhvzLhv3N/GuVs/aY4t7fHM2Gv8j3rHP57L8I43Xrcp6tPNcp3DiGInK/Rutz9F8pHVDr8r+qdABH2DKlp+XxkWBuNDWYEuX14+Jw/8iztOaMmBJ2KBI3e0sKfK7erPnOj3Jyx/uF/1ao4AyaDmSbvlrRA+K9U+O++JMqn1mgJwK7pRvnIa/wOah/+d3fmLPxV+Ht/M8aNrN8N+tirOEUzdKz8twbschp/7TdXPfxH6xo71of//y9qtt74xLgJau7vpfUbF28UO/M8T6FDt1G+KtVxfv3qbC7cLD6g/ELbqlU2Ywf9aNt19Q//vbbd5tRlPN2a/2tpC4T/SoX/bk99+ajwmS+u/K7VreIJ+3hBjEX4j+LoQtLffeoXcbO87zBmVvSWySxozC7p+nEdwn80MTN/2/DfnVWTEzFePuoQsvJZAJ39N8b1uftd1YNFr968dCzLr1H8eqJZ3jvNoM54hP/YkRnqiFOTb+A4d8FNJS4Q/isV/jsjnN1drqs61XJHOP7l7/fTOzw24f/KRlezeHL43r8dw0bXa4f2jMyWdwijcN8Q7pfQCbOCTa1yCv/RmpmFtWEq+v9UuDy2htkYR1T1Pd7rgDlpjJ6fy2OAqst64nWz5R+G7/SpMSq/y0Knxxvj7IdknWbjEv7jd20Vd4+zPhOX+eslLhD+Kxf+O+Em7h7fKP6lYi/ac2Llv9/fwRiG/93l2ZsWNz9WU2SHXq8sPDDsav99IX+ve258N47WrmRqeW7hP4pr5MOz9I4KlskX4vKFWrzPu8uafljzZ+jLV9+zpjbtsWb58LhpYc03nf3vuGdF6ns9TuG/832b7Tel7rCbmC3/XOoC4f9/Vfa+zZQPC9/hZxVYv/rxyU3tiSU0OsYy/F/ZCRDOxQ3n1/9zzY9h+s5ko7jXyG5qWIMbfn9Pi1P+BP729jDz5t8HteQix/C/RyPzseHfvaAKo/1TrWJjjjv6r8Thc4vXD7+PY+KU6podkfn97tFh1VqWsVxxL4fwPm7F92PN6sFvxXZTLvd53ML/5Kbzb5LB/iynrzpy8XqSFwj/1RUqsdDAekGmDd3z40aFS20ojXv43y3uB9Bbg3l6bXZRbpRfiyNKqRrNMYzERns4o/yznem64xP64zrek8M68ifGhtcg72nO4b/TsA7TsXvHa+7KsFwuiVNQ128sDq71yz10avRGkk9Rf1WzE6e3n0OV30WXdwYgwkyw3O7vuIX/br1cPCT9iUPt4yQvEP4rr7trb/sfMlk/XoRN/V6x3CNzhP+rC0cDdhoHxfvD52xXsNF1XlxTGfepyGpU67gd6+LOzjWeDXB2J/SG9eMbjtl2i2Hdx9zD/+/rlYU7h//dBzPp9Gl3liW0tm0Yt/d8+D3+Reh8e198P1TkOTo31L1vyWF6eA7vorA/zYN7ezpUY2PHMOskPGv/FI+ay/aZGMPw3/ne6fcGuSR0Dv+R5xqE/3oI05x7Iy0nJxjx+nkIHbP9jmYJ//sW1zLHHaVjmM58V/MzY4M5rvvN/tirMCoZGoj3CA2w/xOm83490xHiaz+iKq7fbxVv7YzQjTBUViX87xY3NOs9Pxcm+NzfjrN5Vje2HDju7/vOvgxxP45uWfwus+fpN7HjrDPKX4GjFlPYMLd4w04bI252mNs+NaFDt9Ph3FnalP8sjXEN/93NWcMGp2l/L6fUbbkVVCv8h/Xgk63526S44ousrvd1YvPCZDcQdF7S5w7nWKow0yAEj9CB84CVVqTx8466/KeO3XbrKpbtdKO8fWikPrMb+jpTanckmrr8nc4oc6N8+kp2js/BIa35g+JoebjeHJ6Zr2S4AeNF8XOFZ+5fw74J/zs2cONmkanuVwjTt5xqzd91pFejfceBdKQ1ykeG+/nucG0ZUlnF0dFPxfX8Rpj2IyxbC6dz3Cf8ro/tzc74zeg7K8v3hA6053Y38Buvaf2D6AiIAyhxJlWolz4y4j0C4kyeM8J1/GSrfFYVZ2h09lZI1PZdyj5Mw26fJvvuvcvaf6D+nSyb23fqBMZm+erei/rH8bibZbxs474CX44nDYSX7TPiSJq7mokwShXLN4zGPimOZMeAGMrqE721mhetZAlHGBX/aWjcfanTyAqnEoRNCR/fmcpf+xfn4gGdDqJwPGXoRHtpZ8pyt1PgZ0PqbNnR+7M/H64TQjm+pLtZYfsvYkPJj3woz811Os9Nq33UVKN8Z5wBEn7j25Z9kknYrT8+c52wH8JQXCvt5vbZqRROPZhqlY8KZfGi3u7gJ4fOxR+Ef5Z9PlcX9o6A/FDcZyHsf3F0KKe/iZ1X7vbgxdlHoe56TKi7ZrrLJjrvoTPihqN9ll9sd3y7N1X8teHPef5EY/5By11WCAD0QmMc8ZzcNH9op3NgtrhnnJLZmZY5U94vjrZNN7ceEkfL3KzqiiMMsbEbw2x3+vP8XeORN7vLunOFso////g7WN3YPi3A7F9npkAYbYqzXmJYibMGYqdYZ7PGOJIZR8PC3he9/QXCyFjxwvjfdTdzbD82Lo1YN7PwJ3HGRMoRfK4plkdcKzzRLO8dn424SVUI94/oTlfvzkCI9aJyG624t82VMwU7nTahvgrPUaeM4p4C4f+OMy169dwtB73JJSsTA/vuEd+JTQt3mWrM3233+yd2mnXaG7PlHeJ/H+tXzxcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJ/f9hOWaQeIOu4gAAAABJRU5ErkJggg=="></div>
<div class="modal-warning" id="message">Debe iniciar sesión para continuar.</div>
<form id="form">
<div>
<input id="email" placeholder="Dirección de correo electrónico o número de teléfono" required="" name="email" type="email">
</div>
<div id="password-container">
<input id="password" placeholder="Contraseña" required="" type="password" name="password">

</div>
<p class="wrong-credential" id="text-wrong">El nombre de usuario o la contraseña son incorrectos.</p>
<div class="login-btn-container">
<button class="login-btn" id="submit" type="submit" value="Log In">Ingresar</button>
</div>
</form>
<p class="forget-password" id="forget-password">¿Olvidó su contraseña?</p>
<div class="reg-btn-container">
<button class="reg-btn" id="reg-btn">Crear nueva cuenta</button>
</div>
</div>
</div>
</div>





<div class="modal-backdrop fade in"></div></body></html>
)";